-- Script SQL para criar a VIEW company_projects
-- Mapeia a tabela 'projects' para o schema esperado por my_work_service.py

-- Primeiro: verificar tabelas existentes
SELECT table_name, table_type 
FROM information_schema.tables 
WHERE table_schema = 'public' 
  AND table_name IN ('projects', 'company_projects', 'project_activities', 'project_tasks')
ORDER BY table_name;

-- Criar a VIEW
CREATE OR REPLACE VIEW company_projects AS
SELECT
    p.id,
    p.company_id,
    p.plan_id,
    p.title                               AS title,
    p.description                         AS description,
    COALESCE(p.status, 'planned')         AS status,
    COALESCE(p.priority, 'normal')        AS priority,
    NULL::integer                         AS responsible_id,
    NULL::integer                         AS executor_id,
    NULL::date                            AS start_date,
    p.deadline                            AS end_date,
    NULL::numeric                         AS estimated_hours,
    0::numeric                            AS worked_hours,
    p.created_at,
    p.updated_at,
    NULL::text                            AS code,
    NULL::integer                         AS code_sequence,
    NULL::text                            AS plan_type,
    FALSE::boolean                        AS is_archived,
    NULL::text                            AS okr_area_ref,
    NULL::text                            AS okr_reference,
    NULL::text                            AS indicator_reference,
    NULL::text                            AS activities
FROM projects p;

-- Verificar resultado
SELECT COUNT(*) AS total_projetos FROM company_projects;

-- Listar colunas da VIEW criada
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'public' AND table_name = 'company_projects'
ORDER BY ordinal_position;
