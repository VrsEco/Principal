-- Table creation for UI references v2
CREATE TABLE IF NOT EXISTS ui_pages_v2 (
    id SERIAL PRIMARY KEY,
    page_code CHAR(3) NOT NULL UNIQUE,
    page_name TEXT NOT NULL,
    template_file TEXT NOT NULL,
    page_route TEXT,
    description TEXT,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ui_elements_v2 (
    id SERIAL PRIMARY KEY,
    page_id INTEGER NOT NULL REFERENCES ui_pages_v2(id) ON DELETE CASCADE,
    element_code CHAR(3) NOT NULL,
    element_name TEXT NOT NULL,
    element_type TEXT,
    html_id TEXT,
    html_class TEXT,
    description TEXT,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (page_id, element_code)
);

