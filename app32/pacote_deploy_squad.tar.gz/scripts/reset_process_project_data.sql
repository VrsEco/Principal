-- Limpa instâncias de processos e atividades de projetos
-- para a empresa Versus Gestao Corporativa (AA) nos bancos

BEGIN;

CREATE TEMP TABLE tmp_target_company AS
SELECT id
FROM companies
WHERE name ILIKE 'Versus Gest%'
LIMIT 1;

CREATE TEMP TABLE tmp_target_process_instances AS
SELECT id
FROM process_instances
WHERE company_id = (SELECT id FROM tmp_target_company);

CREATE TEMP TABLE tmp_target_projects AS
SELECT id
FROM company_projects
WHERE company_id = (SELECT id FROM tmp_target_company);

CREATE TEMP TABLE tmp_target_project_activities AS
SELECT id
FROM project_activities
WHERE project_id IN (SELECT id FROM tmp_target_projects);

DELETE FROM activity_comments
WHERE activity_type = 'process'
  AND activity_id IN (SELECT id FROM tmp_target_process_instances);

DELETE FROM activity_work_logs
WHERE activity_type = 'process'
  AND activity_id IN (SELECT id FROM tmp_target_process_instances);

DELETE FROM process_instance_collaborators
WHERE process_instance_id IN (SELECT id FROM tmp_target_process_instances);

DELETE FROM process_instances
WHERE id IN (SELECT id FROM tmp_target_process_instances);

DELETE FROM activity_comments
WHERE activity_type = 'project'
  AND activity_id IN (SELECT id FROM tmp_target_project_activities);

DELETE FROM activity_work_logs
WHERE activity_type = 'project'
  AND activity_id IN (SELECT id FROM tmp_target_project_activities);

DELETE FROM project_activity_collaborators
WHERE activity_id IN (SELECT id FROM tmp_target_project_activities);

DELETE FROM project_activities
WHERE id IN (SELECT id FROM tmp_target_project_activities);

DELETE FROM company_projects
WHERE id IN (SELECT id FROM tmp_target_projects);

COMMIT;
