-- Migration: Create notes table
-- Date: 2024-11-24
-- Description: Create table for user notes in the ecosystem view

-- Create notes table
CREATE TABLE IF NOT EXISTS notes (
    id SERIAL PRIMARY KEY,
    code VARCHAR(32) NOT NULL UNIQUE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    text TEXT NOT NULL,
    location VARCHAR(256),
    status VARCHAR(32) NOT NULL DEFAULT 'ativa',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_notes_user_id ON notes(user_id);
CREATE INDEX IF NOT EXISTS idx_notes_status ON notes(status);
CREATE INDEX IF NOT EXISTS idx_notes_created_at ON notes(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notes_code ON notes(code);

-- Add comment to table
COMMENT ON TABLE notes IS 'User notes for the ecosystem view';
COMMENT ON COLUMN notes.id IS 'Primary key';
COMMENT ON COLUMN notes.code IS 'Unique note code (e.g., NT-1234)';
COMMENT ON COLUMN notes.user_id IS 'Foreign key to users table';
COMMENT ON COLUMN notes.text IS 'Note content';
COMMENT ON COLUMN notes.location IS 'Optional location/context information';
COMMENT ON COLUMN notes.status IS 'Note status (ativa, arquivada, etc.)';
COMMENT ON COLUMN notes.created_at IS 'Creation timestamp';
