-- Migration: Criação de tabelas para ModeFin (Modelagem Financeira)
-- Data: 2025-10-29
-- Autor: Sistema GestaoVersus

-- =========================================
-- 1. TABELA: plan_finance_capital_giro
-- =========================================
CREATE TABLE IF NOT EXISTS plan_finance_capital_giro (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans(id) ON DELETE CASCADE,
    item_type VARCHAR(50) NOT NULL, -- 'caixa', 'recebiveis', 'estoques'
    contribution_date DATE NOT NULL,
    amount NUMERIC(15, 2) NOT NULL DEFAULT 0,
    description TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_deleted BOOLEAN DEFAULT FALSE
);

-- Índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_capital_giro_plan_id 
ON plan_finance_capital_giro(plan_id);

CREATE INDEX IF NOT EXISTS idx_capital_giro_item_type 
ON plan_finance_capital_giro(item_type);

CREATE INDEX IF NOT EXISTS idx_capital_giro_contribution_date 
ON plan_finance_capital_giro(contribution_date);

-- =========================================
-- 2. ATUALIZAR plan_finance_metrics
-- =========================================
-- Adicionar coluna para resumo executivo se não existir
ALTER TABLE plan_finance_metrics 
ADD COLUMN IF NOT EXISTS executive_summary TEXT;

-- =========================================
-- 3. COMENTÁRIOS E DOCUMENTAÇÃO
-- =========================================
COMMENT ON TABLE plan_finance_capital_giro IS 'Investimentos em Capital de Giro (Caixa, Recebíveis, Estoques)';
COMMENT ON COLUMN plan_finance_capital_giro.item_type IS 'Tipo: caixa | recebiveis | estoques';
COMMENT ON COLUMN plan_finance_capital_giro.contribution_date IS 'Data do aporte/investimento';
COMMENT ON COLUMN plan_finance_capital_giro.amount IS 'Valor em R$';
COMMENT ON COLUMN plan_finance_capital_giro.description IS 'Descrição do investimento';
COMMENT ON COLUMN plan_finance_capital_giro.notes IS 'Observações adicionais';

COMMENT ON COLUMN plan_finance_metrics.executive_summary IS 'Resumo executivo editável pelo consultor';

-- =========================================
-- 4. DADOS TESTE (opcional - comentado)
-- =========================================
-- Descomentar apenas para desenvolvimento/teste
/*
INSERT INTO plan_finance_capital_giro (plan_id, item_type, contribution_date, amount, description)
VALUES 
(1, 'caixa', '2026-05-01', 612000.00, 'Capital inicial de caixa'),
(1, 'estoques', '2026-06-01', 430000.00, 'Estoque inicial de produtos');
*/

