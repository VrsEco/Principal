-- ============================================================================
-- Migration: Adicionar relacionamento User <-> Employee
-- Data: 2025-10-22
-- Objetivo: Permitir que employees tenham user_id para login no sistema
-- ============================================================================

-- 1. Adicionar coluna user_id em employees
ALTER TABLE employees 
ADD COLUMN user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;

-- 2. Criar índice para performance
CREATE INDEX idx_employees_user ON employees(user_id);

-- 3. Garantir unicidade: um user só pode ser vinculado a um employee
CREATE UNIQUE INDEX idx_employees_user_unique ON employees(user_id) WHERE user_id IS NOT NULL;

-- 4. Comentário na coluna (PostgreSQL)
COMMENT ON COLUMN employees.user_id IS 'FK para users - Permite que colaborador tenha acesso ao sistema';

-- ============================================================================
-- OBSERVAÇÕES
-- ============================================================================
-- 
-- - user_id é NULLABLE: nem todo employee precisa ter login
-- - Relacionamento 1:1 (um user = um employee)
-- - ON DELETE SET NULL: se user for deletado, employee continua existindo
-- - Após migration, executar script de vinculação para dados existentes
--
-- ============================================================================

