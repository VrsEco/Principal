BEGIN;

ALTER TABLE project_activities
    ADD COLUMN IF NOT EXISTS score_weight NUMERIC(10,2) DEFAULT 1;

UPDATE project_activities
SET score_weight = 1
WHERE score_weight IS NULL;

ALTER TABLE process_instances
    ADD COLUMN IF NOT EXISTS score_weight NUMERIC(10,2) DEFAULT 1;

UPDATE process_instances
SET score_weight = 1
WHERE score_weight IS NULL;

COMMIT;

