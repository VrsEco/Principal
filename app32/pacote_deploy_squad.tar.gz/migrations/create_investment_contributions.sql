-- Migration: Create Investment Contributions Tables
-- Date: 2025-10-25
-- Description: Creates tables for investment contributions with dates and funding sources

-- Investment categories (Capital de Giro, Imobilizado)
CREATE TABLE IF NOT EXISTS plan_finance_investment_categories (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    category_type VARCHAR(50) NOT NULL, -- 'capital_giro' ou 'imobilizado'
    category_name VARCHAR(100) NOT NULL, -- 'Capital de Giro' ou 'Imobilizado'
    display_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Investment items (Caixa, Recebíveis, Estoques, etc)
CREATE TABLE IF NOT EXISTS plan_finance_investment_items (
    id SERIAL PRIMARY KEY,
    category_id INTEGER NOT NULL REFERENCES plan_finance_investment_categories (id) ON DELETE CASCADE,
    item_name VARCHAR(100) NOT NULL, -- 'Caixa', 'Recebíveis', etc
    display_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Investment contributions (aportes com data e valor)
CREATE TABLE IF NOT EXISTS plan_finance_investment_contributions (
    id SERIAL PRIMARY KEY,
    item_id INTEGER NOT NULL REFERENCES plan_finance_investment_items (id) ON DELETE CASCADE,
    contribution_date DATE NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Funding sources (tipo, valor, data)
CREATE TABLE IF NOT EXISTS plan_finance_funding_sources (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    source_type VARCHAR(100) NOT NULL, -- 'Fornecedores', 'Empréstimos', 'Aporte dos Sócios'
    contribution_date DATE NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_investment_categories_plan ON plan_finance_investment_categories(plan_id);
CREATE INDEX IF NOT EXISTS idx_investment_items_category ON plan_finance_investment_items(category_id);
CREATE INDEX IF NOT EXISTS idx_investment_contributions_item ON plan_finance_investment_contributions(item_id);
CREATE INDEX IF NOT EXISTS idx_investment_contributions_date ON plan_finance_investment_contributions(contribution_date);
CREATE INDEX IF NOT EXISTS idx_funding_sources_plan ON plan_finance_funding_sources(plan_id);
CREATE INDEX IF NOT EXISTS idx_funding_sources_date ON plan_finance_funding_sources(contribution_date);

