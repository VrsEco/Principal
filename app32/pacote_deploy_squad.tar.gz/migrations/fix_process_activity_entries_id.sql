-- Migração: Adicionar auto-increment à coluna id de process_activity_entries
-- Data: 2025-11-05
-- Problema: Coluna id não está configurada como SERIAL, causando erro ao inserir registros

-- Verificar se já existe uma sequence
DO $$
BEGIN
    -- Criar sequence se não existir
    IF NOT EXISTS (SELECT 1 FROM pg_sequences WHERE schemaname = 'public' AND sequencename = 'process_activity_entries_id_seq') THEN
        CREATE SEQUENCE process_activity_entries_id_seq;
        RAISE NOTICE 'Sequence process_activity_entries_id_seq criada';
    ELSE
        RAISE NOTICE 'Sequence process_activity_entries_id_seq já existe';
    END IF;
END $$;

-- Definir o valor atual da sequence baseado nos dados existentes
SELECT setval('process_activity_entries_id_seq', COALESCE((SELECT MAX(id) FROM process_activity_entries), 0) + 1, false);

-- Alterar a coluna para usar a sequence como default
ALTER TABLE process_activity_entries 
ALTER COLUMN id SET DEFAULT nextval('process_activity_entries_id_seq');

-- Associar a sequence à coluna (para que seja deletada junto com a tabela)
ALTER SEQUENCE process_activity_entries_id_seq OWNED BY process_activity_entries.id;

-- Verificação final
DO $$
DECLARE
    v_default_value text;
BEGIN
    SELECT column_default INTO v_default_value
    FROM information_schema.columns
    WHERE table_name = 'process_activity_entries' AND column_name = 'id';
    
    RAISE NOTICE 'Coluna id agora tem default: %', v_default_value;
END $$;

-- Teste (comentado por segurança - descomente para testar)
-- INSERT INTO process_activity_entries (activity_id, order_index, text_content, image_path, image_width, layout)
-- VALUES (1, 1, 'Teste de migração', NULL, 280, 'dual')
-- RETURNING id;








































