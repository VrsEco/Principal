-- Migration to add order_index to routines table
-- Date: 2026-02-19
-- Author: Antigravity

DO $$ 
BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='routines' AND column_name='order_index') THEN 
        ALTER TABLE routines ADD COLUMN order_index INTEGER DEFAULT 0;
    END IF;
END $$;
