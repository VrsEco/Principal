-- Migration: Seed Default Investment Categories and Items
-- Date: 2025-10-25
-- Description: Creates default investment categories and items for all plans

-- This will be run via Python code to seed for specific plan_id
-- Categories:
-- 1. Capital de Giro
--    - Caixa
--    - Recebíveis
--    - Estoques
-- 2. Imobilizado
--    - Instalações
--    - Máquinas e Equipamentos
--    - Outros Investimentos

-- Note: This SQL is provided as reference
-- Actual implementation will be done in Python to iterate through all plans

