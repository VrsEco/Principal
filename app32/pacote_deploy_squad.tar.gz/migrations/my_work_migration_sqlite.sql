-- ============================================================================
-- MIGRAÇÃO: MY WORK - Sistema de Gestão de Atividades (SQLite)
-- ============================================================================
-- Data: 21/10/2025
-- Descrição: Adiciona campos e tabelas para o módulo My Work
-- Compatibilidade: SQLite
-- ============================================================================

-- ============================================================================
-- PARTE 1: Adicionar campos em company_projects
-- ============================================================================

-- SQLite não suporta ADD COLUMN IF NOT EXISTS, então verificamos manualmente
ALTER TABLE company_projects ADD COLUMN estimated_hours REAL DEFAULT 0;
ALTER TABLE company_projects ADD COLUMN worked_hours REAL DEFAULT 0;
ALTER TABLE company_projects ADD COLUMN executor_id INTEGER;

-- ============================================================================
-- PARTE 2: process_instances já tem os campos necessários
-- ============================================================================
-- estimated_hours e actual_hours já existem
-- Apenas criar índices

CREATE INDEX IF NOT EXISTS idx_process_instances_status ON process_instances(status);
CREATE INDEX IF NOT EXISTS idx_process_instances_priority ON process_instances(priority);
CREATE INDEX IF NOT EXISTS idx_process_instances_due_date ON process_instances(due_date);

-- ============================================================================
-- PARTE 3: Criar tabela TEAMS
-- ============================================================================

CREATE TABLE IF NOT EXISTS teams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    leader_id INTEGER,
    
    -- Auditoria
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    is_active INTEGER DEFAULT 1,  -- 0 = false, 1 = true
    
    -- Constraints
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY (leader_id) REFERENCES employees(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_teams_company ON teams(company_id);
CREATE INDEX IF NOT EXISTS idx_teams_leader ON teams(leader_id);
CREATE INDEX IF NOT EXISTS idx_teams_active ON teams(is_active);

-- Trigger para updated_at
CREATE TRIGGER IF NOT EXISTS trg_teams_updated_at
AFTER UPDATE ON teams
FOR EACH ROW
BEGIN
    UPDATE teams
    SET updated_at = datetime('now')
    WHERE id = NEW.id;
END;

-- ============================================================================
-- PARTE 4: Criar tabela TEAM_MEMBERS
-- ============================================================================

CREATE TABLE IF NOT EXISTS team_members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    team_id INTEGER NOT NULL,
    employee_id INTEGER NOT NULL,
    role TEXT DEFAULT 'member',  -- 'leader', 'member', 'viewer'
    
    -- Auditoria
    joined_at TEXT DEFAULT (datetime('now')),
    left_at TEXT,
    
    -- Constraints
    FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    UNIQUE(team_id, employee_id)
);

CREATE INDEX IF NOT EXISTS idx_team_members_team ON team_members(team_id);
CREATE INDEX IF NOT EXISTS idx_team_members_employee ON team_members(employee_id);

-- ============================================================================
-- PARTE 5: Criar tabela ACTIVITY_WORK_LOGS
-- ============================================================================

CREATE TABLE IF NOT EXISTS activity_work_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    
    -- Referência à atividade
    activity_type TEXT NOT NULL,  -- 'project' ou 'process'
    activity_id INTEGER NOT NULL,
    
    -- Quem trabalhou
    employee_id INTEGER NOT NULL,
    employee_name TEXT,
    
    -- Detalhes
    work_date TEXT NOT NULL,  -- ISO format: YYYY-MM-DD
    hours_worked REAL NOT NULL,
    description TEXT,
    
    -- Auditoria
    created_at TEXT DEFAULT (datetime('now')),
    
    -- Constraints
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CHECK (activity_type IN ('project', 'process')),
    CHECK (hours_worked > 0 AND hours_worked <= 24)
);

CREATE INDEX IF NOT EXISTS idx_work_logs_activity ON activity_work_logs(activity_type, activity_id);
CREATE INDEX IF NOT EXISTS idx_work_logs_employee ON activity_work_logs(employee_id);
CREATE INDEX IF NOT EXISTS idx_work_logs_date ON activity_work_logs(work_date);

-- ============================================================================
-- PARTE 6: Criar tabela ACTIVITY_COMMENTS
-- ============================================================================

CREATE TABLE IF NOT EXISTS activity_comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    
    -- Referência à atividade
    activity_type TEXT NOT NULL,  -- 'project' ou 'process'
    activity_id INTEGER NOT NULL,
    
    -- Autor
    employee_id INTEGER NOT NULL,
    employee_name TEXT,
    
    -- Conteúdo
    comment_type TEXT,  -- 'note', 'progress', 'issue', 'solution', 'question'
    comment_text TEXT NOT NULL,
    is_private INTEGER DEFAULT 0,  -- 0 = false, 1 = true
    
    -- Auditoria
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    
    -- Constraints
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CHECK (activity_type IN ('project', 'process'))
);

CREATE INDEX IF NOT EXISTS idx_comments_activity ON activity_comments(activity_type, activity_id);
CREATE INDEX IF NOT EXISTS idx_comments_employee ON activity_comments(employee_id);
CREATE INDEX IF NOT EXISTS idx_comments_created ON activity_comments(created_at);

-- Trigger para updated_at
CREATE TRIGGER IF NOT EXISTS trg_comments_updated_at
AFTER UPDATE ON activity_comments
FOR EACH ROW
BEGIN
    UPDATE activity_comments
    SET updated_at = datetime('now')
    WHERE id = NEW.id;
END;

-- ============================================================================
-- PARTE 7: Índices adicionais em company_projects
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_company_projects_responsible ON company_projects(responsible_id);
CREATE INDEX IF NOT EXISTS idx_company_projects_executor ON company_projects(executor_id);
CREATE INDEX IF NOT EXISTS idx_company_projects_status ON company_projects(status);
CREATE INDEX IF NOT EXISTS idx_company_projects_priority ON company_projects(priority);
CREATE INDEX IF NOT EXISTS idx_company_projects_end_date ON company_projects(end_date);

-- ============================================================================
-- PARTE 8: Dados iniciais de teste (opcional)
-- ============================================================================

-- Criar equipe de exemplo (descomentar se quiser testar)
-- INSERT INTO teams (company_id, name, description, leader_id) 
-- VALUES (1, 'Equipe Piloto', 'Equipe de testes do sistema My Work', NULL);

-- ============================================================================
-- VERIFICAÇÃO FINAL
-- ============================================================================

-- Verificar se tabelas foram criadas
SELECT 'Tabelas criadas:' as status;
SELECT name FROM sqlite_master WHERE type='table' AND name IN ('teams', 'team_members', 'activity_work_logs', 'activity_comments');

-- Verificar campos adicionados
SELECT 'Campos em company_projects:' as status;
PRAGMA table_info(company_projects);

-- ============================================================================
-- FIM DA MIGRAÇÃO
-- ============================================================================

