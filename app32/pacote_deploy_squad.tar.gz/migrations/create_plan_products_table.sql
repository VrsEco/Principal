-- ========================================
-- Tabela: plan_products
-- Sistema: Modelo & Mercado - Cadastro de Produtos
-- Data: 27/10/2025
-- ========================================

CREATE TABLE IF NOT EXISTS plan_products (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL,
    
    -- Identificação do Produto
    name VARCHAR(200) NOT NULL,
    description TEXT,
    
    -- a) Preço de Venda
    sale_price NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
    sale_price_notes TEXT,
    
    -- b) Custos Variáveis
    variable_costs_percent NUMERIC(5, 2) DEFAULT 0.00,
    variable_costs_value NUMERIC(15, 2) DEFAULT 0.00,
    variable_costs_notes TEXT,
    
    -- c) Despesas Variáveis
    variable_expenses_percent NUMERIC(5, 2) DEFAULT 0.00,
    variable_expenses_value NUMERIC(15, 2) DEFAULT 0.00,
    variable_expenses_notes TEXT,
    
    -- Margem de Contribuição Unitária (CALCULADO)
    unit_contribution_margin_percent NUMERIC(5, 2) DEFAULT 0.00,
    unit_contribution_margin_value NUMERIC(15, 2) DEFAULT 0.00,
    unit_contribution_margin_notes TEXT,
    
    -- d) Tamanho do Mercado
    market_size_monthly_units NUMERIC(15, 2) DEFAULT 0.00,
    market_size_monthly_revenue NUMERIC(15, 2) DEFAULT 0.00, -- CALCULADO
    market_size_notes TEXT,
    
    -- e) Alvo de Marketing Share
    market_share_goal_monthly_units NUMERIC(15, 2) DEFAULT 0.00,
    market_share_goal_percent NUMERIC(5, 2) DEFAULT 0.00,
    market_share_goal_notes TEXT,
    
    -- Auditoria
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_deleted BOOLEAN DEFAULT FALSE,
    
    -- Constraints
    FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE CASCADE,
    CONSTRAINT check_sale_price_positive CHECK (sale_price >= 0),
    CONSTRAINT check_variable_costs_percent_range CHECK (variable_costs_percent >= 0 AND variable_costs_percent <= 100),
    CONSTRAINT check_variable_expenses_percent_range CHECK (variable_expenses_percent >= 0 AND variable_expenses_percent <= 100),
    CONSTRAINT check_market_share_goal_percent_range CHECK (market_share_goal_percent >= 0 AND market_share_goal_percent <= 100)
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_plan_products_plan_id ON plan_products(plan_id);
CREATE INDEX IF NOT EXISTS idx_plan_products_is_deleted ON plan_products(is_deleted);
CREATE INDEX IF NOT EXISTS idx_plan_products_plan_id_not_deleted ON plan_products(plan_id, is_deleted);

-- Comentários
COMMENT ON TABLE plan_products IS 'Produtos para modelagem financeira e análise de mercado';
COMMENT ON COLUMN plan_products.sale_price IS 'Preço de venda unitário do produto';
COMMENT ON COLUMN plan_products.variable_costs_percent IS 'Custos variáveis em percentual do preço';
COMMENT ON COLUMN plan_products.variable_costs_value IS 'Custos variáveis em valor absoluto';
COMMENT ON COLUMN plan_products.variable_expenses_percent IS 'Despesas variáveis em percentual do preço';
COMMENT ON COLUMN plan_products.variable_expenses_value IS 'Despesas variáveis em valor absoluto';
COMMENT ON COLUMN plan_products.unit_contribution_margin_percent IS 'Margem de contribuição unitária em percentual (CALCULADO)';
COMMENT ON COLUMN plan_products.unit_contribution_margin_value IS 'Margem de contribuição unitária em valor (CALCULADO)';
COMMENT ON COLUMN plan_products.market_size_monthly_units IS 'Tamanho do mercado em unidades mensais';
COMMENT ON COLUMN plan_products.market_size_monthly_revenue IS 'Faturamento mensal do mercado (CALCULADO: unidades * preço)';
COMMENT ON COLUMN plan_products.market_share_goal_monthly_units IS 'Meta de market share em unidades mensais';
COMMENT ON COLUMN plan_products.market_share_goal_percent IS 'Meta de market share em percentual do mercado';

-- Trigger para updated_at
CREATE OR REPLACE FUNCTION update_plan_products_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_plan_products_updated_at
    BEFORE UPDATE ON plan_products
    FOR EACH ROW
    EXECUTE FUNCTION update_plan_products_updated_at();

-- ========================================
-- Dados de Exemplo (Opcional)
-- ========================================
-- INSERT INTO plan_products (plan_id, name, sale_price, variable_costs_percent, variable_expenses_percent)
-- VALUES (1, 'Produto Exemplo', 100.00, 30.00, 10.00);

