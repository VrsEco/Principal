-- ============================================
-- Fix: Adicionar SEQUENCES para todas as tabelas sem auto-increment
-- ============================================
-- Data: 2025-10-21
-- Descrição: 14 tabelas foram criadas com id INTEGER NOT NULL sem SERIAL,
--            causando erros ao tentar inserir registros
-- ============================================

-- Tabela 1: alignment_records
CREATE SEQUENCE IF NOT EXISTS alignment_records_id_seq;
SELECT setval('alignment_records_id_seq', COALESCE((SELECT MAX(id) FROM alignment_records), 0) + 1, false);
ALTER TABLE alignment_records ALTER COLUMN id SET DEFAULT nextval('alignment_records_id_seq');
ALTER SEQUENCE alignment_records_id_seq OWNED BY alignment_records.id;

-- Tabela 2: company_records
CREATE SEQUENCE IF NOT EXISTS company_records_id_seq;
SELECT setval('company_records_id_seq', COALESCE((SELECT MAX(id) FROM company_records), 0) + 1, false);
ALTER TABLE company_records ALTER COLUMN id SET DEFAULT nextval('company_records_id_seq');
ALTER SEQUENCE company_records_id_seq OWNED BY company_records.id;

-- Tabela 3: directional_records
CREATE SEQUENCE IF NOT EXISTS directional_records_id_seq;
SELECT setval('directional_records_id_seq', COALESCE((SELECT MAX(id) FROM directional_records), 0) + 1, false);
ALTER TABLE directional_records ALTER COLUMN id SET DEFAULT nextval('directional_records_id_seq');
ALTER SEQUENCE directional_records_id_seq OWNED BY directional_records.id;

-- Tabela 4: market_records
CREATE SEQUENCE IF NOT EXISTS market_records_id_seq;
SELECT setval('market_records_id_seq', COALESCE((SELECT MAX(id) FROM market_records), 0) + 1, false);
ALTER TABLE market_records ALTER COLUMN id SET DEFAULT nextval('market_records_id_seq');
ALTER SEQUENCE market_records_id_seq OWNED BY market_records.id;

-- Tabela 5: misalignment_records
CREATE SEQUENCE IF NOT EXISTS misalignment_records_id_seq;
SELECT setval('misalignment_records_id_seq', COALESCE((SELECT MAX(id) FROM misalignment_records), 0) + 1, false);
ALTER TABLE misalignment_records ALTER COLUMN id SET DEFAULT nextval('misalignment_records_id_seq');
ALTER SEQUENCE misalignment_records_id_seq OWNED BY misalignment_records.id;

-- Tabela 6: okr_area_preliminary_records
CREATE SEQUENCE IF NOT EXISTS okr_area_preliminary_records_id_seq;
SELECT setval('okr_area_preliminary_records_id_seq', COALESCE((SELECT MAX(id) FROM okr_area_preliminary_records), 0) + 1, false);
ALTER TABLE okr_area_preliminary_records ALTER COLUMN id SET DEFAULT nextval('okr_area_preliminary_records_id_seq');
ALTER SEQUENCE okr_area_preliminary_records_id_seq OWNED BY okr_area_preliminary_records.id;

-- Tabela 7: okr_preliminary_records
CREATE SEQUENCE IF NOT EXISTS okr_preliminary_records_id_seq;
SELECT setval('okr_preliminary_records_id_seq', COALESCE((SELECT MAX(id) FROM okr_preliminary_records), 0) + 1, false);
ALTER TABLE okr_preliminary_records ALTER COLUMN id SET DEFAULT nextval('okr_preliminary_records_id_seq');
ALTER SEQUENCE okr_preliminary_records_id_seq OWNED BY okr_preliminary_records.id;

-- Tabela 8: process_activity_entries
CREATE SEQUENCE IF NOT EXISTS process_activity_entries_id_seq;
SELECT setval('process_activity_entries_id_seq', COALESCE((SELECT MAX(id) FROM process_activity_entries), 0) + 1, false);
ALTER TABLE process_activity_entries ALTER COLUMN id SET DEFAULT nextval('process_activity_entries_id_seq');
ALTER SEQUENCE process_activity_entries_id_seq OWNED BY process_activity_entries.id;

-- Tabela 9: process_instances
CREATE SEQUENCE IF NOT EXISTS process_instances_id_seq;
SELECT setval('process_instances_id_seq', COALESCE((SELECT MAX(id) FROM process_instances), 0) + 1, false);
ALTER TABLE process_instances ALTER COLUMN id SET DEFAULT nextval('process_instances_id_seq');
ALTER SEQUENCE process_instances_id_seq OWNED BY process_instances.id;

-- Tabela 10: report_models
CREATE SEQUENCE IF NOT EXISTS report_models_id_seq;
SELECT setval('report_models_id_seq', COALESCE((SELECT MAX(id) FROM report_models), 0) + 1, false);
ALTER TABLE report_models ALTER COLUMN id SET DEFAULT nextval('report_models_id_seq');
ALTER SEQUENCE report_models_id_seq OWNED BY report_models.id;

-- Tabela 11: report_patterns
CREATE SEQUENCE IF NOT EXISTS report_patterns_id_seq;
SELECT setval('report_patterns_id_seq', COALESCE((SELECT MAX(id) FROM report_patterns), 0) + 1, false);
ALTER TABLE report_patterns ALTER COLUMN id SET DEFAULT nextval('report_patterns_id_seq');
ALTER SEQUENCE report_patterns_id_seq OWNED BY report_patterns.id;

-- Tabela 12: report_templates
CREATE SEQUENCE IF NOT EXISTS report_templates_id_seq;
SELECT setval('report_templates_id_seq', COALESCE((SELECT MAX(id) FROM report_templates), 0) + 1, false);
ALTER TABLE report_templates ALTER COLUMN id SET DEFAULT nextval('report_templates_id_seq');
ALTER SEQUENCE report_templates_id_seq OWNED BY report_templates.id;

-- Tabela 13: user_logs
CREATE SEQUENCE IF NOT EXISTS user_logs_id_seq;
SELECT setval('user_logs_id_seq', COALESCE((SELECT MAX(id) FROM user_logs), 0) + 1, false);
ALTER TABLE user_logs ALTER COLUMN id SET DEFAULT nextval('user_logs_id_seq');
ALTER SEQUENCE user_logs_id_seq OWNED BY user_logs.id;

-- Tabela 14: vision_records
CREATE SEQUENCE IF NOT EXISTS vision_records_id_seq;
SELECT setval('vision_records_id_seq', COALESCE((SELECT MAX(id) FROM vision_records), 0) + 1, false);
ALTER TABLE vision_records ALTER COLUMN id SET DEFAULT nextval('vision_records_id_seq');
ALTER SEQUENCE vision_records_id_seq OWNED BY vision_records.id;

-- ============================================
-- Verificação Final
-- ============================================
-- Verificar que todas as tabelas agora têm sequence
SELECT 
    table_name,
    column_default
FROM 
    information_schema.columns
WHERE 
    table_schema = 'public'
    AND table_name IN (
        'alignment_records', 'company_records', 'directional_records',
        'market_records', 'misalignment_records', 'okr_area_preliminary_records',
        'okr_preliminary_records', 'process_activity_entries', 'process_instances',
        'report_models', 'report_patterns', 'report_templates',
        'user_logs', 'vision_records'
    )
    AND column_name = 'id'
ORDER BY 
    table_name;

-- Resultado esperado: Todas as tabelas devem ter nextval('...') como default




