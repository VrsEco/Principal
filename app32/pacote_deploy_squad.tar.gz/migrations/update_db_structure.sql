-- Adicionar coluna permissions na tabela roles
ALTER TABLE roles ADD COLUMN IF NOT EXISTS permissions JSON;

-- Adicionar coluna employee_id na tabela project_tasks
ALTER TABLE project_tasks ADD COLUMN IF NOT EXISTS employee_id INTEGER;

-- Adicionar Foreign Key para employee_id em project_tasks
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_project_tasks_employee') THEN
        ALTER TABLE project_tasks
        ADD CONSTRAINT fk_project_tasks_employee
        FOREIGN KEY (employee_id)
        REFERENCES employees (id);
    END IF;
END $$;
