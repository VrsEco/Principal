-- Migration: Create Financial Model Tables
-- Date: 2025-10-24
-- Description: Creates all tables for the financial modeling feature

-- Premises table
CREATE TABLE IF NOT EXISTS plan_finance_premises (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    suggestion TEXT,
    adjusted TEXT,
    observations TEXT,
    memory TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Investments table
CREATE TABLE IF NOT EXISTS plan_finance_investments (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    amount TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sources (funding sources) table
CREATE TABLE IF NOT EXISTS plan_finance_sources (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    category TEXT,
    description TEXT NOT NULL,
    amount TEXT,
    availability TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Business periods table (cash flow)
CREATE TABLE IF NOT EXISTS plan_finance_business_periods (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    period_label TEXT NOT NULL,
    revenue TEXT,
    variables TEXT,
    contribution_margin TEXT,
    fixed_costs TEXT,
    operating_result TEXT,
    result_period TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Business distribution table (profit distribution per period)
CREATE TABLE IF NOT EXISTS plan_finance_business_distribution (
    id SERIAL PRIMARY KEY,
    period_id INTEGER NOT NULL REFERENCES plan_finance_business_periods (id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    amount TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Variable costs table
CREATE TABLE IF NOT EXISTS plan_finance_variable_costs (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    percentage TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Result rules table (profit allocation rules)
CREATE TABLE IF NOT EXISTS plan_finance_result_rules (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    percentage TEXT,
    periodicity TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Investor periods table (investor cash flow)
CREATE TABLE IF NOT EXISTS plan_finance_investor_periods (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    period_label TEXT NOT NULL,
    contribution TEXT,
    distribution TEXT,
    balance TEXT,
    cumulative TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Metrics table (payback, IRR, etc)
CREATE TABLE IF NOT EXISTS plan_finance_metrics (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL UNIQUE REFERENCES plans (id) ON DELETE CASCADE,
    payback TEXT,
    tir TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_finance_premises_plan ON plan_finance_premises(plan_id);
CREATE INDEX IF NOT EXISTS idx_finance_investments_plan ON plan_finance_investments(plan_id);
CREATE INDEX IF NOT EXISTS idx_finance_sources_plan ON plan_finance_sources(plan_id);
CREATE INDEX IF NOT EXISTS idx_finance_business_periods_plan ON plan_finance_business_periods(plan_id);
CREATE INDEX IF NOT EXISTS idx_finance_business_distribution_period ON plan_finance_business_distribution(period_id);
CREATE INDEX IF NOT EXISTS idx_finance_variable_costs_plan ON plan_finance_variable_costs(plan_id);
CREATE INDEX IF NOT EXISTS idx_finance_result_rules_plan ON plan_finance_result_rules(plan_id);
CREATE INDEX IF NOT EXISTS idx_finance_investor_periods_plan ON plan_finance_investor_periods(plan_id);
CREATE INDEX IF NOT EXISTS idx_finance_metrics_plan ON plan_finance_metrics(plan_id);

