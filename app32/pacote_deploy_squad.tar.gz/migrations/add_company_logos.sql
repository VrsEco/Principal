-- Adicionar campos de logos na tabela companies

ALTER TABLE companies ADD COLUMN logo_square TEXT;
ALTER TABLE companies ADD COLUMN logo_vertical TEXT;
ALTER TABLE companies ADD COLUMN logo_horizontal TEXT;
ALTER TABLE companies ADD COLUMN logo_banner TEXT;

-- Tamanhos recomendados (pixels):
-- logo_square: 400x400
-- logo_vertical: 300x600
-- logo_horizontal: 800x400
-- logo_banner: 1200x300




