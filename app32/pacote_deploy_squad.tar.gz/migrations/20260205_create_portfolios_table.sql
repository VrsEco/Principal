-- Create portfolios table
-- This script creates the portfolios table for project portfolio management

CREATE TABLE IF NOT EXISTS portfolios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL,
    code VARCHAR(100) NOT NULL,
    name VARCHAR(200) NOT NULL,
    responsible_id INTEGER,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY (responsible_id) REFERENCES employees(id) ON DELETE SET NULL
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS ix_portfolios_company_id ON portfolios(company_id);
CREATE UNIQUE INDEX IF NOT EXISTS ix_portfolios_company_code ON portfolios(company_id, code);

-- Trigger to update updated_at timestamp
CREATE TRIGGER IF NOT EXISTS update_portfolios_timestamp 
AFTER UPDATE ON portfolios
FOR EACH ROW
BEGIN
    UPDATE portfolios SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

-- Add portfolio_id to projects table
-- Note: SQLite doesn't support adding foreign keys with ALTER TABLE easily,
-- but for now we'll add the column.
ALTER TABLE projects ADD COLUMN portfolio_id INTEGER REFERENCES portfolios(id);
CREATE INDEX IF NOT EXISTS ix_projects_portfolio_id ON projects(portfolio_id);
