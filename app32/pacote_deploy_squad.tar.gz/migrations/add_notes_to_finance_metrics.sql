-- Migration: Add notes field to plan_finance_metrics table
-- Date: 2025-10-24
-- Description: Adds notes field to store comments about financial metrics

-- Add notes column if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'plan_finance_metrics' 
        AND column_name = 'notes'
    ) THEN
        ALTER TABLE plan_finance_metrics ADD COLUMN notes TEXT;
    END IF;
END $$;


