-- Migration: Expand finance investment and source tables with scheduling metadata
-- Date: 2025-10-27
-- Description: Adds grouping, category and scheduling fields to plan_finance_investments
--              and contribution metadata to plan_finance_sources for detailed cash planning.

ALTER TABLE plan_finance_investments
    ADD COLUMN IF NOT EXISTS investment_group TEXT,
    ADD COLUMN IF NOT EXISTS category TEXT,
    ADD COLUMN IF NOT EXISTS contribution_date DATE,
    ADD COLUMN IF NOT EXISTS notes TEXT;

ALTER TABLE plan_finance_sources
    ADD COLUMN IF NOT EXISTS contribution_date DATE,
    ADD COLUMN IF NOT EXISTS notes TEXT;

CREATE INDEX IF NOT EXISTS idx_finance_investments_group
    ON plan_finance_investments (plan_id, investment_group);

CREATE INDEX IF NOT EXISTS idx_finance_investments_category
    ON plan_finance_investments (plan_id, category);

CREATE INDEX IF NOT EXISTS idx_finance_investments_contribution_date
    ON plan_finance_investments (plan_id, contribution_date);

CREATE INDEX IF NOT EXISTS idx_finance_sources_category
    ON plan_finance_sources (plan_id, category);

CREATE INDEX IF NOT EXISTS idx_finance_sources_contribution_date
    ON plan_finance_sources (plan_id, contribution_date);
