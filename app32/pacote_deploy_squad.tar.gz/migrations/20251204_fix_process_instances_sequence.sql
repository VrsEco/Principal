-- ============================================
-- Fix: Garantir sequência no id de process_instances
-- ============================================
-- Data: 2025-12-04
-- Objetivo: Garantir que a coluna `id` da tabela `process_instances`
-- tenha uma sequence associada e já esteja com o `nextval`.

BEGIN;

CREATE SEQUENCE IF NOT EXISTS process_instances_id_seq;

SELECT setval(
    'process_instances_id_seq',
    COALESCE((SELECT MAX(id) FROM process_instances), 0) + 1,
    false
);

ALTER TABLE process_instances
    ALTER COLUMN id SET DEFAULT nextval('process_instances_id_seq');

ALTER SEQUENCE process_instances_id_seq
    OWNED BY process_instances.id;

COMMIT;

-- Verificação opcional:
-- SELECT column_default
-- FROM information_schema.columns
-- WHERE table_name = 'process_instances' AND column_name = 'id';
