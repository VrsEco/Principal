-- Migration: Update Investment Contributions Table
-- Date: 2025-10-28
-- Description: Adds new columns for investment contributions form

-- Add new columns to investment contributions
ALTER TABLE plan_finance_investment_contributions 
ADD COLUMN IF NOT EXISTS description VARCHAR(255);

ALTER TABLE plan_finance_investment_contributions 
ADD COLUMN IF NOT EXISTS system_suggestion DECIMAL(15,2);

ALTER TABLE plan_finance_investment_contributions 
ADD COLUMN IF NOT EXISTS adjusted_value DECIMAL(15,2);

ALTER TABLE plan_finance_investment_contributions 
ADD COLUMN IF NOT EXISTS calculation_memo TEXT;

-- Rename amount column to be clearer (optional, keep for backwards compatibility)
-- The adjusted_value will be the primary value used going forward

-- Update existing records to populate new fields if needed
UPDATE plan_finance_investment_contributions 
SET adjusted_value = amount 
WHERE adjusted_value IS NULL AND amount IS NOT NULL;

