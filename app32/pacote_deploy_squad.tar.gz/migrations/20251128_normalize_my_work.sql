BEGIN;

-- ============================================================================
-- 1. Tabela normalizada de atividades de projeto
-- ============================================================================
CREATE TABLE IF NOT EXISTS project_activities (
    id SERIAL PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES company_projects(id) ON DELETE CASCADE,
    code VARCHAR(64),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(50) DEFAULT 'planned',
    stage VARCHAR(50),
    priority VARCHAR(20) DEFAULT 'normal',
    deadline DATE,
    estimated_hours NUMERIC(10,2) DEFAULT 0,
    worked_hours NUMERIC(10,2) DEFAULT 0,
    amount NUMERIC(14,2),
    responsible_id INTEGER REFERENCES employees(id),
    executor_id INTEGER REFERENCES employees(id),
    metadata JSON,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_project_activities_project_code
    ON project_activities(project_id, code)
    WHERE code IS NOT NULL AND is_deleted = FALSE;

CREATE INDEX IF NOT EXISTS idx_project_activities_project
    ON project_activities(project_id);

CREATE INDEX IF NOT EXISTS idx_project_activities_responsible
    ON project_activities(responsible_id)
    WHERE responsible_id IS NOT NULL AND is_deleted = FALSE;

CREATE INDEX IF NOT EXISTS idx_project_activities_executor
    ON project_activities(executor_id)
    WHERE executor_id IS NOT NULL AND is_deleted = FALSE;

CREATE OR REPLACE FUNCTION trg_project_activities_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at := CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname = 'trg_project_activities_updated_at_row'
    ) THEN
        CREATE TRIGGER trg_project_activities_updated_at_row
        BEFORE UPDATE ON project_activities
        FOR EACH ROW
        EXECUTE PROCEDURE trg_project_activities_updated_at();
    END IF;
END;
$$;

-- ============================================================================
-- 2. Colaboradores normalizados das instâncias de processo
-- ============================================================================
CREATE TABLE IF NOT EXISTS process_instance_collaborators (
    id SERIAL PRIMARY KEY,
    process_instance_id INTEGER NOT NULL REFERENCES process_instances(id) ON DELETE CASCADE,
    employee_id INTEGER NOT NULL REFERENCES employees(id),
    role VARCHAR(32) NOT NULL DEFAULT 'executor',
    estimated_hours NUMERIC(10,2) DEFAULT 0,
    worked_hours NUMERIC(10,2) DEFAULT 0,
    notes TEXT,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_proc_inst_collab_unique
    ON process_instance_collaborators(process_instance_id, employee_id, role)
    WHERE is_deleted = FALSE;

CREATE INDEX IF NOT EXISTS idx_proc_inst_collab_employee
    ON process_instance_collaborators(employee_id)
    WHERE is_deleted = FALSE;

CREATE OR REPLACE FUNCTION trg_proc_inst_collab_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at := CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname = 'trg_proc_inst_collab_updated_at_row'
    ) THEN
        CREATE TRIGGER trg_proc_inst_collab_updated_at_row
        BEFORE UPDATE ON process_instance_collaborators
        FOR EACH ROW
        EXECUTE PROCEDURE trg_proc_inst_collab_updated_at();
    END IF;
END;
$$;

-- ============================================================================
-- 3. Colunas auxiliares em processos e instâncias
-- ============================================================================
ALTER TABLE processes
    ADD COLUMN IF NOT EXISTS owner_employee_id INTEGER REFERENCES employees(id),
    ADD COLUMN IF NOT EXISTS responsible_id INTEGER REFERENCES employees(id);

ALTER TABLE process_instances
    ADD COLUMN IF NOT EXISTS owner_employee_id INTEGER REFERENCES employees(id),
    ADD COLUMN IF NOT EXISTS responsible_id INTEGER REFERENCES employees(id),
    ADD COLUMN IF NOT EXISTS executor_id INTEGER REFERENCES employees(id),
    ADD COLUMN IF NOT EXISTS notes JSON,
    ADD COLUMN IF NOT EXISTS estimated_hours NUMERIC(10,2) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS worked_hours NUMERIC(10,2) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS actual_hours NUMERIC(10,2),
    ADD COLUMN IF NOT EXISTS assigned_collaborators JSON;

CREATE INDEX IF NOT EXISTS idx_process_instances_responsible
    ON process_instances(responsible_id)
    WHERE responsible_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_process_instances_executor
    ON process_instances(executor_id)
    WHERE executor_id IS NOT NULL;

COMMIT;

