-- Migration: Criação da tabela ui_catalog para referenciação de elementos de UI
-- Data: 2025-11-08
-- Objetivo: Permitir mapeamento tela-objeto (ex.: 314-24) para suporte, QA e documentação

CREATE TABLE IF NOT EXISTS ui_catalog (
    id SERIAL PRIMARY KEY,
    screen_code INTEGER NOT NULL,
    object_code INTEGER NOT NULL,
    ui_code VARCHAR(50) NOT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    object_type VARCHAR(50),
    route VARCHAR(255),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT uq_ui_catalog_ui_code UNIQUE (ui_code),
    CONSTRAINT uq_ui_catalog_screen_object UNIQUE (screen_code, object_code)
);

CREATE INDEX IF NOT EXISTS ix_ui_catalog_screen_code
    ON ui_catalog (screen_code);

CREATE INDEX IF NOT EXISTS ix_ui_catalog_object_code
    ON ui_catalog (object_code);

-- =========================================
-- Seeds para prova de conceito (Tela ModeFin 314)
-- =========================================
INSERT INTO ui_catalog (screen_code, object_code, ui_code, name, description, object_type, route)
VALUES
    (314, 1, '314-01', 'Cabeçalho ModeFin', 'Card superior com título e identificação do plano', 'container', '/pev/implantacao/modelo/modefin'),
    (314, 2, '314-02', 'Botão Voltar', 'Ação para retornar à visão de implantação', 'action', '/pev/implantacao/modelo/modefin'),
    (314, 10, '314-10', 'Seção Resultados', 'Container principal da seção de resultados operacionais', 'section', '/pev/implantacao/modelo/modefin'),
    (314, 11, '314-11', 'Card Resultados', 'Card com resumo de faturamento, margens e custos', 'card', '/pev/implantacao/modelo/modefin'),
    (314, 20, '314-20', 'Seção Investimentos', 'Container principal da seção de investimentos', 'section', '/pev/implantacao/modelo/modefin'),
    (314, 21, '314-21', 'Botão Capital de Giro', 'Ação para cadastrar novos itens de capital de giro', 'action', '/pev/implantacao/modelo/modefin'),
    (314, 30, '314-30', 'Seção Fontes de Recursos', 'Container principal de fontes de financiamento', 'section', '/pev/implantacao/modelo/modefin'),
    (314, 31, '314-31', 'Botão Nova Fonte', 'Ação para cadastrar nova fonte de recursos', 'action', '/pev/implantacao/modelo/modefin'),
    (314, 40, '314-40', 'Seção Distribuição de Lucros', 'Container da área de distribuição e destino de resultados', 'section', '/pev/implantacao/modelo/modefin'),
    (314, 41, '314-41', 'Botão Configurar Distribuição', 'Ação para abrir a configuração de distribuição de lucros', 'action', '/pev/implantacao/modelo/modefin'),
    (314, 50, '314-50', 'Seção Fluxo Investimento', 'Container da área de fluxo de investimentos', 'section', '/pev/implantacao/modelo/modefin'),
    (314, 60, '314-60', 'Seção Fluxo Negócio', 'Container da área de fluxo de caixa do negócio', 'section', '/pev/implantacao/modelo/modefin'),
    (314, 70, '314-70', 'Seção Fluxo Investidor', 'Container da área de fluxo de caixa do investidor', 'section', '/pev/implantacao/modelo/modefin'),
    (314, 80, '314-80', 'Seção Análise de Viabilidade', 'Container da área de métricas e análise financeira', 'section', '/pev/implantacao/modelo/modefin')
ON CONFLICT (ui_code) DO NOTHING;

COMMENT ON TABLE ui_catalog IS 'Catálogo de identificação de elementos de interface via código Tela-Objeto';
COMMENT ON COLUMN ui_catalog.screen_code IS 'Código numérico da tela (ex.: 314)';
COMMENT ON COLUMN ui_catalog.object_code IS 'Código sequencial do objeto na tela';
COMMENT ON COLUMN ui_catalog.ui_code IS 'Identificador combinado tela-objeto (ex.: 314-24)';
COMMENT ON COLUMN ui_catalog.route IS 'Rota/permalink associado ao elemento';



































