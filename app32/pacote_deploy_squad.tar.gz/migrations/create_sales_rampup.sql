-- Migration: Ramp-up de Vendas (Crescimento até Meta)
-- Data: 2025-10-29
-- Autor: Sistema GestaoVersus

-- =========================================
-- TABELA: plan_product_monthly_growth
-- =========================================
-- Define o % da meta de vendas esperado em cada mês
-- Permite modelar crescimento gradual até atingir 100% da meta

CREATE TABLE IF NOT EXISTS plan_product_monthly_growth (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans(id) ON DELETE CASCADE,
    product_id INTEGER, -- NULL = aplica para todos os produtos
    month_offset INTEGER NOT NULL, -- 0 = primeiro mês, 1 = segundo mês, etc
    percentage_of_goal NUMERIC(5, 2) NOT NULL DEFAULT 100.00, -- % da meta (ex: 50.00 = 50%)
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_plan_product_month UNIQUE (plan_id, product_id, month_offset)
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_monthly_growth_plan_id 
ON plan_product_monthly_growth(plan_id);

CREATE INDEX IF NOT EXISTS idx_monthly_growth_product_id 
ON plan_product_monthly_growth(product_id);

-- =========================================
-- CONFIGURAÇÃO GLOBAL DE RAMP-UP
-- =========================================
-- Tabela para configuração global do ramp-up

CREATE TABLE IF NOT EXISTS plan_sales_rampup_config (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans(id) ON DELETE CASCADE,
    start_month INTEGER NOT NULL DEFAULT 1, -- Mês de início (1-12)
    start_year INTEGER NOT NULL DEFAULT 2026,
    ramp_duration_months INTEGER NOT NULL DEFAULT 6, -- Quantos meses até 100%
    curve_type VARCHAR(20) DEFAULT 'linear', -- 'linear', 'accelerated', 'decelerated'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_plan_rampup UNIQUE (plan_id)
);

-- =========================================
-- DADOS DEFAULT (opcional)
-- =========================================
-- Exemplo: Crescimento linear em 6 meses
/*
INSERT INTO plan_sales_rampup_config (plan_id, start_month, start_year, ramp_duration_months, curve_type)
VALUES (1, 5, 2026, 6, 'linear')
ON CONFLICT (plan_id) DO NOTHING;
*/

-- Comentários
COMMENT ON TABLE plan_product_monthly_growth IS 'Define % da meta de vendas esperado em cada mês (ramp-up)';
COMMENT ON COLUMN plan_product_monthly_growth.month_offset IS 'Mês relativo ao início (0 = primeiro mês, 1 = segundo, etc)';
COMMENT ON COLUMN plan_product_monthly_growth.percentage_of_goal IS 'Percentual da meta anual esperado neste mês';

COMMENT ON TABLE plan_sales_rampup_config IS 'Configuração global do crescimento de vendas';
COMMENT ON COLUMN plan_sales_rampup_config.curve_type IS 'Tipo de curva: linear, accelerated, decelerated';

