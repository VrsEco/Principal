-- Migration: 20251023_create_alignment_tables.sql
-- Cria tabelas para o Canvas de Expectativas (Implantação)

-- Tabela para membros do alinhamento (sócios)
CREATE TABLE IF NOT EXISTS plan_alignment_members (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(255),
    motivation TEXT,
    commitment TEXT,
    risk TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela para overview do alinhamento (visão, metas, critérios)
CREATE TABLE IF NOT EXISTS plan_alignment_overview (
    plan_id INTEGER PRIMARY KEY REFERENCES plans (id) ON DELETE CASCADE,
    shared_vision TEXT,
    financial_goals TEXT,
    decision_criteria JSONB DEFAULT '[]'::jsonb,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela para agenda de alinhamento (próximos passos)
CREATE TABLE IF NOT EXISTS plan_alignment_agenda (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    action_title TEXT,
    owner_name TEXT,
    schedule_info TEXT,
    execution_info TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela para princípios de decisão (se necessário)
CREATE TABLE IF NOT EXISTS plan_alignment_principles (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    principle TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela para projeto de alinhamento (se necessário)
CREATE TABLE IF NOT EXISTS plan_alignment_project (
    plan_id INTEGER PRIMARY KEY REFERENCES plans (id) ON DELETE CASCADE,
    project_name TEXT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_alignment_members_plan_id ON plan_alignment_members(plan_id);
CREATE INDEX IF NOT EXISTS idx_alignment_agenda_plan_id ON plan_alignment_agenda(plan_id);
CREATE INDEX IF NOT EXISTS idx_alignment_principles_plan_id ON plan_alignment_principles(plan_id);

-- Comentários para documentação
COMMENT ON TABLE plan_alignment_members IS 'Membros do alinhamento estratégico (sócios)';
COMMENT ON TABLE plan_alignment_overview IS 'Visão geral do alinhamento estratégico';
COMMENT ON TABLE plan_alignment_agenda IS 'Agenda de próximos passos do alinhamento';
COMMENT ON TABLE plan_alignment_principles IS 'Princípios de decisão do alinhamento';
COMMENT ON TABLE plan_alignment_project IS 'Projeto associado ao alinhamento';
