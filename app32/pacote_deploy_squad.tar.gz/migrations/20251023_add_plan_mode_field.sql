-- Migration: Add plan_mode field to plans table
-- Date: 2025-10-23
-- Description: Adds plan_mode field to differentiate between 'evolucao' and 'implantacao' planning types

-- Add plan_mode column if it doesn't exist
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'plans' 
        AND column_name = 'plan_mode'
    ) THEN
        ALTER TABLE plans ADD COLUMN plan_mode VARCHAR(32) DEFAULT 'evolucao';
        COMMENT ON COLUMN plans.plan_mode IS 'Type of planning: evolucao (evolution) or implantacao (implementation)';
    END IF;
END $$;

-- Update existing plans to have default value
UPDATE plans SET plan_mode = 'evolucao' WHERE plan_mode IS NULL;

-- Create index for better query performance
CREATE INDEX IF NOT EXISTS idx_plans_plan_mode ON plans(plan_mode);

-- Verify
SELECT 
    column_name, 
    data_type, 
    column_default,
    is_nullable
FROM information_schema.columns 
WHERE table_schema = 'public' 
  AND table_name = 'plans' 
  AND column_name = 'plan_mode';

