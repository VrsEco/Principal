-- ============================================================================
-- MIGRAÇÃO: MY WORK - Sistema de Gestão de Atividades
-- ============================================================================
-- Data: 21/10/2025
-- Descrição: Adiciona campos e tabelas para o módulo My Work
-- Compatibilidade: PostgreSQL e SQLite
-- ============================================================================

-- ============================================================================
-- PARTE 1: Adicionar campos em company_projects
-- ============================================================================

-- PostgreSQL
ALTER TABLE company_projects 
ADD COLUMN IF NOT EXISTS estimated_hours DECIMAL(5,2) DEFAULT 0;

ALTER TABLE company_projects 
ADD COLUMN IF NOT EXISTS worked_hours DECIMAL(5,2) DEFAULT 0;

ALTER TABLE company_projects 
ADD COLUMN IF NOT EXISTS executor_id INTEGER;

COMMENT ON COLUMN company_projects.estimated_hours IS 'Horas estimadas para conclusão da atividade';
COMMENT ON COLUMN company_projects.worked_hours IS 'Total de horas trabalhadas (soma de activity_work_logs)';
COMMENT ON COLUMN company_projects.executor_id IS 'Colaborador que executa (pode ser diferente do responsável)';

-- ============================================================================
-- PARTE 2: Padronizar process_instances
-- ============================================================================

-- process_instances JÁ TEM estimated_hours e actual_hours
-- Vamos apenas garantir que existem e adicionar índices

-- Criar índice para melhorar performance de queries
CREATE INDEX IF NOT EXISTS idx_process_instances_status ON process_instances(status);
CREATE INDEX IF NOT EXISTS idx_process_instances_priority ON process_instances(priority);
CREATE INDEX IF NOT EXISTS idx_process_instances_due_date ON process_instances(due_date);

-- ============================================================================
-- PARTE 3: Criar tabela TEAMS
-- ============================================================================

CREATE TABLE IF NOT EXISTS teams (
    id SERIAL PRIMARY KEY,  -- INTEGER PRIMARY KEY AUTOINCREMENT no SQLite
    company_id INTEGER NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    leader_id INTEGER,  -- FK para employees.id
    
    -- Auditoria
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    
    -- Constraints
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY (leader_id) REFERENCES employees(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_teams_company ON teams(company_id);
CREATE INDEX IF NOT EXISTS idx_teams_leader ON teams(leader_id);
CREATE INDEX IF NOT EXISTS idx_teams_active ON teams(is_active);

COMMENT ON TABLE teams IS 'Equipes de trabalho configuráveis';

-- ============================================================================
-- PARTE 4: Criar tabela TEAM_MEMBERS
-- ============================================================================

CREATE TABLE IF NOT EXISTS team_members (
    id SERIAL PRIMARY KEY,  -- INTEGER PRIMARY KEY AUTOINCREMENT no SQLite
    team_id INTEGER NOT NULL,
    employee_id INTEGER NOT NULL,
    role VARCHAR(50) DEFAULT 'member',  -- 'leader', 'member', 'viewer'
    
    -- Auditoria
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    left_at TIMESTAMP,
    
    -- Constraints
    FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    UNIQUE(team_id, employee_id)
);

CREATE INDEX IF NOT EXISTS idx_team_members_team ON team_members(team_id);
CREATE INDEX IF NOT EXISTS idx_team_members_employee ON team_members(employee_id);

COMMENT ON TABLE team_members IS 'Membros das equipes';

-- ============================================================================
-- PARTE 5: Criar tabela ACTIVITY_WORK_LOGS
-- ============================================================================

CREATE TABLE IF NOT EXISTS activity_work_logs (
    id SERIAL PRIMARY KEY,  -- INTEGER PRIMARY KEY AUTOINCREMENT no SQLite
    
    -- Referência à atividade (polimórfica)
    activity_type VARCHAR(20) NOT NULL,  -- 'project' ou 'process'
    activity_id INTEGER NOT NULL,
    
    -- Quem trabalhou
    employee_id INTEGER NOT NULL,
    employee_name VARCHAR(200),  -- Cache para histórico
    
    -- Detalhes do trabalho
    work_date DATE NOT NULL,
    hours_worked DECIMAL(5,2) NOT NULL,  -- Ex: 2.5 = 2h 30min
    description TEXT,
    
    -- Auditoria
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CHECK (activity_type IN ('project', 'process')),
    CHECK (hours_worked > 0 AND hours_worked <= 24)
);

CREATE INDEX IF NOT EXISTS idx_work_logs_activity ON activity_work_logs(activity_type, activity_id);
CREATE INDEX IF NOT EXISTS idx_work_logs_employee ON activity_work_logs(employee_id);
CREATE INDEX IF NOT EXISTS idx_work_logs_date ON activity_work_logs(work_date);

COMMENT ON TABLE activity_work_logs IS 'Registro detalhado de horas trabalhadas';

-- ============================================================================
-- PARTE 6: Criar tabela ACTIVITY_COMMENTS
-- ============================================================================

CREATE TABLE IF NOT EXISTS activity_comments (
    id SERIAL PRIMARY KEY,  -- INTEGER PRIMARY KEY AUTOINCREMENT no SQLite
    
    -- Referência à atividade (polimórfica)
    activity_type VARCHAR(20) NOT NULL,  -- 'project' ou 'process'
    activity_id INTEGER NOT NULL,
    
    -- Autor
    employee_id INTEGER NOT NULL,
    employee_name VARCHAR(200),  -- Cache
    
    -- Conteúdo
    comment_type VARCHAR(20),  -- 'note', 'progress', 'issue', 'solution', 'question'
    comment_text TEXT NOT NULL,
    is_private BOOLEAN DEFAULT FALSE,
    
    -- Auditoria
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CHECK (activity_type IN ('project', 'process'))
);

CREATE INDEX IF NOT EXISTS idx_comments_activity ON activity_comments(activity_type, activity_id);
CREATE INDEX IF NOT EXISTS idx_comments_employee ON activity_comments(employee_id);
CREATE INDEX IF NOT EXISTS idx_comments_created ON activity_comments(created_at DESC);

COMMENT ON TABLE activity_comments IS 'Comentários e anotações em atividades';

-- ============================================================================
-- PARTE 7: Função/Trigger para atualizar worked_hours automaticamente
-- ============================================================================

-- PostgreSQL: Trigger para recalcular worked_hours quando um log é adicionado
CREATE OR REPLACE FUNCTION update_activity_worked_hours()
RETURNS TRIGGER AS $$
BEGIN
    -- Atualizar company_projects
    IF NEW.activity_type = 'project' THEN
        UPDATE company_projects 
        SET worked_hours = (
            SELECT COALESCE(SUM(hours_worked), 0) 
            FROM activity_work_logs 
            WHERE activity_type = 'project' AND activity_id = NEW.activity_id
        )
        WHERE id = NEW.activity_id;
    
    -- Atualizar process_instances
    ELSIF NEW.activity_type = 'process' THEN
        UPDATE process_instances 
        SET actual_hours = (
            SELECT COALESCE(SUM(hours_worked), 0) 
            FROM activity_work_logs 
            WHERE activity_type = 'process' AND activity_id = NEW.activity_id
        )
        WHERE id = NEW.activity_id;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Criar trigger
DROP TRIGGER IF EXISTS trigger_update_worked_hours ON activity_work_logs;
CREATE TRIGGER trigger_update_worked_hours
AFTER INSERT ON activity_work_logs
FOR EACH ROW
EXECUTE FUNCTION update_activity_worked_hours();

-- ============================================================================
-- PARTE 8: Adicionar índices para performance
-- ============================================================================

-- Índices em company_projects
CREATE INDEX IF NOT EXISTS idx_company_projects_responsible ON company_projects(responsible_id);
CREATE INDEX IF NOT EXISTS idx_company_projects_executor ON company_projects(executor_id);
CREATE INDEX IF NOT EXISTS idx_company_projects_status ON company_projects(status);
CREATE INDEX IF NOT EXISTS idx_company_projects_priority ON company_projects(priority);
CREATE INDEX IF NOT EXISTS idx_company_projects_end_date ON company_projects(end_date);

-- ============================================================================
-- FIM DA MIGRAÇÃO
-- ============================================================================

-- Verificar tabelas criadas
SELECT 
    'Migração concluída!' as status,
    COUNT(*) as teams_count
FROM teams;

SELECT 
    'Campos adicionados!' as status,
    COUNT(*) as projects_with_hours
FROM company_projects
WHERE estimated_hours IS NOT NULL;

