﻿-- Implantacao do Negocio - Estruturas de apoio
CREATE TABLE IF NOT EXISTS plan_alignment_members (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(255),
    motivation TEXT,
    commitment TEXT,
    risk TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_alignment_agenda (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    action_title TEXT,
    owner_name TEXT,
    schedule_info TEXT,
    execution_info TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_alignment_principles (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    principle TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_alignment_overview (
    plan_id INTEGER PRIMARY KEY REFERENCES plans (id) ON DELETE CASCADE,
    shared_vision TEXT,
    financial_goals TEXT,
    decision_criteria JSONB DEFAULT '[]'::jsonb,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_alignment_project (
    plan_id INTEGER PRIMARY KEY REFERENCES plans (id) ON DELETE CASCADE,
    project_name TEXT,
    description TEXT,
    observations JSONB DEFAULT '[]'::jsonb,
    grv_project_id INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_implantation_dashboard (
    plan_id INTEGER PRIMARY KEY REFERENCES plans (id) ON DELETE CASCADE,
    hero_message TEXT,
    progress_message TEXT,
    general_note TEXT,
    general_details TEXT,
    next_focus TEXT,
    next_focus_details TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_implantation_phases (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    phase_key VARCHAR(50) NOT NULL,
    title TEXT,
    status VARCHAR(32) DEFAULT 'sem_registros',
    tagline TEXT,
    pulse TEXT,
    sections JSONB DEFAULT '[]'::jsonb,
    deliverables JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(plan_id, phase_key)
);

CREATE TABLE IF NOT EXISTS plan_implantation_checkpoints (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    status VARCHAR(32) DEFAULT 'upcoming',
    date_label TEXT,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_segments (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    audiences JSONB,
    differentials JSONB,
    evidences JSONB,
    personas JSONB,
    competitors_matrix JSONB,
    strategy JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_structures (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    area VARCHAR(120),
    block VARCHAR(120),
    item_type VARCHAR(50),
    description TEXT,
    value TEXT,
    repetition TEXT,
    payment_form TEXT,
    acquisition_info TEXT,
    availability_info TEXT,
    supplier TEXT,
    observations TEXT,
    status TEXT,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_structure_installments (
    id SERIAL PRIMARY KEY,
    structure_id INTEGER NOT NULL REFERENCES plan_structures (id) ON DELETE CASCADE,
    installment_number TEXT,
    amount TEXT,
    due_info TEXT,
    installment_type TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_finance_premises (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    suggestion TEXT,
    adjusted TEXT,
    observations TEXT,
    memory TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_finance_investments (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    amount TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_finance_sources (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    category TEXT,
    description TEXT NOT NULL,
    amount TEXT,
    availability TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_finance_business_periods (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    period_label TEXT NOT NULL,
    revenue TEXT,
    variables TEXT,
    contribution_margin TEXT,
    fixed_costs TEXT,
    operating_result TEXT,
    result_period TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_finance_business_distribution (
    id SERIAL PRIMARY KEY,
    period_id INTEGER NOT NULL REFERENCES plan_finance_business_periods (id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    amount TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_finance_variable_costs (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    percentage TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_finance_result_rules (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    percentage TEXT,
    periodicity TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_finance_investor_periods (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    period_label TEXT NOT NULL,
    contribution TEXT,
    distribution TEXT,
    balance TEXT,
    cumulative TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plan_finance_metrics (
    id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES plans (id) ON DELETE CASCADE,
    payback TEXT,
    tir TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(plan_id)
);
