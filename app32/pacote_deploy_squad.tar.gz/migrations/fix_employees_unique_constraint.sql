-- ============================================================================
-- Migration: Corrigir constraint UNIQUE em employees
-- Data: 2025-11-26
-- Objetivo: Permitir que um usuário tenha múltiplos vínculos (um por empresa)
-- ============================================================================
--
-- PROBLEMA:
-- A constraint atual idx_employees_user_unique impede que um usuário tenha
-- múltiplos registros de Employee (um por empresa), o que contradiz a
-- arquitetura que permite que um usuário trabalhe em múltiplas empresas.
--
-- SOLUÇÃO:
-- Remover constraint antiga (UNIQUE em user_id apenas)
-- Criar constraint correta (UNIQUE em user_id + company_id)
-- ============================================================================

-- 1. Remover constraint antiga (se existir)
DROP INDEX IF EXISTS idx_employees_user_unique;

-- 2. Criar constraint correta: UNIQUE(user_id, company_id)
-- Isso permite que um usuário tenha múltiplos vínculos, mas não duplicados na mesma empresa
CREATE UNIQUE INDEX IF NOT EXISTS idx_employees_user_company_unique 
ON employees(user_id, company_id) 
WHERE user_id IS NOT NULL;

-- 3. Manter índice simples para performance em queries por user_id
CREATE INDEX IF NOT EXISTS idx_employees_user_id 
ON employees(user_id) 
WHERE user_id IS NOT NULL;

-- ============================================================================
-- OBSERVAÇÕES
-- ============================================================================
-- 
-- - Agora um usuário pode ter múltiplos registros de Employee (um por empresa)
-- - A constraint garante que não haverá duplicatas: mesmo user + mesma empresa
-- - user_id pode ser NULL (funcionários sem acesso ao sistema)
-- - Compatível com PostgreSQL e SQLite
--
-- ============================================================================


