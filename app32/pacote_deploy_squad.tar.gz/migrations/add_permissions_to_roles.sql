-- Migration: Add permissions column to roles table
-- Executed on: 2026-02-22
ALTER TABLE roles ADD COLUMN IF NOT EXISTS permissions JSON;
