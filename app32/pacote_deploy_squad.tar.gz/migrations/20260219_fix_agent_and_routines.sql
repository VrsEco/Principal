-- Migration to fix routines.is_active type and add agent_actions.original_file
-- Date: 2026-02-19
-- Author: Antigravity

-- 1. Routines.is_active (Integer mismatch -> Boolean standard)
DO $$ 
BEGIN 
    IF (SELECT data_type FROM information_schema.columns WHERE table_name='routines' AND column_name='is_active') = 'integer' THEN 
        ALTER TABLE routines 
        ALTER COLUMN is_active DROP DEFAULT,
        ALTER COLUMN is_active TYPE BOOLEAN USING (CASE WHEN is_active=1 THEN TRUE ELSE FALSE END),
        ALTER COLUMN is_active SET DEFAULT TRUE;
    END IF;
END $$;

-- 2. Agent_actions.original_file (Missing column for Engineering Worker)
DO $$ 
BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='agent_actions' AND column_name='original_file') THEN 
        ALTER TABLE agent_actions ADD COLUMN original_file TEXT;
    END IF;
END $$;
