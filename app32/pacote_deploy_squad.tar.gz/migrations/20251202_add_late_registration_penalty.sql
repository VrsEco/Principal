BEGIN;

ALTER TABLE company_performance_settings
    ADD COLUMN IF NOT EXISTS late_registration_penalty NUMERIC(10,2) DEFAULT -1;

UPDATE company_performance_settings
SET late_registration_penalty = -1
WHERE late_registration_penalty IS NULL;

ALTER TABLE project_activities
    ADD COLUMN IF NOT EXISTS completion_recorded_at TIMESTAMP WITHOUT TIME ZONE;

ALTER TABLE process_instances
    ADD COLUMN IF NOT EXISTS completion_recorded_at TIMESTAMP WITHOUT TIME ZONE;

COMMIT;
























