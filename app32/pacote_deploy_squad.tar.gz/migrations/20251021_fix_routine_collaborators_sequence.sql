-- ============================================
-- Fix: Adicionar SEQUENCE para routine_collaborators.id
-- ============================================
-- Data: 2025-10-21
-- Descrição: A tabela routine_collaborators foi criada sem SERIAL,
--            causando erro ao tentar inserir registros (id=NULL)
-- ============================================

-- 1. Criar sequence para gerar IDs automaticamente
CREATE SEQUENCE IF NOT EXISTS routine_collaborators_id_seq;

-- 2. Definir o valor inicial da sequence baseado no maior ID existente
SELECT setval('routine_collaborators_id_seq', 
    COALESCE((SELECT MAX(id) FROM routine_collaborators), 0) + 1, 
    false
);

-- 3. Alterar a coluna id para usar a sequence como default
ALTER TABLE routine_collaborators 
    ALTER COLUMN id SET DEFAULT nextval('routine_collaborators_id_seq');

-- 4. Associar a sequence à coluna (para que seja deletada automaticamente se a tabela for deletada)
ALTER SEQUENCE routine_collaborators_id_seq OWNED BY routine_collaborators.id;

-- ============================================
-- Verificação (descomentar para testar):
-- ============================================
-- SELECT column_name, column_default, is_nullable, data_type
-- FROM information_schema.columns
-- WHERE table_name = 'routine_collaborators' AND column_name = 'id';
--
-- Resultado esperado:
-- column_name | column_default                              | is_nullable | data_type
-- ------------|---------------------------------------------|-------------|----------
-- id          | nextval('routine_collaborators_id_seq')     | NO          | integer

-- ============================================
-- Teste de inserção (descomentar para testar):
-- ============================================
-- INSERT INTO routine_collaborators (routine_id, employee_id, hours_used, notes)
-- VALUES (1, 1, 4.0, 'Teste')
-- RETURNING id;
-- 
-- Se funcionar, o INSERT retornará um id gerado automaticamente!

