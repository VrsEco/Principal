-- ============================================================================
-- Migration: Adicionar relacionamento User <-> Employee (SQLite)
-- Data: 2025-10-22
-- Objetivo: Permitir que employees tenham user_id para login no sistema
-- ============================================================================

-- SQLite não suporta ALTER TABLE ADD FOREIGN KEY diretamente
-- Mas podemos adicionar a coluna sem FK e criar índices

-- 1. Adicionar coluna user_id em employees
ALTER TABLE employees 
ADD COLUMN user_id INTEGER;

-- 2. Criar índice para performance
CREATE INDEX IF NOT EXISTS idx_employees_user ON employees(user_id);

-- 3. Garantir unicidade: um user só pode ser vinculado a um employee
CREATE UNIQUE INDEX IF NOT EXISTS idx_employees_user_unique ON employees(user_id) WHERE user_id IS NOT NULL;

-- ============================================================================
-- OBSERVAÇÕES
-- ============================================================================
-- 
-- - user_id é NULLABLE: nem todo employee precisa ter login
-- - SQLite não valida FK em ALTER TABLE, mas a aplicação deve garantir integridade
-- - Relacionamento 1:1 (um user = um employee)
-- - Após migration, executar script de vinculação para dados existentes
--
-- ============================================================================

