--
-- PostgreSQL database dump
--

\restrict NiU0xIOmm0AnNZcRBlchIh0fdrEWUe61yO37RfMCjavsMeu2bXF4NEmnqz71wkX

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: trg_company_projects_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_company_projects_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
                BEGIN
                    NEW.updated_at := CURRENT_TIMESTAMP;
                    RETURN NEW;
                END;
                $$;


ALTER FUNCTION public.trg_company_projects_updated_at() OWNER TO postgres;

--
-- Name: update_activity_worked_hours(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_activity_worked_hours() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                IF NEW.activity_type = 'project' THEN
                    UPDATE company_projects 
                    SET worked_hours = (
                        SELECT COALESCE(SUM(hours_worked), 0) 
                        FROM activity_work_logs 
                        WHERE activity_type = 'project' AND activity_id = NEW.activity_id
                    )
                    WHERE id = NEW.activity_id;
                
                ELSIF NEW.activity_type = 'process' THEN
                    UPDATE process_instances 
                    SET actual_hours = (
                        SELECT COALESCE(SUM(hours_worked), 0) 
                        FROM activity_work_logs 
                        WHERE activity_type = 'process' AND activity_id = NEW.activity_id
                    )
                    WHERE id = NEW.activity_id;
                END IF;
                
                RETURN NEW;
            END;
            $$;


ALTER FUNCTION public.update_activity_worked_hours() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity_comments (
    id integer NOT NULL,
    activity_type character varying(20) NOT NULL,
    activity_id integer NOT NULL,
    employee_id integer NOT NULL,
    employee_name character varying(200),
    comment_type character varying(20),
    comment_text text NOT NULL,
    is_private boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT activity_comments_activity_type_check CHECK (((activity_type)::text = ANY ((ARRAY['project'::character varying, 'process'::character varying])::text[])))
);


ALTER TABLE public.activity_comments OWNER TO postgres;

--
-- Name: activity_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activity_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_comments_id_seq OWNER TO postgres;

--
-- Name: activity_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activity_comments_id_seq OWNED BY public.activity_comments.id;


--
-- Name: activity_work_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity_work_logs (
    id integer NOT NULL,
    activity_type character varying(20) NOT NULL,
    activity_id integer NOT NULL,
    employee_id integer NOT NULL,
    employee_name character varying(200),
    work_date date NOT NULL,
    hours_worked numeric(5,2) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT activity_work_logs_activity_type_check CHECK (((activity_type)::text = ANY ((ARRAY['project'::character varying, 'process'::character varying])::text[]))),
    CONSTRAINT activity_work_logs_hours_worked_check CHECK (((hours_worked > (0)::numeric) AND (hours_worked <= (24)::numeric)))
);


ALTER TABLE public.activity_work_logs OWNER TO postgres;

--
-- Name: activity_work_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activity_work_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_work_logs_id_seq OWNER TO postgres;

--
-- Name: activity_work_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activity_work_logs_id_seq OWNED BY public.activity_work_logs.id;


--
-- Name: ai_agents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_agents (
    id text,
    name text NOT NULL,
    description text,
    version text DEFAULT '1.0'::text,
    status text DEFAULT 'active'::text,
    page text NOT NULL,
    section text NOT NULL,
    button_text text NOT NULL,
    required_data text,
    optional_data text,
    prompt_template text,
    format_type text DEFAULT 'markdown'::text,
    output_field text DEFAULT 'ai_insights'::text,
    response_template text,
    timeout integer DEFAULT 300,
    max_retries integer DEFAULT 3,
    execution_mode text DEFAULT 'sequential'::text,
    cache_enabled integer DEFAULT 1,
    created_at text NOT NULL,
    updated_at text NOT NULL
);


ALTER TABLE public.ai_agents OWNER TO postgres;

--
-- Name: alignment_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alignment_records (
    id integer NOT NULL,
    plan_id integer,
    topic text NOT NULL,
    description text NOT NULL,
    consensus text,
    priority text,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.alignment_records OWNER TO postgres;

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.companies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.companies_id_seq OWNER TO postgres;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    id integer DEFAULT nextval('public.companies_id_seq'::regclass) NOT NULL,
    name text NOT NULL,
    legal_name text,
    industry text,
    size text,
    description text,
    client_code text,
    mvv_mission text,
    mvv_vision text,
    mvv_values text,
    pev_config text,
    grv_config text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    logo_square text,
    logo_vertical text,
    logo_horizontal text,
    logo_banner text,
    cnpj text,
    coverage_physical text,
    coverage_online text,
    experience_total text,
    experience_segment text,
    cnaes text,
    headcount_strategic integer DEFAULT 0,
    headcount_tactical integer DEFAULT 0,
    headcount_operational integer DEFAULT 0,
    financial_total_revenue text,
    financial_total_margin text,
    city text,
    state text
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- Name: company_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.company_data_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.company_data_id_seq OWNER TO postgres;

--
-- Name: company_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_data (
    id integer DEFAULT nextval('public.company_data_id_seq'::regclass) NOT NULL,
    plan_id integer,
    trade_name text,
    legal_name text,
    cnpj text,
    coverage_physical text,
    coverage_online text,
    experience_total text,
    experience_segment text,
    cnaes text,
    mission text,
    vision text,
    company_values text,
    headcount_strategic integer DEFAULT 0,
    headcount_tactical integer DEFAULT 0,
    headcount_operational integer DEFAULT 0,
    financials text,
    financial_total_revenue text,
    financial_total_margin text,
    other_information text,
    process_map_file text,
    org_chart_file text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP,
    grv_mvv_in_use integer DEFAULT 0,
    ai_insights text,
    consultant_analysis text
);


ALTER TABLE public.company_data OWNER TO postgres;

--
-- Name: company_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.company_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.company_projects_id_seq OWNER TO postgres;

--
-- Name: company_projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_projects (
    id integer DEFAULT nextval('public.company_projects_id_seq'::regclass) NOT NULL,
    company_id integer NOT NULL,
    plan_id integer,
    title text NOT NULL,
    description text,
    status text,
    priority text,
    owner text,
    start_date date,
    end_date date,
    okr_area_ref text,
    activities text,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP,
    responsible_id integer,
    okr_reference text,
    indicator_reference text,
    code text,
    code_sequence integer,
    plan_type text,
    estimated_hours numeric(5,2) DEFAULT 0,
    worked_hours numeric(5,2) DEFAULT 0,
    executor_id integer
);


ALTER TABLE public.company_projects OWNER TO postgres;

--
-- Name: company_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_records (
    id integer NOT NULL,
    plan_id integer,
    participants text NOT NULL,
    consultants text NOT NULL,
    company_date date,
    bsc_financial text,
    bsc_commercial text,
    bsc_process text,
    bsc_learning text,
    tri_commercial text,
    tri_adm_fin text,
    tri_operational text,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.company_records OWNER TO postgres;

--
-- Name: directional_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.directional_records (
    id integer NOT NULL,
    plan_id integer,
    title text NOT NULL,
    description text NOT NULL,
    status text,
    owner text,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP,
    type text,
    priority text
);


ALTER TABLE public.directional_records OWNER TO postgres;

--
-- Name: drivers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.drivers (
    id integer NOT NULL,
    plan_id integer,
    title text NOT NULL,
    description text,
    status text,
    priority text,
    owner text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.drivers OWNER TO postgres;

--
-- Name: drivers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.drivers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.drivers_id_seq OWNER TO postgres;

--
-- Name: drivers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.drivers_id_seq OWNED BY public.drivers.id;


--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_id_seq OWNER TO postgres;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    id integer DEFAULT nextval('public.employees_id_seq'::regclass) NOT NULL,
    company_id integer NOT NULL,
    name text NOT NULL,
    email text,
    phone text,
    role_id integer,
    department text,
    hire_date text,
    status text,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP,
    weekly_hours real DEFAULT 40,
    whatsapp text,
    user_id integer
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- Name: COLUMN employees.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employees.user_id IS 'FK para users - Permite que colaborador tenha acesso ao sistema';


--
-- Name: indicator_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.indicator_data_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.indicator_data_id_seq OWNER TO postgres;

--
-- Name: indicator_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.indicator_data (
    id integer DEFAULT nextval('public.indicator_data_id_seq'::regclass) NOT NULL,
    company_id integer NOT NULL,
    goal_id integer NOT NULL,
    record_date date NOT NULL,
    value real NOT NULL,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.indicator_data OWNER TO postgres;

--
-- Name: indicator_goals_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.indicator_goals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.indicator_goals_id_seq OWNER TO postgres;

--
-- Name: indicator_goals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.indicator_goals (
    id integer DEFAULT nextval('public.indicator_goals_id_seq'::regclass) NOT NULL,
    company_id integer NOT NULL,
    indicator_id integer NOT NULL,
    code text NOT NULL,
    goal_value real NOT NULL,
    goal_date date NOT NULL,
    responsible_id integer,
    status text,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP,
    goal_type text,
    period_start date,
    period_end date,
    evaluation_basis text,
    okr_reference text,
    okr_reference_label text
);


ALTER TABLE public.indicator_goals OWNER TO postgres;

--
-- Name: indicator_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.indicator_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.indicator_groups_id_seq OWNER TO postgres;

--
-- Name: indicator_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.indicator_groups (
    id integer DEFAULT nextval('public.indicator_groups_id_seq'::regclass) NOT NULL,
    company_id integer NOT NULL,
    parent_id integer,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.indicator_groups OWNER TO postgres;

--
-- Name: indicators_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.indicators_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.indicators_id_seq OWNER TO postgres;

--
-- Name: indicators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.indicators (
    id integer DEFAULT nextval('public.indicators_id_seq'::regclass) NOT NULL,
    company_id integer NOT NULL,
    group_id integer,
    code text NOT NULL,
    name text NOT NULL,
    process_id integer,
    project_id integer,
    department_id integer,
    collaborators text,
    unit text,
    formula text,
    polarity text,
    data_source text,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP,
    okr_reference text,
    okr_reference_label text,
    plan_id text,
    okr_id integer,
    okr_level text
);


ALTER TABLE public.indicators OWNER TO postgres;

--
-- Name: interviews_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.interviews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.interviews_id_seq OWNER TO postgres;

--
-- Name: interviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.interviews (
    id integer DEFAULT nextval('public.interviews_id_seq'::regclass) NOT NULL,
    plan_id integer,
    participant_name text NOT NULL,
    consultant_name text NOT NULL,
    interview_date date,
    format text,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.interviews OWNER TO postgres;

--
-- Name: macro_processes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.macro_processes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.macro_processes_id_seq OWNER TO postgres;

--
-- Name: macro_processes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.macro_processes (
    id integer DEFAULT nextval('public.macro_processes_id_seq'::regclass) NOT NULL,
    company_id integer NOT NULL,
    area_id integer NOT NULL,
    name text NOT NULL,
    code text,
    owner text,
    description text,
    order_index integer DEFAULT 0,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.macro_processes OWNER TO postgres;

--
-- Name: market_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_records (
    id integer NOT NULL,
    plan_id integer,
    participants text NOT NULL,
    consultants text NOT NULL,
    market_date date,
    format text,
    global_context text,
    sector_context text,
    market_size text,
    growth_space text,
    threats text,
    consumer_behavior text,
    competition text,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.market_records OWNER TO postgres;

--
-- Name: meeting_agenda_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.meeting_agenda_items (
    id integer NOT NULL,
    company_id integer NOT NULL,
    title text NOT NULL,
    description text,
    usage_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.meeting_agenda_items OWNER TO postgres;

--
-- Name: meeting_agenda_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.meeting_agenda_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.meeting_agenda_items_id_seq OWNER TO postgres;

--
-- Name: meeting_agenda_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.meeting_agenda_items_id_seq OWNED BY public.meeting_agenda_items.id;


--
-- Name: meetings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.meetings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.meetings_id_seq OWNER TO postgres;

--
-- Name: meetings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.meetings (
    id integer DEFAULT nextval('public.meetings_id_seq'::regclass) NOT NULL,
    company_id integer NOT NULL,
    project_id integer,
    title text NOT NULL,
    scheduled_date date,
    scheduled_time text,
    invite_notes text,
    meeting_notes text,
    guests_json text,
    agenda_json text,
    participants_json text,
    discussions_json text,
    activities_json text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    actual_date date,
    actual_time text,
    status text
);


ALTER TABLE public.meetings OWNER TO postgres;

--
-- Name: misalignment_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.misalignment_records (
    id integer NOT NULL,
    plan_id integer,
    issue text NOT NULL,
    description text NOT NULL,
    severity text,
    impact text,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.misalignment_records OWNER TO postgres;

--
-- Name: occurrences_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.occurrences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.occurrences_id_seq OWNER TO postgres;

--
-- Name: occurrences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.occurrences (
    id integer DEFAULT nextval('public.occurrences_id_seq'::regclass) NOT NULL,
    company_id integer NOT NULL,
    employee_id integer NOT NULL,
    process_id integer,
    project_id integer,
    title text NOT NULL,
    description text,
    type text NOT NULL,
    score integer DEFAULT 0,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.occurrences OWNER TO postgres;

--
-- Name: okr_area_preliminary_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.okr_area_preliminary_records (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    analysis text NOT NULL,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.okr_area_preliminary_records OWNER TO postgres;

--
-- Name: okr_area_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.okr_area_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.okr_area_records_id_seq OWNER TO postgres;

--
-- Name: okr_area_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.okr_area_records (
    id integer DEFAULT nextval('public.okr_area_records_id_seq'::regclass) NOT NULL,
    plan_id integer NOT NULL,
    stage text NOT NULL,
    objective text NOT NULL,
    okr_type text NOT NULL,
    type_display text,
    department text,
    owner_id integer,
    owner text,
    deadline text,
    observations text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.okr_area_records OWNER TO postgres;

--
-- Name: okr_global_key_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.okr_global_key_results (
    id integer NOT NULL,
    okr_id integer NOT NULL,
    label text NOT NULL,
    target text,
    deadline text,
    owner text,
    "position" integer DEFAULT 0,
    created_at time without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at time without time zone DEFAULT CURRENT_TIMESTAMP,
    owner_id integer,
    indicator_id integer
);


ALTER TABLE public.okr_global_key_results OWNER TO postgres;

--
-- Name: okr_global_key_results_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.okr_global_key_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.okr_global_key_results_id_seq OWNER TO postgres;

--
-- Name: okr_global_key_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.okr_global_key_results_id_seq OWNED BY public.okr_global_key_results.id;


--
-- Name: okr_global_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.okr_global_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.okr_global_records_id_seq OWNER TO postgres;

--
-- Name: okr_global_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.okr_global_records (
    id integer DEFAULT nextval('public.okr_global_records_id_seq'::regclass) NOT NULL,
    plan_id integer NOT NULL,
    stage text NOT NULL,
    objective text NOT NULL,
    okr_type text NOT NULL,
    type_display text,
    owner text,
    deadline text,
    observations text,
    directional text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP,
    owner_id integer
);


ALTER TABLE public.okr_global_records OWNER TO postgres;

--
-- Name: okr_preliminary_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.okr_preliminary_records (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    analysis text NOT NULL,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.okr_preliminary_records OWNER TO postgres;

--
-- Name: okrs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.okrs (
    id integer NOT NULL,
    plan_id integer,
    title text NOT NULL,
    description text,
    type text,
    area text,
    status text DEFAULT 'draft'::text,
    created_at time without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at time without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.okrs OWNER TO postgres;

--
-- Name: okrs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.okrs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.okrs_id_seq OWNER TO postgres;

--
-- Name: okrs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.okrs_id_seq OWNED BY public.okrs.id;


--
-- Name: participants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.participants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.participants_id_seq OWNER TO postgres;

--
-- Name: participants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.participants (
    id integer DEFAULT nextval('public.participants_id_seq'::regclass) NOT NULL,
    plan_id integer,
    name text NOT NULL,
    role text,
    relation text,
    email text,
    cpf text,
    phone text,
    status text,
    email_confirmed boolean DEFAULT false,
    whatsapp_confirmed boolean DEFAULT false,
    message_sent boolean DEFAULT false,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text,
    employee_id integer
);


ALTER TABLE public.participants OWNER TO postgres;

--
-- Name: plan_alignment_agenda; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_alignment_agenda (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    action_title text,
    owner_name text,
    schedule_info text,
    execution_info text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_alignment_agenda OWNER TO postgres;

--
-- Name: plan_alignment_agenda_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_alignment_agenda_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_alignment_agenda_id_seq OWNER TO postgres;

--
-- Name: plan_alignment_agenda_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_alignment_agenda_id_seq OWNED BY public.plan_alignment_agenda.id;


--
-- Name: plan_alignment_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_alignment_members (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    name character varying(255) NOT NULL,
    role character varying(255),
    motivation text,
    commitment text,
    risk text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_alignment_members OWNER TO postgres;

--
-- Name: plan_alignment_members_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_alignment_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_alignment_members_id_seq OWNER TO postgres;

--
-- Name: plan_alignment_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_alignment_members_id_seq OWNED BY public.plan_alignment_members.id;


--
-- Name: plan_alignment_overview; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_alignment_overview (
    plan_id integer NOT NULL,
    shared_vision text,
    financial_goals text,
    decision_criteria jsonb DEFAULT '[]'::jsonb,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_alignment_overview OWNER TO postgres;

--
-- Name: plan_alignment_principles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_alignment_principles (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    principle text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_alignment_principles OWNER TO postgres;

--
-- Name: plan_alignment_principles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_alignment_principles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_alignment_principles_id_seq OWNER TO postgres;

--
-- Name: plan_alignment_principles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_alignment_principles_id_seq OWNED BY public.plan_alignment_principles.id;


--
-- Name: plan_alignment_project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_alignment_project (
    plan_id integer NOT NULL,
    project_name text,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_alignment_project OWNER TO postgres;

--
-- Name: plan_finance_business_distribution; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_finance_business_distribution (
    id integer NOT NULL,
    period_id integer NOT NULL,
    description text NOT NULL,
    amount text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_finance_business_distribution OWNER TO postgres;

--
-- Name: plan_finance_business_distribution_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_finance_business_distribution_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_finance_business_distribution_id_seq OWNER TO postgres;

--
-- Name: plan_finance_business_distribution_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_finance_business_distribution_id_seq OWNED BY public.plan_finance_business_distribution.id;


--
-- Name: plan_finance_business_periods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_finance_business_periods (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    period_label text NOT NULL,
    revenue text,
    variables text,
    contribution_margin text,
    fixed_costs text,
    operating_result text,
    result_period text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_finance_business_periods OWNER TO postgres;

--
-- Name: plan_finance_business_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_finance_business_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_finance_business_periods_id_seq OWNER TO postgres;

--
-- Name: plan_finance_business_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_finance_business_periods_id_seq OWNED BY public.plan_finance_business_periods.id;


--
-- Name: plan_finance_funding_sources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_finance_funding_sources (
    id integer NOT NULL,
    plan_id integer,
    source_type character varying(100),
    contribution_date date NOT NULL,
    amount numeric(15,2) NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_finance_funding_sources OWNER TO postgres;

--
-- Name: plan_finance_funding_sources_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_finance_funding_sources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_finance_funding_sources_id_seq OWNER TO postgres;

--
-- Name: plan_finance_funding_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_finance_funding_sources_id_seq OWNED BY public.plan_finance_funding_sources.id;


--
-- Name: plan_finance_investment_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_finance_investment_categories (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    category_type character varying(50),
    category_name character varying(100),
    display_order integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_finance_investment_categories OWNER TO postgres;

--
-- Name: plan_finance_investment_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_finance_investment_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_finance_investment_categories_id_seq OWNER TO postgres;

--
-- Name: plan_finance_investment_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_finance_investment_categories_id_seq OWNED BY public.plan_finance_investment_categories.id;


--
-- Name: plan_finance_investment_contributions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_finance_investment_contributions (
    id integer NOT NULL,
    item_id integer,
    contribution_date date CONSTRAINT plan_finance_investment_contribution_contribution_date_not_null NOT NULL,
    amount numeric(15,2) NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    description character varying(255),
    system_suggestion numeric(15,2),
    adjusted_value numeric(15,2),
    calculation_memo text
);


ALTER TABLE public.plan_finance_investment_contributions OWNER TO postgres;

--
-- Name: plan_finance_investment_contributions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_finance_investment_contributions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_finance_investment_contributions_id_seq OWNER TO postgres;

--
-- Name: plan_finance_investment_contributions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_finance_investment_contributions_id_seq OWNED BY public.plan_finance_investment_contributions.id;


--
-- Name: plan_finance_investment_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_finance_investment_items (
    id integer NOT NULL,
    category_id integer,
    item_name character varying(100),
    display_order integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_finance_investment_items OWNER TO postgres;

--
-- Name: plan_finance_investment_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_finance_investment_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_finance_investment_items_id_seq OWNER TO postgres;

--
-- Name: plan_finance_investment_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_finance_investment_items_id_seq OWNED BY public.plan_finance_investment_items.id;


--
-- Name: plan_finance_investments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_finance_investments (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    description text NOT NULL,
    amount text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_finance_investments OWNER TO postgres;

--
-- Name: plan_finance_investments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_finance_investments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_finance_investments_id_seq OWNER TO postgres;

--
-- Name: plan_finance_investments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_finance_investments_id_seq OWNED BY public.plan_finance_investments.id;


--
-- Name: plan_finance_investor_periods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_finance_investor_periods (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    period_label text NOT NULL,
    contribution text,
    distribution text,
    balance text,
    cumulative text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_finance_investor_periods OWNER TO postgres;

--
-- Name: plan_finance_investor_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_finance_investor_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_finance_investor_periods_id_seq OWNER TO postgres;

--
-- Name: plan_finance_investor_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_finance_investor_periods_id_seq OWNED BY public.plan_finance_investor_periods.id;


--
-- Name: plan_finance_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_finance_metrics (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    payback text,
    tir text,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_finance_metrics OWNER TO postgres;

--
-- Name: plan_finance_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_finance_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_finance_metrics_id_seq OWNER TO postgres;

--
-- Name: plan_finance_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_finance_metrics_id_seq OWNED BY public.plan_finance_metrics.id;


--
-- Name: plan_finance_premises; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_finance_premises (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    description text NOT NULL,
    suggestion text,
    adjusted text,
    observations text,
    memory text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_finance_premises OWNER TO postgres;

--
-- Name: plan_finance_premises_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_finance_premises_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_finance_premises_id_seq OWNER TO postgres;

--
-- Name: plan_finance_premises_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_finance_premises_id_seq OWNED BY public.plan_finance_premises.id;


--
-- Name: plan_finance_profit_distribution; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_finance_profit_distribution (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    percentage text,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    start_date date
);


ALTER TABLE public.plan_finance_profit_distribution OWNER TO postgres;

--
-- Name: plan_finance_profit_distribution_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_finance_profit_distribution_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_finance_profit_distribution_id_seq OWNER TO postgres;

--
-- Name: plan_finance_profit_distribution_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_finance_profit_distribution_id_seq OWNED BY public.plan_finance_profit_distribution.id;


--
-- Name: plan_finance_result_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_finance_result_rules (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    description text NOT NULL,
    percentage text,
    periodicity text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_finance_result_rules OWNER TO postgres;

--
-- Name: plan_finance_result_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_finance_result_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_finance_result_rules_id_seq OWNER TO postgres;

--
-- Name: plan_finance_result_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_finance_result_rules_id_seq OWNED BY public.plan_finance_result_rules.id;


--
-- Name: plan_finance_sources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_finance_sources (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    category text,
    description text NOT NULL,
    amount text,
    availability text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_finance_sources OWNER TO postgres;

--
-- Name: plan_finance_sources_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_finance_sources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_finance_sources_id_seq OWNER TO postgres;

--
-- Name: plan_finance_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_finance_sources_id_seq OWNED BY public.plan_finance_sources.id;


--
-- Name: plan_finance_variable_costs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_finance_variable_costs (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    description text NOT NULL,
    percentage text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_finance_variable_costs OWNER TO postgres;

--
-- Name: plan_finance_variable_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_finance_variable_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_finance_variable_costs_id_seq OWNER TO postgres;

--
-- Name: plan_finance_variable_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_finance_variable_costs_id_seq OWNED BY public.plan_finance_variable_costs.id;


--
-- Name: plan_implantation_checkpoints; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_implantation_checkpoints (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    title text NOT NULL,
    status character varying(32) DEFAULT 'upcoming'::character varying,
    date_label text,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_implantation_checkpoints OWNER TO postgres;

--
-- Name: plan_implantation_checkpoints_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_implantation_checkpoints_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_implantation_checkpoints_id_seq OWNER TO postgres;

--
-- Name: plan_implantation_checkpoints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_implantation_checkpoints_id_seq OWNED BY public.plan_implantation_checkpoints.id;


--
-- Name: plan_implantation_dashboard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_implantation_dashboard (
    plan_id integer NOT NULL,
    hero_message text,
    progress_message text,
    general_note text,
    general_details text,
    next_focus text,
    next_focus_details text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_implantation_dashboard OWNER TO postgres;

--
-- Name: plan_implantation_phases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_implantation_phases (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    phase_key character varying(50) NOT NULL,
    title text,
    status character varying(32) DEFAULT 'sem_registros'::character varying,
    tagline text,
    pulse text,
    sections jsonb DEFAULT '[]'::jsonb,
    deliverables jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_implantation_phases OWNER TO postgres;

--
-- Name: plan_implantation_phases_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_implantation_phases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_implantation_phases_id_seq OWNER TO postgres;

--
-- Name: plan_implantation_phases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_implantation_phases_id_seq OWNED BY public.plan_implantation_phases.id;


--
-- Name: plan_products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_products (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    sale_price numeric(15,2) NOT NULL,
    sale_price_notes text,
    variable_costs_percent numeric(5,2),
    variable_costs_value numeric(15,2),
    variable_costs_notes text,
    variable_expenses_percent numeric(5,2),
    variable_expenses_value numeric(15,2),
    variable_expenses_notes text,
    unit_contribution_margin_percent numeric(5,2),
    unit_contribution_margin_value numeric(15,2),
    unit_contribution_margin_notes text,
    market_size_monthly_units numeric(15,2),
    market_size_monthly_revenue numeric(15,2),
    market_size_notes text,
    market_share_goal_monthly_units numeric(15,2),
    market_share_goal_percent numeric(5,2),
    market_share_goal_notes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    is_deleted boolean NOT NULL
);


ALTER TABLE public.plan_products OWNER TO postgres;

--
-- Name: plan_products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_products_id_seq OWNER TO postgres;

--
-- Name: plan_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_products_id_seq OWNED BY public.plan_products.id;


--
-- Name: plan_sections_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_sections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_sections_id_seq OWNER TO postgres;

--
-- Name: plan_sections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_sections (
    id integer DEFAULT nextval('public.plan_sections_id_seq'::regclass) NOT NULL,
    plan_id integer,
    section_name text NOT NULL,
    status text,
    closed_by text,
    closed_at text,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP,
    adjustments text
);


ALTER TABLE public.plan_sections OWNER TO postgres;

--
-- Name: plan_segments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_segments (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    audiences jsonb,
    differentials jsonb,
    evidences jsonb,
    personas jsonb,
    competitors_matrix jsonb,
    strategy jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_segments OWNER TO postgres;

--
-- Name: plan_segments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_segments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_segments_id_seq OWNER TO postgres;

--
-- Name: plan_segments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_segments_id_seq OWNED BY public.plan_segments.id;


--
-- Name: plan_structure_capacities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_structure_capacities (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    area character varying(120) NOT NULL,
    revenue_capacity text,
    observations text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_structure_capacities OWNER TO postgres;

--
-- Name: plan_structure_capacities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_structure_capacities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_structure_capacities_id_seq OWNER TO postgres;

--
-- Name: plan_structure_capacities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_structure_capacities_id_seq OWNED BY public.plan_structure_capacities.id;


--
-- Name: plan_structure_installments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_structure_installments (
    id integer NOT NULL,
    structure_id integer NOT NULL,
    installment_number text,
    amount text,
    due_info text,
    installment_type text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    classification text,
    repetition text
);


ALTER TABLE public.plan_structure_installments OWNER TO postgres;

--
-- Name: plan_structure_installments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_structure_installments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_structure_installments_id_seq OWNER TO postgres;

--
-- Name: plan_structure_installments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_structure_installments_id_seq OWNED BY public.plan_structure_installments.id;


--
-- Name: plan_structures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_structures (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    area character varying(120),
    block character varying(120),
    item_type character varying(50),
    description text,
    value text,
    repetition text,
    payment_form text,
    acquisition_info text,
    availability_info text,
    supplier text,
    observations text,
    status text,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plan_structures OWNER TO postgres;

--
-- Name: plan_structures_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_structures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_structures_id_seq OWNER TO postgres;

--
-- Name: plan_structures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_structures_id_seq OWNED BY public.plan_structures.id;


--
-- Name: plans_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plans_id_seq OWNER TO postgres;

--
-- Name: plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plans (
    id integer DEFAULT nextval('public.plans_id_seq'::regclass) NOT NULL,
    company_id integer,
    name text NOT NULL,
    description text,
    start_date date,
    end_date date,
    year integer,
    status text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    plan_mode character varying(32) DEFAULT 'evolucao'::character varying,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.plans OWNER TO postgres;

--
-- Name: portfolios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.portfolios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.portfolios_id_seq OWNER TO postgres;

--
-- Name: portfolios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.portfolios (
    id integer DEFAULT nextval('public.portfolios_id_seq'::regclass) NOT NULL,
    company_id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    responsible_id integer,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.portfolios OWNER TO postgres;

--
-- Name: process_activities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.process_activities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.process_activities_id_seq OWNER TO postgres;

--
-- Name: process_activities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.process_activities (
    id integer DEFAULT nextval('public.process_activities_id_seq'::regclass) NOT NULL,
    process_id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    layout text,
    order_index integer DEFAULT 0,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.process_activities OWNER TO postgres;

--
-- Name: process_activity_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.process_activity_entries (
    id integer NOT NULL,
    activity_id integer NOT NULL,
    order_index integer DEFAULT 0,
    text_content text,
    image_path text,
    image_width integer DEFAULT 280,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP,
    layout text
);


ALTER TABLE public.process_activity_entries OWNER TO postgres;

--
-- Name: process_areas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.process_areas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.process_areas_id_seq OWNER TO postgres;

--
-- Name: process_areas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.process_areas (
    id integer DEFAULT nextval('public.process_areas_id_seq'::regclass) NOT NULL,
    company_id integer NOT NULL,
    name text NOT NULL,
    code text,
    description text,
    order_index integer DEFAULT 0,
    color text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.process_areas OWNER TO postgres;

--
-- Name: process_instances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.process_instances (
    id integer NOT NULL,
    company_id integer NOT NULL,
    process_id integer NOT NULL,
    routine_id integer,
    instance_code text,
    title text NOT NULL,
    description text,
    status text,
    priority text,
    due_date timestamp without time zone,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    assigned_collaborators text,
    estimated_hours real,
    actual_hours real,
    notes text,
    metadata text,
    created_by text,
    trigger_type text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.process_instances OWNER TO postgres;

--
-- Name: processes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.processes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.processes_id_seq OWNER TO postgres;

--
-- Name: processes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.processes (
    id integer DEFAULT nextval('public.processes_id_seq'::regclass) NOT NULL,
    company_id integer NOT NULL,
    macro_id integer NOT NULL,
    name text NOT NULL,
    code text,
    structuring_level text,
    performance_level text,
    responsible text,
    description text,
    order_index integer DEFAULT 0,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP,
    kanban_stage text,
    flow_document text,
    notes text
);


ALTER TABLE public.processes OWNER TO postgres;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    plan_id integer,
    title text NOT NULL,
    description text,
    status text DEFAULT 'planned'::text,
    priority text,
    owner text,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    created_at time without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at time without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.projects_id_seq OWNER TO postgres;

--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: report_instances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report_instances (
    id integer NOT NULL,
    model_id integer,
    title character varying(255),
    report_type character varying(100),
    company_id integer,
    generated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    file_path text,
    status character varying(50) DEFAULT 'active'::character varying
);


ALTER TABLE public.report_instances OWNER TO postgres;

--
-- Name: report_instances_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.report_instances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.report_instances_id_seq OWNER TO postgres;

--
-- Name: report_instances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.report_instances_id_seq OWNED BY public.report_instances.id;


--
-- Name: report_models; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report_models (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    paper_size text,
    orientation text,
    margin_top integer DEFAULT 20,
    margin_right integer DEFAULT 15,
    margin_bottom integer DEFAULT 15,
    margin_left integer DEFAULT 20,
    header_height integer DEFAULT 25,
    header_rows integer DEFAULT 2,
    header_columns integer DEFAULT 3,
    header_content text,
    footer_height integer DEFAULT 12,
    footer_rows integer DEFAULT 1,
    footer_columns integer DEFAULT 2,
    footer_content text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by text
);


ALTER TABLE public.report_models OWNER TO postgres;

--
-- Name: report_patterns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report_patterns (
    id integer NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    description text,
    pattern_type text NOT NULL,
    sections_config text NOT NULL,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.report_patterns OWNER TO postgres;

--
-- Name: report_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report_templates (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    page_config_id integer NOT NULL,
    report_type text NOT NULL,
    sections_config text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by text
);


ALTER TABLE public.report_templates OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer DEFAULT nextval('public.roles_id_seq'::regclass) NOT NULL,
    company_id integer NOT NULL,
    title text NOT NULL,
    parent_role_id integer,
    reports_to text,
    department text,
    color text,
    headcount_planned integer DEFAULT 0,
    weekly_hours integer DEFAULT 40,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: routine_collaborators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.routine_collaborators (
    id integer NOT NULL,
    routine_id integer NOT NULL,
    employee_id integer NOT NULL,
    hours_used real NOT NULL,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.routine_collaborators OWNER TO postgres;

--
-- Name: routine_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.routine_tasks (
    id integer NOT NULL,
    routine_id integer NOT NULL,
    trigger_id integer NOT NULL,
    title text NOT NULL,
    description text,
    scheduled_date time without time zone NOT NULL,
    deadline_date time without time zone NOT NULL,
    status text DEFAULT 'pending'::text,
    completed_at time without time zone,
    completed_by text,
    notes text,
    created_at time without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at time without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.routine_tasks OWNER TO postgres;

--
-- Name: routine_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.routine_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.routine_tasks_id_seq OWNER TO postgres;

--
-- Name: routine_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.routine_tasks_id_seq OWNED BY public.routine_tasks.id;


--
-- Name: routine_triggers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.routine_triggers (
    id integer NOT NULL,
    routine_id integer NOT NULL,
    trigger_type text NOT NULL,
    trigger_value text NOT NULL,
    deadline_value integer NOT NULL,
    deadline_unit text NOT NULL,
    is_active integer DEFAULT 1,
    created_at time without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at time without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.routine_triggers OWNER TO postgres;

--
-- Name: routine_triggers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.routine_triggers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.routine_triggers_id_seq OWNER TO postgres;

--
-- Name: routine_triggers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.routine_triggers_id_seq OWNED BY public.routine_triggers.id;


--
-- Name: routines_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.routines_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.routines_id_seq OWNER TO postgres;

--
-- Name: routines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.routines (
    id integer DEFAULT nextval('public.routines_id_seq'::regclass) NOT NULL,
    company_id integer NOT NULL,
    name text NOT NULL,
    description text,
    is_active integer DEFAULT 1,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP,
    process_id integer,
    schedule_type text,
    schedule_value text,
    deadline_days integer,
    deadline_date text,
    deadline_hours integer DEFAULT 0
);


ALTER TABLE public.routines OWNER TO postgres;

--
-- Name: team_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_members (
    id integer NOT NULL,
    team_id integer NOT NULL,
    employee_id integer NOT NULL,
    role character varying(50) DEFAULT 'member'::character varying,
    joined_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    left_at timestamp without time zone
);


ALTER TABLE public.team_members OWNER TO postgres;

--
-- Name: team_members_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.team_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.team_members_id_seq OWNER TO postgres;

--
-- Name: team_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.team_members_id_seq OWNED BY public.team_members.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teams (
    id integer NOT NULL,
    company_id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    leader_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean DEFAULT true
);


ALTER TABLE public.teams OWNER TO postgres;

--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.teams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.teams_id_seq OWNER TO postgres;

--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- Name: user_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_logs (
    id integer NOT NULL,
    user_id integer,
    user_email text NOT NULL,
    user_name text NOT NULL,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text,
    entity_name text,
    old_values text,
    new_values text,
    ip_address text,
    user_agent text,
    endpoint text,
    method text,
    description text,
    company_id integer,
    plan_id text,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_logs OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer DEFAULT nextval('public.users_id_seq'::regclass) NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    name text NOT NULL,
    role text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: vision_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vision_records (
    id integer NOT NULL,
    plan_id integer,
    participants text NOT NULL,
    consultants text NOT NULL,
    vision_date date,
    format text,
    notes text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.vision_records OWNER TO postgres;

--
-- Name: workshop_discussions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.workshop_discussions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workshop_discussions_id_seq OWNER TO postgres;

--
-- Name: workshop_discussions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workshop_discussions (
    id integer DEFAULT nextval('public.workshop_discussions_id_seq'::regclass) NOT NULL,
    plan_id integer NOT NULL,
    section_type text NOT NULL,
    content text,
    created_at text DEFAULT CURRENT_TIMESTAMP,
    updated_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.workshop_discussions OWNER TO postgres;

--
-- Name: activity_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_comments ALTER COLUMN id SET DEFAULT nextval('public.activity_comments_id_seq'::regclass);


--
-- Name: activity_work_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_work_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_work_logs_id_seq'::regclass);


--
-- Name: drivers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.drivers ALTER COLUMN id SET DEFAULT nextval('public.drivers_id_seq'::regclass);


--
-- Name: meeting_agenda_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meeting_agenda_items ALTER COLUMN id SET DEFAULT nextval('public.meeting_agenda_items_id_seq'::regclass);


--
-- Name: okr_global_key_results id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.okr_global_key_results ALTER COLUMN id SET DEFAULT nextval('public.okr_global_key_results_id_seq'::regclass);


--
-- Name: okrs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.okrs ALTER COLUMN id SET DEFAULT nextval('public.okrs_id_seq'::regclass);


--
-- Name: plan_alignment_agenda id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_alignment_agenda ALTER COLUMN id SET DEFAULT nextval('public.plan_alignment_agenda_id_seq'::regclass);


--
-- Name: plan_alignment_members id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_alignment_members ALTER COLUMN id SET DEFAULT nextval('public.plan_alignment_members_id_seq'::regclass);


--
-- Name: plan_alignment_principles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_alignment_principles ALTER COLUMN id SET DEFAULT nextval('public.plan_alignment_principles_id_seq'::regclass);


--
-- Name: plan_finance_business_distribution id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_business_distribution ALTER COLUMN id SET DEFAULT nextval('public.plan_finance_business_distribution_id_seq'::regclass);


--
-- Name: plan_finance_business_periods id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_business_periods ALTER COLUMN id SET DEFAULT nextval('public.plan_finance_business_periods_id_seq'::regclass);


--
-- Name: plan_finance_funding_sources id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_funding_sources ALTER COLUMN id SET DEFAULT nextval('public.plan_finance_funding_sources_id_seq'::regclass);


--
-- Name: plan_finance_investment_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_investment_categories ALTER COLUMN id SET DEFAULT nextval('public.plan_finance_investment_categories_id_seq'::regclass);


--
-- Name: plan_finance_investment_contributions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_investment_contributions ALTER COLUMN id SET DEFAULT nextval('public.plan_finance_investment_contributions_id_seq'::regclass);


--
-- Name: plan_finance_investment_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_investment_items ALTER COLUMN id SET DEFAULT nextval('public.plan_finance_investment_items_id_seq'::regclass);


--
-- Name: plan_finance_investments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_investments ALTER COLUMN id SET DEFAULT nextval('public.plan_finance_investments_id_seq'::regclass);


--
-- Name: plan_finance_investor_periods id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_investor_periods ALTER COLUMN id SET DEFAULT nextval('public.plan_finance_investor_periods_id_seq'::regclass);


--
-- Name: plan_finance_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_metrics ALTER COLUMN id SET DEFAULT nextval('public.plan_finance_metrics_id_seq'::regclass);


--
-- Name: plan_finance_premises id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_premises ALTER COLUMN id SET DEFAULT nextval('public.plan_finance_premises_id_seq'::regclass);


--
-- Name: plan_finance_profit_distribution id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_profit_distribution ALTER COLUMN id SET DEFAULT nextval('public.plan_finance_profit_distribution_id_seq'::regclass);


--
-- Name: plan_finance_result_rules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_result_rules ALTER COLUMN id SET DEFAULT nextval('public.plan_finance_result_rules_id_seq'::regclass);


--
-- Name: plan_finance_sources id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_sources ALTER COLUMN id SET DEFAULT nextval('public.plan_finance_sources_id_seq'::regclass);


--
-- Name: plan_finance_variable_costs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_variable_costs ALTER COLUMN id SET DEFAULT nextval('public.plan_finance_variable_costs_id_seq'::regclass);


--
-- Name: plan_implantation_checkpoints id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_implantation_checkpoints ALTER COLUMN id SET DEFAULT nextval('public.plan_implantation_checkpoints_id_seq'::regclass);


--
-- Name: plan_implantation_phases id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_implantation_phases ALTER COLUMN id SET DEFAULT nextval('public.plan_implantation_phases_id_seq'::regclass);


--
-- Name: plan_products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_products ALTER COLUMN id SET DEFAULT nextval('public.plan_products_id_seq'::regclass);


--
-- Name: plan_segments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_segments ALTER COLUMN id SET DEFAULT nextval('public.plan_segments_id_seq'::regclass);


--
-- Name: plan_structure_capacities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_structure_capacities ALTER COLUMN id SET DEFAULT nextval('public.plan_structure_capacities_id_seq'::regclass);


--
-- Name: plan_structure_installments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_structure_installments ALTER COLUMN id SET DEFAULT nextval('public.plan_structure_installments_id_seq'::regclass);


--
-- Name: plan_structures id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_structures ALTER COLUMN id SET DEFAULT nextval('public.plan_structures_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: report_instances id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_instances ALTER COLUMN id SET DEFAULT nextval('public.report_instances_id_seq'::regclass);


--
-- Name: routine_tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routine_tasks ALTER COLUMN id SET DEFAULT nextval('public.routine_tasks_id_seq'::regclass);


--
-- Name: routine_triggers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routine_triggers ALTER COLUMN id SET DEFAULT nextval('public.routine_triggers_id_seq'::regclass);


--
-- Name: team_members id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_members ALTER COLUMN id SET DEFAULT nextval('public.team_members_id_seq'::regclass);


--
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- Data for Name: activity_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity_comments (id, activity_type, activity_id, employee_id, employee_name, comment_type, comment_text, is_private, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: activity_work_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity_work_logs (id, activity_type, activity_id, employee_id, employee_name, work_date, hours_worked, description, created_at) FROM stdin;
\.


--
-- Data for Name: ai_agents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_agents (id, name, description, version, status, page, section, button_text, required_data, optional_data, prompt_template, format_type, output_field, response_template, timeout, max_retries, execution_mode, cache_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alignment_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alignment_records (id, plan_id, topic, description, consensus, priority, notes, created_at, updated_at) FROM stdin;
1	5						2025-10-13 21:26:29	2025-10-13 21:26:29
2	5						2025-10-13 21:26:55	2025-10-13 21:26:55
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (id, name, legal_name, industry, size, description, client_code, mvv_mission, mvv_vision, mvv_values, pev_config, grv_config, created_at, logo_square, logo_vertical, logo_horizontal, logo_banner, cnpj, coverage_physical, coverage_online, experience_total, experience_segment, cnaes, headcount_strategic, headcount_tactical, headcount_operational, financial_total_revenue, financial_total_margin, city, state) FROM stdin;
5	Versus Gestao Corporativa	Versus Consultoria LTDA	Consultoria	Pequena	Teste	AA	Auxiliar os gestores e as organizações nas definições e no alcance dos seus objetivos.	Ser referência em gestão e organização nos mercados em que atuar.	Verdade, ética, respeito e valorização das parcerias.	\N	\N	2025-10-10 17:29:46	uploads/logos/company_5_square.png	uploads/logos/company_5_vertical.png	uploads/logos/company_5_horizontal.png	uploads/logos/company_5_banner.png	15028181000131	Nacional	Nacional	30	15	6201-05	0	0	0			Salvador	BA
13	Save Water	Stela Baptista Serviço e Comércio LTDA	Serviços	pequena	\N	AL	\N	\N	\N	\N	\N	2025-10-16 10:02:17	uploads/logos/company_13_square.png	uploads/logos/company_13_vertical.png	uploads/logos/company_13_horizontal.png	uploads/logos/company_13_banner.png	13.674.329/0002-60	Nacional	Sem presença	40	40	47.89-0-05	0	0	0	\N	\N	Salvador	BA
14	Gas Evolution	Evolution Gas LTDA	Comercio Varejista de Gas de Cozinha	pequena	\N	AB	\N	\N	\N	\N	\N	2025-10-16 15:22:33	\N	\N	\N	\N	50160903000108	Local	Sem presença	10	10	47.84-9-00, 49.30-2-03	0	0	0	\N	\N	Salvador	BA
15	Souto Costa Advogados Associados	Souto Costa Advogados Associados LTDA	Serviços Advocatícios	micro	\N	AI	\N	\N	\N	\N	\N	2025-10-16 22:53:32	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0	\N	\N	\N	\N
25	Eua - Moveis Planejados	Moveis EUA LTD	Movelaria	Pequena	Projeto criado para constituir e operacionalizar a empresa de móveis planejados nos EUA	AS	\N	\N	\N	\N	\N	2025-10-19 11:29:36.903094-03	\N	\N	\N	\N							0	0	0	\N	\N		
\.


--
-- Data for Name: company_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_data (id, plan_id, trade_name, legal_name, cnpj, coverage_physical, coverage_online, experience_total, experience_segment, cnaes, mission, vision, company_values, headcount_strategic, headcount_tactical, headcount_operational, financials, financial_total_revenue, financial_total_margin, other_information, process_map_file, org_chart_file, created_at, updated_at, grv_mvv_in_use, ai_insights, consultant_analysis) FROM stdin;
5	5								[]				0	0	0	[{"line": "Comercio", "revenue": 100000.0, "margin": 45.0, "market": ""}, {"line": "Servi\\u00e7os", "revenue": 200000.0, "margin": 55.0, "market": ""}]	300000.00	51.67				2025-10-13 21:07:27	2025-10-13 21:07:27	0		
\.


--
-- Data for Name: company_projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_projects (id, company_id, plan_id, title, description, status, priority, owner, start_date, end_date, okr_area_ref, activities, notes, created_at, updated_at, responsible_id, okr_reference, indicator_reference, code, code_sequence, plan_type, estimated_hours, worked_hours, executor_id) FROM stdin;
26	5	5	Projeto PEV	\N	planned	medium	\N	2025-01-01	2025-12-31	\N	[{"id": 1, "code": "AA.J.1.01", "what": "Definir escopo do projeto", "who": "Jo\\u00e3o Silva", "when": "2025-12-31", "how": "Reuni\\u00e3o com stakeholders", "amount": 5000, "observations": "Priorit\\u00e1rio", "stage": "completed", "status": "completed", "completion_date": "2025-10-11"}, {"id": 2, "code": "AA.J.1.02", "what": "Teste Calendario", "who": "Maria Santos", "when": "2025-06-13", "how": null, "amount": "8000", "observations": null, "stage": "inbox", "status": "pending", "completion_date": null, "logs": []}]	\N	2025-10-11 16:38:15	2025-10-11 18:26:29	\N	\N	\N	AA.J.1	1	PEV	0.00	0.00	\N
27	5	5	Projeto GRV	\N	planned	medium	\N	2025-01-01	2025-12-31	\N	\N	\N	2025-10-11 16:38:39	2025-10-11 16:38:39	\N	\N	\N	AA.J.2	2	GRV	0.00	0.00	\N
28	5	\N	Geral	Inclusão de Afazeres não catalogados e outras coisas	planned	medium	\N	\N	\N	\N	[{"id": 1, "code": "AA.J.3.01", "what": "Atividade Teste", "who": "Fabiano", "when": "2025-10-31", "how": "Teste Fabiano", "amount": "10000", "observations": "Teste", "stage": "inbox", "status": "inbox", "completion_date": "2025-10-11"}, {"id": 2, "code": "AA.J.3.02", "what": "Atividade 02", "who": "Fabiano", "when": "2025-12-31", "how": "Teste Fabiano", "amount": "100000", "observations": null, "stage": "executing", "status": "executing", "completion_date": null}]	\N	2025-10-11 16:52:27	2025-10-12 19:28:20	3	\N	\N	AA.J.3	3	\N	0.00	0.00	\N
29	5	\N	Pendências e Afazeres	Pendências cadastradas pelo usuário ou por outros colaboradores.	planned	medium	\N	\N	\N	\N	[{"id": 1, "code": "AA.J.4.01", "what": "Teste Atividade", "who": "Fabiano", "when": "2025-12-31", "how": "djkla\\u00e7sdfjl\\u00e7kfds jsdf jdsfa j\\u00e7kldasf jkl\\u00e7adfs jkl\\u00e7dfsadsfjkl\\u00e7 fads jkl\\u00e7", "amount": "1000", "observations": "teste", "stage": "completed", "status": "completed", "completion_date": "2025-10-11", "logs": [{"text": "Teste atividade 01ajkldf\\u00e7 dfsjklfdjkl \\u00e7dasfjkl\\u00e7 dasfjkl\\u00e7 dasfjkl\\u00e7 dfjk\\u00e7 ldfsjk\\u00e7 ldfsjkl\\u00e7 dfsjkl df\\u00e7sjk\\u00e7ldf sajk\\u00e7 lsdfjk\\u00e7 ldsfa\\u00e7 jkldsfa jk\\u00e7adsflf djkl\\u00e7sfd jkl\\u00e7ajk dl\\u00e7fdf\\u00e7asjkl dfsajk \\u00e7ldfsjkl \\u00e7dfas jkl\\u00e7dfsajkl\\u00e7 dsfajkl\\u00e7 dsfj kl\\u00e7dfjkl \\u00e7dsfajkl\\u00e7 adfsjkl\\u00e7 dfsjkl\\u00e7 dfadsfjl\\u00e7k fdjkl \\u00e7fdasjkl \\u00e7fdsajkl \\u00e7fsadjkl \\u00e7fadsjkl fdsajldfsa jkfadsjkl\\u00e7 fdsajkl\\u00e7fadsj klfdsajsklf\\u00e7ad\\u00e7dfjkla dfjkl\\u00e7sdfjkl\\u00e7df jkal\\u00e7dfjkl fadsjkl \\u00e7sf djkl\\u00e7fadsjkl fdsjkl dfs jklafdsjk l\\u00e7sdfjkl \\u00e7asfdjkl\\u00e7afdsjkl", "timestamp": "2025-10-11T17:22:56.096Z", "type": "manual"}, {"text": "teste 02 hjlkdjakldsfjlhk\\u00e7 dfsjkl\\u00e7fsaj lkfadjk\\u00e7fl adjkl\\u00e7fdjkdlfjk ldf\\u00e7ajkl\\u00e7 dfajdfkl\\u00e7 fdjkl\\u00e7 adjsfkl\\u00e7 dfsjkl \\u00e7fdljk \\u00e7dfjaadf jlk\\u00e7df jklfdsa jkl\\u00e7fdjkl\\u00e7 fdasjkl fdsjkl \\u00e7fdsajkl\\u00e7 fdsajkl \\u00e7fdjkl\\u00e7 adsfjkl\\u00e7 adfsjkl\\u00e7 dsfjkl\\u00e7 dfjkl\\u00e7 dfjkl\\u00e7 adsfjkl adfsjkl dffdajkl \\u00e7djkl\\u00e7 dfaadfjkl \\u00e7sdl\\u00e7fjk dfjkl\\u00e7 ljk dsfa\\u00e7fjkl\\u00e7 sdfjkl\\u00e7a dfasjkl \\u00e7dlfsjk dfjkl\\u00e7 \\u00e7lfadjk sl adsfjkdasfjkl \\u00e7dfasl\\u00e7 jkafdsjkl \\u00e7afdsl jk\\u00e7dfsljk \\u00e7adsfjkl\\u00e7 sd\\u00e7ljk adfsl\\u00e7jk dfsjkl adsf", "timestamp": "2025-10-11T17:23:13.910Z", "type": "manual"}, {"timestamp": "2025-10-11T17:23:27.838Z", "text": "Atividade conclu\\u00edda em 10/10/2025", "type": "completion", "date": "2025-10-11"}, {"timestamp": "2025-10-11T17:23:42.932Z", "text": "Conclus\\u00e3o cancelada em 10/10/2025", "type": "cancellation", "date": "2025-10-11"}, {"timestamp": "2025-10-11T17:23:53.678Z", "text": "Atividade conclu\\u00edda em 10/10/2025", "type": "completion", "date": "2025-10-11"}]}]	\N	2025-10-11 17:19:27	2025-10-11 17:23:53	\N	\N	\N	AA.J.4	4	\N	0.00	0.00	\N
31	5	\N	Reunião Reunião Teste - 2025.10.14	Projeto gerado automaticamente para a reunião: Reunião Teste	planned	medium	Fabiano Ferreira	2025-10-21	\N	\N	\N	Projeto vinculado à reunião "Reunião Teste"	2025-10-14 21:48:57	2025-10-14 21:48:57	\N	\N	\N	AA.J.6	6	\N	0.00	0.00	\N
33	13	8	2025.10.15 - Reunião Semanal Ordinária	\N	planned	high	\N	\N	\N	\N	\N	\N	2025-10-16 15:38:56	2025-10-16 15:38:56	\N	\N	\N	AL.J.1	1	GRV	0.00	0.00	\N
34	13	7	2025.10 - Reunião de Diretoria - Mensal	\N	planned	medium	\N	\N	\N	\N	\N	\N	2025-10-16 15:40:02	2025-10-16 15:40:02	\N	\N	\N	AL.J.2	2	GRV	0.00	0.00	\N
36	14	22	Pendências Fiscal	\N	planned	medium	\N	\N	\N	\N	\N	\N	2025-10-16 19:05:00	2025-10-16 21:21:41	22	\N	\N	AB.J.1	1	GRV	0.00	0.00	\N
39	14	22	Pendências Financeiro	\N	planned	medium	\N	\N	\N	\N	[{"id": 1, "code": "AB.J.2.01", "what": "Teste Fabiano 01", "who": "Fabiano", "when": "2026-01-01", "how": null, "amount": null, "observations": null, "stage": "pending", "status": "pending", "completion_date": null, "logs": []}, {"id": 2, "code": "AB.J.2.02", "what": "Teste Fabiano 02", "who": "Fabiano", "when": null, "how": null, "amount": null, "observations": null, "stage": "pending", "status": "pending", "completion_date": null, "logs": []}]	\N	2025-10-16 21:22:31	2025-10-17 02:09:46	22	\N	\N	AB.J.2	2	GRV	0.00	0.00	\N
40	14	22	Estruturação de Processos	\N	planned	high	\N	\N	\N	\N	[{"id": 1, "code": "AB.J.3.01", "what": "Senhas e Informa\\u00e7\\u00f5es Fiscais (Nivea)", "who": null, "when": null, "how": null, "amount": null, "observations": "<p>SENHA SIMPLES</p><p>G\\u00e1s no Bairro da Paz (s/certificado) - BAIRRO DA PAZ</p><p>Cod Simples: 295209356615</p><p>Senha Sefaz BA: GINALD1</p><p>cnpj:31232360000142</p><p>cpf socio: 04838909527 (Adriano)</p><p>Jeremias Santos Azevedo (s/certificado) - REAL GAS</p><p>Cod Simples: 957178456054</p><p>Senha Sefaz BA: empresa sem opera\\u00e7\\u00e3o / n\\u00e3o possui ainda!</p><p>CNPJ 40467079000180</p><p>cpf socio: 51367157587</p><p>Maria Aparecida dos Santos Cerqueira (s/certificado) - LIBERDADE</p><p>Cod Simples: 877461553479</p><p>Senha Sefaz BA: MARIA01</p><p>CNPJ&nbsp; 31065894000121</p><p>cpf socio:17666832826</p><p>Ramon J Mascarenhas de Souza G\\u00e1s (s/certificado)- BATE CORA\\u00c7\\u00c3O</p><p>Cod Simples: 043724964922</p><p>Senha Sefaz BA: RAMON01</p><p>CNPJ:31813011000114</p><p>cpf socio:85795920541</p><p>RB de Jesus Comercial de Gas (s/certificado) - PERNANBUES</p><p>Cod Simples: 840905656152</p><p>Senha Sefaz BA: rafa291</p><p>CNPJ: 32712090000154</p><p><img src=\\"https://gestaoversus.odoo.com/web/image/3880-2e949359/senha%20sefaz2.png?access_token=3fc09489-5b55-4479-b586-8da145170ed0\\"></p><p><strong>Empresas que Declaram e Quais n\\u00e3o Declaram:</strong><br>Geralmente a m\\u00e9dia de valor declara\\u00e7\\u00e3o \\u00e9 o da tabela abaixo, precisa fazer levantamento das unidades que tem maquineta, conta banc\\u00e1ria e etc para ver se os valores ainda condiz.&nbsp;A evolu\\u00e7\\u00e3o&nbsp;do gas&nbsp;(cabula) ta sem movimento pq antes estava no lucro presumido&nbsp;e foi enviado zerado, agora que ta no simples esse ano, n\\u00e3o sei se deve declarar algum valor aos poucos.&nbsp;</p><figure class=\\"table\\"><table><tbody><tr><td><strong>FANTASIA</strong></td><td><strong>RAZ\\u00c3O SOCIAL</strong></td><td><strong>CNPJ</strong></td><td><strong>FATURAMENTO</strong></td></tr><tr><td>GAS PAZ</td><td>GAS NO BAIRRO DA PAZ LTDA</td><td>31.232.360/0001-42</td><td>&nbsp;SEM MOVIMENTO&nbsp;</td></tr><tr><td>BATE CORACAO GAS</td><td>RAMON J MASCARENHAS DE SOUZA GAS</td><td>31.813.011/0001-14</td><td>&nbsp;SEM MOVIMENTO&nbsp;</td></tr><tr><td>EVOLUCAO DO GAS PERNAMBUES</td><td>RB DE JESUS COMERCIAL DE GAS EIREL</td><td>32.713.090/0001-54</td><td>&nbsp;SEM MOVIMENTO&nbsp;</td></tr><tr><td>RAMON GAS</td><td>V M RAMON GAS LTDA - ME</td><td>11.505.325/0001-42</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4.300,00</td></tr><tr><td>EVA GAS</td><td>EVA GAS LTDA</td><td>35.606.306/0001-70</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 25.050,00</td></tr><tr><td>MELHOR GAS</td><td>EVOLUCAO DO GAS AV PEIXE EIRELI</td><td>35.541.437/0001-17</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 52.800,00</td></tr><tr><td>REAL GAS</td><td>JEREMIAS SANTOS AZEVEDO</td><td>40.467.079/0001-80</td><td>&nbsp;SEM MOVIMENTO&nbsp;</td></tr><tr><td>EVOLUCAO DO GAS LIBERDADE</td><td>MARIA APARECIDA DOS SANTOS CERQUEIRA</td><td>31.065.894/0001-21</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 48.050,00</td></tr><tr><td>GAS SAN MARTINS</td><td>A G B COMERCIO VAREJISTA DE GAS LTDA</td><td>45.654.394/0001-30</td><td>SEM CERTIFICADO</td></tr><tr><td>GOL DE PLACA GAS</td><td>D.C. TEIXEIRA COMERCIO VAREJISTA DE GAS</td><td>38.109.107/0001-45</td><td>SEM CERTIFICADO</td></tr><tr><td>JRO COMERCIO DE GAS</td><td>JRO COMERCIO DE GAS LTDA</td><td>38.109.107/0001-45</td><td>&nbsp;SEM MOVIMENTO&nbsp;</td></tr><tr><td>EVOLUTION GAS - SIMOES FILHO</td><td>GAS EVOLUTION LTDA</td><td>50.160.903/0001-08</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 53.100,00</td></tr><tr><td>LINHA VERDE GAS</td><td>A TODO GAS COMERCIO GLP LTDA</td><td>33.889.917/0001-48</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 19.900,00</td></tr><tr><td>SAO TOME GAS</td><td>SAO TOME GAS EIRELI</td><td>31.088.749/0001-66</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8.100,00</td></tr><tr><td>TIAGO GAS</td><td>RT REVENDEDORA DE GAS EIRELI</td><td>26.652.963/0001-63</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8.200,00</td></tr><tr><td>EVOLU\\u00c7\\u00c3O DO GAS CABULA</td><td>EVOLU\\u00c7\\u00c3O DO GAS LTDA-ME</td><td>20.804.651/0001-41</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; SEM MOVIMENTO</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></tbody></table></figure>", "stage": "inbox", "status": "pending", "completion_date": null, "logs": []}, {"id": 2, "code": "AB.J.3.02", "what": "Divis\\u00e3o de Postos - Conferencia de Caixa", "who": "Fabiano", "when": null, "how": null, "amount": null, "observations": "<p><strong>Divis\\u00e3o feita por Azevedo em 12/09/2025:</strong></p><figure class=\\"table\\"><table><tbody><tr><td><i><strong>SANDRO</strong></i></td><td><i><strong>QUESIA</strong></i></td><td><i><strong>VICTOR</strong></i></td></tr><tr><td>Bairro da Paz</td><td>Av. Peixe</td><td>Constituinte</td></tr><tr><td>VM</td><td>Pau da Lima</td><td>Cabula</td></tr><tr><td>Paripe</td><td>San Martin</td><td>Cajazeiras</td></tr><tr><td>Bate Cora\\u00e7\\u00e3o</td><td>S\\u00e3o Tom\\u00e9</td><td>Plataforma</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>BR</td></tr></tbody></table></figure><p>&nbsp;</p>", "stage": "inbox", "status": "pending", "completion_date": null, "logs": []}, {"id": 3, "code": "AB.J.3.03", "what": "Lucro Real Gas Evolution", "who": "Fabiano", "when": null, "how": null, "amount": null, "observations": "<p><strong>2025.03.13</strong></p><ul><li>Nova identidade de Nivea est\\u00e1 prevista para segunda, dia 17/03/2025</li></ul><p><strong>2025.03.10</strong></p><ul><li>DBE deu pend\\u00eancia -&gt; nome de N\\u00edvea com diverg\\u00eancia entre nome de solteira e de casada.</li><li>Quarta, dia 12/03 ela tem um agendamento para corre\\u00e7\\u00e3o e ap\\u00f3s ir\\u00e1 retransmitir.&nbsp;</li></ul><p><strong>Atividades a Fazer:</strong></p><ul><li>Altera\\u00e7\\u00e3o Contratual incluindo uma atividade impedidtiva (ver qual ser\\u00e1);</li><li>Comunicar a exclus\\u00e3o;</li><li>Ir\\u00e1 valer a partir do primeiro dia \\u00fatil do m\\u00eas subsequente ap\\u00f3s a exclus\\u00e3o;</li><li>Transferir / Contratar 02 Funcion\\u00e1rios;</li><li>Contrato de Loca\\u00e7\\u00e3o tem que ser feito em nome da PJ e recolher o IRRF caso haja.</li><li>Na conta pessoa jur\\u00eddica tem que ser feito concilia\\u00e7\\u00e3o do que \\u00e9 vendido e do que \\u00e9 comprado com seus respectivos docs fiscais (NFe, etc);</li><li>Fazer planejamento tribut\\u00e1rio para entender por quanto cada filial ir\\u00e1 receber os itens;</li></ul><p><strong>Atividades Vedadas no Simples Nacional:</strong></p><ul><li>CNAE 4922-1/01 - Transporte rodovi\\u00e1rio coletivo de passageiros, sob regime de fretamento, intermunicipal, interestadual e internacional</li><li>CNAE 3511-5/01 - GERA\\u00c7\\u00c3O DE ENERGIA EL\\u00c9TRICA;</li><li>CNAE 4110-7/00 - INCORPORA\\u00c7\\u00c3O DE EMPREENDIMENTOS IMOBILI\\u00c1RIOS;</li><li>CNAE 6462-0/00 - HOLDINGS DE INSTITUI\\u00c7\\u00d5ES N\\u00c3O FINANCEIRAS;</li><li>CNAE 4929-9/04 - ORGANIZA\\u00c7\\u00c3O DE EXCURS\\u00d5ES EM VE\\u00cdCULOS RODOVI\\u00c1RIOS PR\\u00d3PRIOS, INTERMUNICIPAL, INTERESTADUAL E INTERNACIONAL;</li></ul><p>Ap\\u00f3s os estudos necess\\u00e1rios, sugiro a atividade:&nbsp;CNAE:&nbsp;<strong>4110-7/00 - INCORPORA\\u00c7\\u00c3O DE EMPREENDIMENTOS IMOBILI\\u00c1RIOS;</strong></p><p><strong>- Pessoa Jur\\u00eddica:</strong></p><ul><li>CNPJ: 50.160.903/0001-08</li><li>Sem Funcion\\u00e1rios</li><li>Alvar\\u00e1: Em renova\\u00e7\\u00e3o</li><li>ANP: OK</li><li>Bombeiros: Em renova\\u00e7\\u00e3o;</li><li>Munic\\u00edpio: Sim\\u00f5es Filho;</li><li>Empresa Optante Pelo Simples;</li><li>S\\u00f3cios: N\\u00edvea Fernanda (Unipessoal);</li><li>Conta corrente: Ita\\u00fa (Sendo usada para receber pix por ela);</li><li>Maquininha de Cart\\u00e3o (Tem mas nunca foi usada);</li></ul><p><strong>- Compras:</strong></p><ul><li>Desde 01/2024 -&gt; 139 compras com valor m\\u00e9dio de R$ 80.000,00 pra cada compra;</li><li>Em 02/2025 -&gt; 03 compras de 80 mil, 91 mil e 80 mil;</li><li>Em 03/2025 -&gt; 02 compras de 86 mil cada;</li></ul><p><strong>- Vendas:</strong></p><ul><li>Poucas vendas -&gt;&nbsp;M\\u00e9dia de R$ 50.000,00 por m\\u00eas;</li></ul><p>Aqui fica demonstrado um risco fiscal pelo passado/presente, pois as vendas n\\u00e3o cobrem nem 1/5 das compras.</p><p><strong>- A empresa vai para o nome de Azevedo, onde ele tem mais 04 empresas em seu nome:</strong></p><ul><li>Eva G\\u00e1s LTDA</li><li>&nbsp;<ul><li>Compras:</li><li>&nbsp;<ul><li>451.000,00</li></ul></li><li>Vendas:</li><li>&nbsp;<ul><li>25.000,00</li></ul></li></ul></li><li>Evolu\\u00e7\\u00e3o do G\\u00e1s (Av. Peixe);</li><li>&nbsp;<ul><li>Compras</li><li>&nbsp;<ul><li>615.000,00</li></ul></li><li>Vendas</li><li>&nbsp;<ul><li>50.000,00</li></ul></li></ul></li><li>Real G\\u00e1s;</li><li>&nbsp;<ul><li>Compras</li><li>&nbsp;<ul><li>&nbsp;</li></ul></li><li>Vendas</li><li>&nbsp;<ul><li>0,00</li></ul></li></ul></li><li>A Todo G\\u00e1s Com\\u00e9rcio de GLP;</li><li>&nbsp;<ul><li>Compras</li><li>&nbsp;<ul><li>1.120.000,00</li></ul></li><li>Vendas</li><li>&nbsp;<ul><li>20.000,00</li></ul></li></ul></li></ul>", "stage": "executing", "status": "executing", "completion_date": null, "logs": []}, {"id": 4, "code": "AB.J.3.04", "what": "Pend\\u00eancia IRPF Azevedo e CIDA", "who": null, "when": null, "how": null, "amount": null, "observations": null, "stage": "waiting", "status": "waiting", "completion_date": null, "logs": []}, {"id": 5, "code": "AB.J.3.05", "what": "Pend\\u00eancia Gas Evolution - Sim\\u00f5es Filho", "who": "Victor", "when": null, "how": null, "amount": null, "observations": "<p>De:&nbsp;<strong>Cadastro Economico SEFAZ PMSF</strong>&nbsp;&lt;<a href=\\"mailto:cadastroeconomico.sefaz@simoesfilho.ba.gov.br\\">cadastroeconomico.sefaz@simoesfilho.ba.gov.br</a>&gt;</p><p>Date: qui., 12 de jun. de 2025 \\u00e0s 12:08</p><p>Subject: Pend\\u00eancias Fiscais \\u2013 Cadastro Econ\\u00f4mico Prefeitura de Sim\\u00f5es Filho.</p><p>To: &lt;<a href=\\"mailto:advecont.nivea.gas@gmail.com\\">advecont.nivea.gas@gmail.com</a>&gt;</p><p><strong>Ol\\u00e1,&nbsp;</strong></p><figure class=\\"table\\"><table><tbody><tr><td>G\\u00c1S EVOLUTION LTDA!</td></tr><tr><td>&nbsp;</td></tr></tbody></table></figure><p>Somos do Cadastro Econ\\u00f4mico da Prefeitura de Sim\\u00f5es Filho. Identificamos o&nbsp;<strong>registro do protocolo na Junta Comercial da Bahia</strong>, n\\u00famero 258880228<strong>,&nbsp;referente \\u00e0&nbsp;sua empresa</strong>.</p><p>Caso precise de informa\\u00e7\\u00f5es, queira solicitar a ficha cadastral ou resolver pend\\u00eancias fiscais, entre em contato conosco pelo e-mail:&nbsp;<a href=\\"mailto:cadastroeconomico.sefaz@simoesfilho.ba.gov.br\\">cadastroeconomico.sefaz@simoesfilho.ba.gov.br</a>&nbsp;.</p><p>\\u00c9 importante que a regulariza\\u00e7\\u00e3o seja feita o quanto antes para evitar maiores complica\\u00e7\\u00f5es, como a inclus\\u00e3o do d\\u00e9bito em d\\u00edvida ativa. Caso j\\u00e1 tenha regularizado a pend\\u00eancia, por favor, desconsidere esta correspond\\u00eancia. Aguardamos seu contato e permanecemos \\u00e0 disposi\\u00e7\\u00e3o para eventuais esclarecimentos.&nbsp;</p><p>Se preferir n\\u00e3o receber mais comunicados por esse canal, basta bloquear essa comunica\\u00e7\\u00e3o.</p><p>Estamos \\u00e0 disposi\\u00e7\\u00e3o para ajud\\u00e1-lo!</p><p>Atenciosamente,</p><p><strong>Cadastro Econ\\u00f4mico - Prefeitura de Sim\\u00f5es Filho.</strong></p>", "stage": "executing", "status": "executing", "completion_date": null, "logs": []}, {"id": 6, "code": "AB.J.3.06", "what": "IPTU que precisam ser alterados para alvar\\u00e1", "who": "Victor", "when": null, "how": null, "amount": null, "observations": "<p><strong>-&gt; IPTU que precisam ser alterados para alvar\\u00e1:</strong><br>LISTA DE IPTU QUE PRECISAM MUDAR PARA COM\\u00c9RCIO, ALGUNS J\\u00c1 FORAM ALTERADOS E EST\\u00c3O COM OK, OS QUE TEM N\\u00c3O IDENTIFICADO \\u00c9 PQ N\\u00c3O LOCALIZEI, TEM QUE IR NA SEFAZ.&nbsp;</p><p>PARA ALTERAR PRECISA DE DOCUMENTO DO IMOVEL, CERTID\\u00c3O DE \\u00d4NUS OU CONTRATO, CONTA DA EMBASA E DOCUMENTO DO PROPRIET\\u00c1RIO.&nbsp;</p><p>LEMBRANDO QUE A MAIORIA DOS ESTABELECIMENTO TEM D\\u00cdVIDA DE IPTU.</p><figure class=\\"table\\"><table><tbody><tr><td><strong>RAZ\\u00c3O SOCIAL</strong></td><td><strong>TIPO</strong></td></tr><tr><td>AV PEIXE</td><td>N\\u00c3O IDENTIFICADO</td></tr><tr><td>BATE CORA\\u00c7\\u00c3O</td><td>CASA</td></tr><tr><td>MARIA APARECIDA- LIBERDADE</td><td>CASA</td></tr><tr><td>RB- PERNANBUES</td><td>TERRENO</td></tr><tr><td>RT</td><td>OK</td></tr><tr><td>S\\u00c3O TOME</td><td>OK</td></tr><tr><td>A TODO GAS</td><td>N\\u00c3O IDENTIFICADO</td></tr><tr><td><strong>VM</strong></td><td><strong>TERRENO</strong></td></tr><tr><td>EVA</td><td>OK</td></tr><tr><td>EVOLU\\u00c7\\u00c3O DO GAS</td><td>CASA</td></tr><tr><td>REAL GAS</td><td>OK</td></tr><tr><td>JRO</td><td>OK</td></tr><tr><td>GAS PAZ</td><td>CASA</td></tr><tr><td>JR</td><td>OK</td></tr><tr><td>GAS EVOLUTION</td><td>--</td></tr></tbody></table></figure><p><br>&nbsp;</p>", "stage": "inbox", "status": "pending", "completion_date": null, "logs": []}, {"id": 7, "code": "AB.J.3.07", "what": "Lembrete TFF", "who": "Fabiano", "when": "2025-10-25", "how": null, "amount": null, "observations": "<p><strong>-&gt; Lembrete TFF:</strong><br>GERALMENTE EM OUTUBRO TEM QUE ESCOLHER O PAGAMENTO DA COTA OU O PARCELAMENTO DO TFF. SEMPRE PARCELAM.&nbsp;</p>", "stage": "executing", "status": "executing", "completion_date": null, "logs": []}, {"id": 8, "code": "AB.J.3.08", "what": "Altera\\u00e7\\u00e3o VM", "who": "Fabiano", "when": null, "how": null, "amount": null, "observations": "<p><strong>2025.09.18</strong></p><h2>\\ud83d\\udccc Pend\\u00eancias identificadas</h2><h3>1. <strong>Faltou informar no Requerimento eletr\\u00f4nico o evento 051 (Consolida\\u00e7\\u00e3o)</strong></h3><p>O <strong>evento 051</strong> \\u00e9 o c\\u00f3digo usado quando se faz a <strong>consolida\\u00e7\\u00e3o do contrato social</strong> (ou seja, juntar todas as altera\\u00e7\\u00f5es em um documento \\u00fanico atualizado).</p><p>Voc\\u00ea provavelmente protocolou o instrumento de consolida\\u00e7\\u00e3o, mas no <strong>Requerimento Eletr\\u00f4nico (Integrador/REDESIM)</strong> n\\u00e3o marcou o evento correto.</p><p>\\u2705 Solu\\u00e7\\u00e3o: retificar o requerimento eletr\\u00f4nico, incluir o evento <strong>051</strong>, assinar novamente e reapresentar.</p><h3>2. <strong>Data de in\\u00edcio das atividades divergente</strong></h3><p>A <strong>data de in\\u00edcio das atividades</strong> que voc\\u00ea colocou na consolida\\u00e7\\u00e3o <strong>n\\u00e3o bate</strong> com a que j\\u00e1 est\\u00e1 registrada na JUCEB (na constitui\\u00e7\\u00e3o original).</p><p>Isso n\\u00e3o pode ser alterado agora, a n\\u00e3o ser que tenha havido erro material antes.</p><p>\\u2705 Solu\\u00e7\\u00e3o: corrigir a data no contrato consolidado para coincidir com a da constitui\\u00e7\\u00e3o j\\u00e1 arquivada.</p><h3>3. <strong>Participa\\u00e7\\u00e3o de s\\u00f3cio menor de idade (art. 1.690 CC)</strong></h3><p>A JUCEB apontou que existe <strong>s\\u00f3cio menor de 16 anos</strong> no quadro societ\\u00e1rio.</p><p>Nesse caso, a lei exige que <strong>ambos os pais representem o menor</strong>.</p><p>Exce\\u00e7\\u00e3o: se apenas um deles puder representar (falecimento, decis\\u00e3o judicial, monoparentalidade etc.), isso precisa estar <strong>expressamente declarado no contrato/altera\\u00e7\\u00e3o</strong>, com a fundamenta\\u00e7\\u00e3o legal.</p><p>N\\u00e3o basta um dos pais assinar sozinho sem justificar.</p><p>\\u2705 Solu\\u00e7\\u00e3o: ajustar o instrumento de consolida\\u00e7\\u00e3o para:</p><p>Trazer a <strong>assinatura de ambos os pais</strong> em nome do menor, <strong>ou</strong></p><p>Incluir cl\\u00e1usula explicando a aus\\u00eancia de um dos pais, fundamentando (ex.: \\u201cO menor X \\u00e9 representado apenas por sua m\\u00e3e Y, em raz\\u00e3o do falecimento do pai Z, conforme certid\\u00e3o anexa\\u201d).</p><h3>4. <strong>N\\u00famero do requerimento</strong></h3><p>A JUCEB alerta que o <strong>mesmo n\\u00famero de requerimento</strong> que originou o processo deve ser usado para cumprir exig\\u00eancia.</p><p>Ou seja: n\\u00e3o crie novo processo. Apenas <strong>corrija/atualize</strong> o mesmo requerimento eletr\\u00f4nico, reanexe os documentos corrigidos e reenvie.</p><h2>\\u2705 Passos pr\\u00e1ticos para corrigir</h2><p>Acessar o <strong>Integrador Estadual / REDESIM</strong> e <strong>editar o requerimento existente</strong>, marcando o evento 051.</p><p>Corrigir o <strong>instrumento de consolida\\u00e7\\u00e3o</strong>:</p><p>Ajustar a data de in\\u00edcio das atividades para a mesma que est\\u00e1 no contrato social original arquivado.</p><p>Tratar corretamente a quest\\u00e3o do s\\u00f3cio menor (assinatura dos dois pais ou justificativa fundamentada).</p><p>Assinar novamente (assinaturas digitais ou reconhecimento de firma, conforme o caso).</p><p>Anexar ao processo j\\u00e1 existente e reenviar para an\\u00e1lise.</p><p><strong>Exig\\u00eancias Processo</strong></p><figure class=\\"table\\"><table><tbody><tr><td><figure class=\\"table\\"><table><tbody><tr><td>Exig\\u00eancia</td><td>Observa\\u00e7\\u00e3o</td></tr><tr><td>&nbsp;</td></tr><tr><td>Outras exig\\u00eancias a especificar e fundamentar</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr><tr><td>Faltou informar no Requerimento eletr\\u00f4nico o evento 051 referente \\u00e0 consolida\\u00e7\\u00e3o.</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr><tr><td>Data de in\\u00edcio das atividades informada na consolida\\u00e7\\u00e3o est\\u00e1 divergindo do arquivado nesta JUCEB.</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr></tbody></table></figure></td></tr></tbody></table></figure><p><strong>Outras Exig\\u00eancias Processo</strong></p><figure class=\\"table\\"><table><tbody><tr><td><figure class=\\"table\\"><table><tbody><tr><td>Descri\\u00e7\\u00e3o</td><td>Fundamenta\\u00e7\\u00e3o</td></tr><tr><td>&nbsp;</td></tr><tr><td>CONFORME ART. 1.690 DO C\\u00d3DIGO CIVIL COMPETE AOS PAIS REPRESENTAR OS S\\u00d3CIOS MENORES DE DEZESSEIS ANOS, BEM COMO ASSISTI-LOS AT\\u00c9 COMPLETAREM A MAIORIDADE. DE FORMA EXCEPCIONAL, NA FALTA DE UM DELES, PODER\\u00c1 SER REPRESENTADO PELO OUTRO. NESSES CASOS, CABER\\u00c1 A PARTE INTERESSADA DECLARAR O MOTIVO DA FALTA NO INSTRUMENTO, RESPONDENDO PELA VERACIDADE DAS INFORMA\\u00c7\\u00d5ES LEVADAS A REGISTRO, SOB AS PENAS DA LEI</td><td>.</td></tr><tr><td>&nbsp;</td></tr><tr><td>OS MOTIVOS PODER\\u00c3O SER, A T\\u00cdTULO DE EXEMPLO: MORTE DE UM DOS PAIS, FAM\\u00cdLIA MONOPARENTAL, DECIS\\u00c3O JUDICIAL QUE CONCEDA O PODER FAMILIAR PARA APENAS UM DOS PAIS, DENTRE OUTROS. N\\u00c3O SER\\u00c1 ACEITO COMO MOTIVO A FALTA DE CONCORD\\u00c2NCIA DE UM DOS PAIS (RESP N. 1.816.742/SP, RELATOR MINISTRO PAULO DE TARSO SANSEVERINO, TERCEIRA TURMA, JULGADO EM 27/10/2020, DJE DE 19/11/2020).</td><td>.</td></tr><tr><td>&nbsp;</td></tr><tr><td>O numero do requerimento que originou o processo, devera ser utilizado nos casos de cumprimento de exigencias. Se necessario, atualize o requerimento, assine e envie o processo para reanalise. Para cumprimento nao deve criar outro processo. Para mais informa\\u00e7oes, acesse o nosso Site.</td></tr></tbody></table></figure></td></tr></tbody></table></figure><p><img src=\\"https://gestaoversus.odoo.com/web/image/4109-6f29283f/image.png?access_token=e415d9f8-86f9-4aab-b63f-02175546fe27\\"></p><p>Protocolo:&nbsp;81500002530990</p>", "stage": "executing", "status": "executing", "completion_date": null, "logs": []}, {"id": 9, "code": "AB.J.3.09", "what": "Altera\\u00e7\\u00e3o Constituinte", "who": "Fabiano", "when": null, "how": null, "amount": null, "observations": "<p>Fabiano, Bom dia!</p><p>Estava lembrando da empresa da constituinte (o CNPJ novo) que ficou pendente a quest\\u00e3o do bombeiro pra gerar o contrato social.</p><p>H\\u00e1 uns 3 meses atr\\u00e1s, entrei com CPF do s\\u00f3cio e vim que j\\u00e1 tava gerando obriga\\u00e7\\u00f5es desde quando teve a assinatura do contrato, a\\u00ed conseguir fazer o certificado digital mesmo sem o contrato e mandei algumas declara\\u00e7\\u00f5es, teve uma que gerou at\\u00e9 uma multa, valor baixo, n\\u00e3o cheguei a manda ainda pq quando tiver toda alinhado pode ser que tenha mais, a\\u00ed manda de vez pra poder incluir no simples ano que vem. Como t\\u00e1 fora do simples eu pedi ajuda a uma amiga e fiz at\\u00e9 aquele m\\u00eas, a\\u00ed n\\u00e3o sei se voc\\u00ea chegou a ver pra da continuidade ou me orientar em algo. Tinha colocado no papel pra te lembrar na reuni\\u00e3o, por\\u00e9m meu tio n\\u00e3o marcou e eu acabei esquecendo.&nbsp;</p>", "stage": "executing", "status": "executing", "completion_date": null, "logs": []}, {"id": 10, "code": "AB.J.3.10", "what": "AVCB", "who": "Victor", "when": null, "how": null, "amount": null, "observations": "<p><strong>BR324 - Protocolo feito em 22/08/2025</strong></p><p>A Solicita\\u00e7\\u00e3o de Vistoria foi protocolada. N\\u00ba do Protocolo:&nbsp;<strong>0054061-3/2025</strong>.</p><p>Conforme item 6.3.1, da IT n.\\u00ba 01/2016, deve haver pessoa para acompanhar e demonstrar o funcionamento dos sistemas de seguran\\u00e7a contra inc\\u00eandio.</p><p>O pagamento da taxa de vistoria d\\u00e1 direito a realiza\\u00e7\\u00e3o de uma vistoria e de dois retornos, caso sejam constatadas irregularidades pelo vistoriador, conforme item 6.7.4, da IT n.\\u00ba 01/2016.</p><p>-&gt; IPTU -&gt; Alvar\\u00e1 -&gt; Projetos -&gt; AVCB</p><p>1. Documenta\\u00e7\\u00e3o b\\u00e1sica da empresa/im\\u00f3vel</p><p>C\\u00f3pia do CNPJ e do Contrato Social (ou documento equivalente).</p><p>Alvar\\u00e1 de funcionamento ou documento da Prefeitura autorizando a atividade.</p><p>Matr\\u00edcula ou escritura do im\\u00f3vel, ou contrato de loca\\u00e7\\u00e3o.</p><p>Documento de identifica\\u00e7\\u00e3o do respons\\u00e1vel legal.</p><p>2. Projeto t\\u00e9cnico</p><p>PSCIP (Projeto de Seguran\\u00e7a Contra Inc\\u00eandio e P\\u00e2nico) assinado por engenheiro/arquitetos credenciados, com ART ou RRT registrada no CREA/CAU.</p><p>Memorial descritivo das medidas de seguran\\u00e7a (hidrantes, extintores, ilumina\\u00e7\\u00e3o, sinaliza\\u00e7\\u00e3o, etc.).</p><p>Plantas baixas e cortes da edifica\\u00e7\\u00e3o com localiza\\u00e7\\u00e3o de equipamentos de combate a inc\\u00eandio.</p><p>3. Comprova\\u00e7\\u00f5es t\\u00e9cnicas</p><p>ART/RRT da execu\\u00e7\\u00e3o das medidas de seguran\\u00e7a contra inc\\u00eandio.</p><p>Laudos de conformidade dos sistemas (ex.: teste de estanqueidade do g\\u00e1s, laudo el\\u00e9trico, certificado dos extintores e mangueiras, etc.).</p><p>Relat\\u00f3rio fotogr\\u00e1fico das instala\\u00e7\\u00f5es j\\u00e1 implantadas.</p><p>4. Requerimento oficial</p><p>Formul\\u00e1rio padr\\u00e3o do Corpo de Bombeiros solicitando a vistoria.</p><p>Comprovante de pagamento da taxa&nbsp;de&nbsp;vistoria.</p><p>&nbsp;</p><p>G\\u00e1s Evolution foi solicitado pelo sistema e esta pago, porem ta pendente Anexo J (renova\\u00e7\\u00e3o da brigada de inc\\u00eandio) e ART atualizada para solicitar a vistoria.</p><p>Segue login e senha das empreas que tinha planta e conseguir cadastrar no sistema:</p><p><strong>-BR E JRO-</strong></p><p>LOGIN:&nbsp;<a href=\\"mailto:advecont.nivea.gas@gmail.com\\">advecont.nivea.gas@gmail.com</a>&nbsp;</p><p>SENHA: 09973038</p><p><strong>-EVOLU\\u00c7\\u00c3O CABULA-&nbsp;</strong></p><p><a href=\\"mailto:LOGIN%3Alucas_heren@hotmail.com\\">LOGIN:lucas_heren@hotmail.com</a>&nbsp;</p><p>SENHA: 09973038-A</p><p><strong>-AV.PEIXE-</strong></p><p>LOGIN:&nbsp;<a href=\\"mailto:niveafernanda94@gmail.com\\">niveafernanda94@gmail.com</a></p><p>SENHA: 09973038</p><figure class=\\"table\\"><table><tbody><tr><td><strong>RAZ\\u00c3O SOCIAL</strong></td><td><p><strong>DATA DE VENCIMENTO</strong></p><p><strong>AVCB</strong></p></td></tr><tr><td>AV PEIXE&nbsp;(SISTEMA)</td><td>11/04/2025</td></tr><tr><td>BATE CORA\\u00c7\\u00c3O</td><td>07/01/2023</td></tr><tr><td>MARIA APARECIDA- LIBERDADE</td><td>01/09/2022</td></tr><tr><td>RB- PERNANBUES</td><td>02/07/2025</td></tr><tr><td>RT</td><td>23/01/2025</td></tr><tr><td>S\\u00c3O TOME</td><td>23/01/2025</td></tr><tr><td>A TODO GAS</td><td>11/09/2023</td></tr><tr><td>VM</td><td>23/01/2025</td></tr><tr><td>EVA</td><td>22/07/2025</td></tr><tr><td>EVOLU\\u00c7\\u00c3O DO GAS</td><td>17/01/2025</td></tr><tr><td>REAL GAS</td><td>02/07/2025</td></tr><tr><td>JRO&nbsp;(SISTEMA)</td><td>25/02/2025</td></tr><tr><td>GAS PAZ</td><td>02/07/2025</td></tr><tr><td>GAS EVOLUTION&nbsp;(SISTEMA)- RENOVA\\u00c7\\u00c3O PAGA</td><td>21/02/2025</td></tr></tbody></table></figure>", "stage": "inbox", "status": "pending", "completion_date": null, "logs": []}, {"id": 11, "code": "AB.J.3.11", "what": "Pend\\u00eancias Certificado", "who": "Fabiano", "when": null, "how": null, "amount": null, "observations": "<p><strong>Pend\\u00eancias Certificado:&nbsp;</strong></p><p>01- Atualizar certificado da Gas Evolution (com o novo s\\u00f3cio).</p><p>02- JRO ta sem certificado, foi solicitado o contrato social, mas n\\u00e3o foi entregue.</p><p>03- DC e AGB n\\u00e3o tem certificado pois precisa fazer altera\\u00e7\\u00e3o dos s\\u00f3cios.</p><p>04- As senhas est\\u00e3o salvas no t\\u00edtulo do certificado, \\u00e9 o nome do s\\u00f3cio&nbsp;com a inicial mai\\u00fasculas seguido de 12@.</p><p>05- As empresas a seguir n\\u00e3o possuem certificados, as declara\\u00e7\\u00e3o s\\u00e3o feitas pelo portal do simples nacional:</p>", "stage": "executing", "status": "executing", "completion_date": null, "logs": []}, {"id": 12, "code": "AB.J.3.12", "what": "Pend\\u00eancias Contrato", "who": "Fabiano", "when": null, "how": null, "amount": null, "observations": "<p><strong>Pend\\u00eancias Contratos:</strong></p><p>01- Altera\\u00e7\\u00e3o contratual (mudan\\u00e7a de s\\u00f3cio) da AGB (san Martins) e DC (Paripe), est\\u00e1&nbsp;sem enviar as declara\\u00e7\\u00f5es (n\\u00e3o tem certificado digital).</p><p>02- Foi dado entrada com o novo CNAE (protocolo BAP2500898795 em anexo) na empresa G\\u00e1s Evolution, precisa acompanhar o andamento da solicita\\u00e7\\u00e3o.<strong> (Aprovado).</strong></p><p>03- Abertura de NOVO CNPJ candeias&nbsp; (protocolo BAB2500759101 via requerimento eletr\\u00f4nico em anexo), PRECISA GERAR BOLETO SE&nbsp; O PROTOCOLO TIVER NA VALIDADE AINDA, caso n\\u00e3o, solicitar novamente a abertura, tenho os documentos dos s\\u00f3cios encaminhado por Azevedo.</p><p>04- O novo CNPJ aberto para o posto da constituinte GAS&nbsp;PARIPE (protocolo em anexo), ficou com pend\\u00eancia&nbsp;na viabilidade. Azevedo solicitou que entrasse em contato com Rogerio ( telefone e zap 71 98679-6388), o mesmo informou que ia abrir um convite&nbsp;com o prazo de 30 dias para juntar o AVCB, mas ainda n\\u00e3o mandou n\\u00famero de protocolo. No processo de abertura da empresa o bombeiro informou que a atividade foi enquadrada para ter acesso ao PTS e que seria necess\\u00e1rio a realiza\\u00e7\\u00e3o de vistorias&nbsp;(anexo e no sistema tb tem).&nbsp; At\\u00e9 hoje n\\u00e3o houve vistoria, ent\\u00e3o tudo indica que precisa dar entrada no AVCB pelo sistema&nbsp;fenix. Caso precise de planta baixa, a empresa anterior tem uma planta que segue em anexo.</p><p>05- Foi solicitado que&nbsp;abrisse um novo CNPJ no nome de Cida para uma empresa em Plataforma, s\\u00f3 que o IPTU ta como terreno, para mudar de terreno para com\\u00e9rcio&nbsp;precisa&nbsp;do comprovante da embasa, por\\u00e9m ainda n\\u00e3o tem \\u00e1gua&nbsp;l\\u00e1.</p><p>06- Alterar CNAE do cabula (EVOLU\\u00c7\\u00c3O DO GAS), retirar o transporte.&nbsp;</p>", "stage": "inbox", "status": "pending", "completion_date": null, "logs": []}, {"id": 13, "code": "AB.J.3.13", "what": "Pend\\u00eancia Fiscal do G\\u00e1s", "who": "Fabiano", "when": null, "how": null, "amount": null, "observations": "<p><strong>-&gt; Pend\\u00eancia Fiscal do G\\u00e1s:</strong></p><p>01- VM: RECEITA FEDERAL- DIVERG\\u00caNCIA DE CONTRIBUI\\u00c7\\u00c3O DA EMPRESA&nbsp;SOBRE BASES DECLARADAS (C\\u00c1LCULOS&nbsp;REALIZADOS)</p><p>\\u200b-&gt; 11.505.325/0001-42</p><p>\\u200b-&gt; N\\u00edvea mandou um e-mail retificando algumas informa\\u00e7\\u00f5es em 2025.07.09 -&gt;&nbsp;EMPRESA N\\u00c3O TAVA NO SIMPLES E DECLAROU COMO SE TIVESSE- C\\u00c1LCULO FEITO PELO REGULARIZE;</p><p><strong>\\u200b-&gt; 2025.07 -&gt; Aguardando Perfil Outro ou Prata do Valdines (Azevedo ficou de ver)</strong><br>&nbsp;</p><p>02- AV. PEIXE: EMPRESA N\\u00c3O TAVA NO SIMPLES E DECLAROU COMO SE TIVESSE- C\\u00c1LCULO FEITO PELO REGULARIZE;</p><p>\\u200b-&gt; CNPJ: 35.541.437/0001-17</p><p><strong>\\u200b-&gt; 2025.07.09 -&gt; Aguardando N\\u00edvea responder e-mail</strong></p><p><strong>\\u200b-&gt; 2025.07.09 -&gt; Resposta do e-mail de Nivea: Av. PEIXE \\u00e9 a empresa que foi declarada&nbsp;no PGDAS com o valor menor que as informa\\u00e7\\u00f5es fornecidas&nbsp;das vendas pelo cart\\u00e3o, fiscaliza\\u00e7\\u00e3o da prefeitura.</strong></p><p>03- EVOLU\\u00c7\\u00c3O DO GAS: RESTO DE PARCELAMENTO EM ABERTO REF. A D\\u00cdVIDA DE ICMS - SEFAZ-BA, CADIM E MULTA DE ENTREGA DE DCTF.</p><p>\\u200b-&gt; 20.804.651/0001-41</p><p><strong>\\u200b-&gt; 2025.07.09 -&gt;Empresa com muitos problemas, por\\u00e9m, o site da SEFAZ estava com problema e por isso n\\u00e3o consegui tirar o relat\\u00f3rio com detalhes.</strong><br>&nbsp;</p>", "stage": "inbox", "status": "pending", "completion_date": null, "logs": []}]	\N	2025-10-16 21:23:20	2025-10-16 22:02:01	22	\N	\N	AB.J.3	3	GRV	0.00	0.00	\N
41	13	\N	Reunião Semanal Gerencial - 2025.10.14	Projeto gerado automaticamente para a reunião: Reunião Semanal Gerencial	in_progress	medium	Sistema	2025-10-14	\N	\N	[{"title": "Mudança de Contratos (Conta e Falar com Cliente)", "what": "Mudança de Contratos (Conta e Falar com Cliente)", "description": "- Abertura da Conta;\\n- Entrar em contato com os clientes e trazer o parecer deles.", "how": "- Abertura da Conta;\\n- Entrar em contato com os clientes e trazer o parecer deles.", "responsible": "Marcel", "who": "Marcel", "deadline": "2025-10-17", "when": "2025-10-17", "updated_at": "2025-10-18T09:22:45.875718", "status": "pending", "stage": "inbox", "created_at": "2025-10-18T09:22:45.875718", "source": "meeting", "meeting_id": 3, "id": 1, "code": "AL.J.3.01"}, {"title": "Treinamento Joseane e Thais", "what": "Treinamento Joseane e Thais", "description": "- Estruturar os processos que Joseane e Thais irão atuar.\\n- Fazer um plano de treinamento para cada uma.\\n- Trazer atualização em que status elas estão.", "how": "- Estruturar os processos que Joseane e Thais irão atuar.\\n- Fazer um plano de treinamento para cada uma.\\n- Trazer atualização em que status elas estão.", "responsible": "Erika", "who": "Erika", "deadline": "2025-10-28", "when": "2025-10-28", "updated_at": "2025-10-18T09:22:45.875718", "status": "pending", "stage": "inbox", "created_at": "2025-10-18T09:22:45.875718", "source": "meeting", "meeting_id": 3, "id": 2, "code": "AL.J.3.02"}, {"title": "Controle de Colaboradores", "what": "Controle de Colaboradores", "description": "Será discutido na próxima reunião:\\n-> Controle da Rotina\\n-> Controle de Km\\n-> Controle de Gastos\\nVicente e Manoel estarão presentes.", "how": "Será discutido na próxima reunião:\\n-> Controle da Rotina\\n-> Controle de Km\\n-> Controle de Gastos\\nVicente e Manoel estarão presentes.", "responsible": "Erika", "who": "Erika", "deadline": "2025-10-21", "when": "2025-10-21", "updated_at": "2025-10-18T09:22:45.875718", "status": "pending", "stage": "inbox", "created_at": "2025-10-18T09:22:45.875718", "source": "meeting", "meeting_id": 3, "id": 3, "code": "AL.J.3.03"}, {"title": "Orçamento Base Zero", "what": "Orçamento Base Zero", "description": "Iremos discutir na próxima reunião a partir das 10:00 com Vicente e Manoel.", "how": "Iremos discutir na próxima reunião a partir das 10:00 com Vicente e Manoel.", "responsible": "Marcel", "who": "Marcel", "deadline": "2025-10-21", "when": "2025-10-21", "updated_at": "2025-10-18T09:22:45.875718", "status": "pending", "stage": "inbox", "created_at": "2025-10-18T09:22:45.875718", "source": "meeting", "meeting_id": 3, "id": 4, "code": "AL.J.3.04"}, {"title": "Trocar Dono do Processo", "what": "Trocar Dono do Processo", "description": "Avaliar a troca do dono do processo de Ativo Imobilizado e Gestão de Estoque.", "how": "Avaliar a troca do dono do processo de Ativo Imobilizado e Gestão de Estoque.", "responsible": "Todos", "who": "Todos", "deadline": "2025-10-21", "when": "2025-10-21", "updated_at": "2025-10-18T09:22:45.875718", "status": "pending", "stage": "inbox", "created_at": "2025-10-18T09:22:45.875718", "source": "meeting", "meeting_id": 3, "id": 5, "code": "AL.J.3.05"}]	Projeto vinculado à reunião ID 3	2025-10-16 22:23:36	2025-10-18 13:07:36	\N	\N	\N	AL.J.3	3	\N	0.00	0.00	\N
42	13	\N	Teste Fabiano Reunião 02 - 2025.10.17	Projeto gerado automaticamente para a reunião: Teste Fabiano Reunião 02	in_progress	medium	Sistema	2025-10-17	\N	\N	[{"title": "📋 Resumo da Reunião - Teste Fabiano Reunião 02", "description": "RESUMO DA REUNIÃO: Teste Fabiano Reunião 02\\n\\nData: None\\nHora: None\\n\\nPARTICIPANTES:\\n", "status": "completed", "created_at": "2025-10-17T19:54:31.150533", "id": 1, "stage": "inbox", "code": "AL.J.4.01"}, {"title": "Teste Atividade 01", "description": "Como Atividade 01", "responsible": "Fabiano", "deadline": "2025-10-31", "status": "pending", "created_at": "2025-10-18T09:10:37.740599", "source": "meeting", "meeting_id": 4, "updated_at": "2025-10-18T09:20:23.477326", "id": 2, "stage": "inbox", "code": "AL.J.4.02"}, {"title": "Teste Atividade 02", "description": "Como Atividade 02", "responsible": "Fabiano", "deadline": "2025-10-31", "status": "pending", "created_at": "2025-10-18T09:10:37.740599", "source": "meeting", "meeting_id": 4, "updated_at": "2025-10-18T09:20:23.493068", "id": 3, "stage": "inbox", "code": "AL.J.4.03"}, {"title": "Teste Atividade 03", "description": "Como Atividade 03", "responsible": "Fabiano", "deadline": "2025-10-31", "status": "pending", "created_at": "2025-10-18T09:10:37.740599", "source": "meeting", "meeting_id": 4, "updated_at": "2025-10-18T09:20:23.493068", "id": 4, "stage": "inbox", "code": "AL.J.4.04"}, {"title": "Tste Atividade 04", "description": "teatfdsadsaf dfs ddsfsadfas dsaddf sda fsa fa ", "responsible": "Fabiano", "deadline": "2025-10-20", "status": "pending", "created_at": "2025-10-18T09:20:23.493068", "source": "meeting", "meeting_id": 4, "id": 5, "stage": "inbox", "code": "AL.J.4.05"}]	Projeto vinculado à reunião ID 4	2025-10-17 22:53:00	2025-10-18 13:09:48	\N	\N	\N	AL.J.4	4	\N	0.00	0.00	\N
30	5	5	Teste Fabiano Projeto PEV	Teste Fabiano	planned	medium	Fabiano Ferreira	2025-10-01	2025-10-01	\N	[{"what": "Teste Atividade 01", "who": "Quem", "when": "2025-10-31", "amount": "10000", "how": "teste como", "observations": "teste observ", "id": 1, "stage": "waiting", "status": "waiting", "code": "AA.J.5.01"}, {"what": "Atividade 02", "who": "quem", "when": "2025-10-31", "amount": "20000", "how": "teste como", "observations": "teste observações", "id": 2, "stage": "completed", "status": "completed", "code": "AA.J.5.02", "logs": [{"timestamp": "2025-10-18T16:30:20.939Z", "text": "teste", "type": "completion", "date": "2025-10-18"}], "completion_date": "2025-10-18"}]	\N	2025-10-11 21:30:07	2025-10-18 13:30:20.945913-03	\N	\N	\N	AA.J.5	5	\N	0.00	0.00	\N
44	25	6	Concepção Empresa de Móveis - EUA - Projeto de Implantacao	Projeto criado para organização e validação do projeto da empresa de móveis nos EUA e criação dos projetos e atividades (com seus prazos, responsáveis e orçamentos).	\N	medium	\N	2025-10-20	2026-03-31	\N	[{"id": 1, "code": "AS.J.1.01", "what": "Validar preço de venda do marceneiro para o cliente final e da indústria para o marceneiro.", "who": "Tom", "when": "2025-11-10", "how": "Pesquisa \\"in loco\\" na viagem para os EUA", "amount": null, "observations": "Colher informações de várias fontes.", "stage": "executing", "status": "executing", "completion_date": null, "logs": []}, {"id": 2, "code": "AS.J.1.02", "what": "Validar condições de compra / locação do imóvel", "who": "Antonio Carlos", "when": "2025-11-10", "how": "Pesquisa \\"in-loco\\" na viagem que será feita.", "amount": null, "observations": "Pesquisar terrenos, galpões prontos, financiamentos, e imóveis para locação. Além de condições de construção (prazo e preço) como também permissões atreladas a estes imóveis.", "stage": "executing", "status": "executing", "completion_date": null, "logs": []}, {"id": 3, "code": "AS.J.1.03", "what": "Verificar aportes pelos 50% da empresa", "who": "Tom", "when": "2025-11-10", "how": "Verificar quanto se quer aportar pelos 50% da empresa que serão dele (e de seu grupo). Hoje esse valor seria de USD 750.000,00.", "amount": null, "observations": "", "stage": "executing", "status": "executing", "completion_date": null, "logs": []}, {"id": 4, "code": "AS.J.1.04", "what": "Escolher nome para a empresa", "who": "Tom", "when": "2025-11-10", "how": "Escolher razão social e nome fantasia para a empresa.", "amount": null, "observations": "Se atentar a: Instagram, site, concorrentes, etc.", "stage": "executing", "status": "executing", "completion_date": null, "logs": []}, {"id": 5, "code": "AS.J.1.05", "what": "Verificar sobre pagamento das máquinas na China", "who": "Tom", "when": "2025-11-10", "how": "Ver com os fabricantes das máquinas qual as condições de pagamento e as questões de declaração das exportações.", "amount": null, "observations": "", "stage": "inbox", "status": "pending", "completion_date": null, "logs": []}, {"id": 6, "code": "AS.J.1.06", "what": "Validar o tamanho do mercado de Marceneiros", "who": "Tom", "when": "2025-11-10", "how": "Verificar com os marceneiros ou outras fontes de informação, qual a quantidade de profissionais que atuam na região e principalmente quantos projetos \\"tipo\\" (1.000) peças eles vendem / instalam por mês em média.", "amount": null, "observations": "Obter várias fontes de dados.", "stage": "inbox", "status": "pending", "completion_date": null, "logs": []}, {"id": 7, "code": "AS.J.1.07", "what": "Concorrentes", "who": "Antonio Carlos", "when": "2025-11-10", "how": "Fazer pesquisa de quais empresas como o nosso projeto tem na região, quais seus preços e diferenciais competitivos.", "amount": null, "observations": "Mapear até um raio de 200 kms, ou no raio do concorrente mais longe que atende a região.", "stage": "inbox", "status": "pending", "completion_date": null, "logs": []}]	Projeto criado automaticamente para o planejamento PEV em 23/10/2025 23:15	2025-10-23 23:15:40.594814	2025-10-28 20:40:19.350473-03	\N	\N	\N	AS.J.1	1	PEV	0.00	0.00	\N
43	13	9	Estruturação de Compras e Estoque	Projeto associado a estruturação de compras e estoque, desde a definição de estoque mínimo até o procedimento de compras.	\N	high	\N	2025-10-20	2025-10-31	\N	[{"id": 1, "code": "AL.J.5.01", "what": "Definir lead time para produtos", "who": "Erika", "when": "2025-10-21", "how": "A empresa tem três centros de distribuição:\\n -> Fortaleza\\n -> Recife\\n -> Salvador\\nDefinir lead time para todos os produtos para cada um dos três centros de distribuição.\\nPara isso considerar os tempos de:\\nPedido - Faturamento do Fornecedor - Transporte - Intercorrências Comuns", "amount": null, "observations": "<p>Após Definir o lead time, avançar para:<br>→ Estoque mínimo de cada produto em cada centro de distribuição;</p><p>→ Gestão a vista (visual) do estoque mínimo em cada almoxarifado / estoque;</p><p>→ Controle de estoque (ver Auvo / Conta Azul / Planilha);</p><p>→ Responsável pelo estoque e pela solicitação de compras;</p>", "stage": "executing", "status": "executing", "completion_date": null, "logs": []}, {"id": 2, "code": "AL.J.5.02", "what": "Definir estoque mínimo de cada produto em cada centro de distribuição", "who": "Marcel", "when": "2025-10-31", "how": null, "amount": null, "observations": null, "stage": "waiting", "status": "waiting", "completion_date": null, "logs": []}, {"id": 3, "code": "AL.J.5.03", "what": "Estruturar Controle de Estoques", "who": "Fabiano", "when": "2025-10-31", "how": "-> Escolher Sistema\\n-> Definir Responsável\\n-> Modelar Processo (em especial POP)", "amount": null, "observations": null, "stage": "waiting", "status": "waiting", "completion_date": null, "logs": []}]	\N	2025-10-20 11:18:16.667856-03	2025-10-20 11:35:14.066233-03	25	\N	\N	AL.J.5	5	GRV	0.00	0.00	\N
\.


--
-- Data for Name: company_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_records (id, plan_id, participants, consultants, company_date, bsc_financial, bsc_commercial, bsc_process, bsc_learning, tri_commercial, tri_adm_fin, tri_operational, notes, created_at, updated_at) FROM stdin;
1	5	Fulano e Beltrano	Fabiano	2025-10-31	lkjdsafç df jkldfsajdsfjk lfadjk lfdsjkl ç	dsfjklç dafjkl adsfjkl çdasfjkl çdfajklç 	qdsfljkç dafjkldafjkl dajkl sadsfjklç 	dsfjklçdafljkçdafjklç adfljkç adfsjkl ç	jlçadsfjlkç dfjklç dfajklç adfjklç adfjklç 	dslkjç dafsjkl çdasfjklç dfasjklç adfsfdjklç a	dsflçjk dafljkç dafsljkç adsfjkladsfadsfjkl ç		2025-10-13 21:25:38	2025-10-13 21:25:38
\.


--
-- Data for Name: directional_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.directional_records (id, plan_id, title, description, status, owner, notes, created_at, updated_at, type, priority) FROM stdin;
8	5	Direcionador 02	lkjadsjkldsjlkdfsljkdfljk dsfjkl dfsjklç dfsjklç dfdfjklç sdfasjkl çadfsjkl çdfsjkl çdfsajklç afdjkl çdfjklç adfsljkafsd	active			2025-10-14 14:49:24	2025-10-14 14:49:24	Acelerador	Alta
9	5	Direcionador 01	ljkçadsfjlkdsfajlkçdsfjkl dfsajkl dsfajkl adsf	active			2025-10-14 15:09:17	2025-10-14 15:09:17	Estruturante	M�dia
\.


--
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.drivers (id, plan_id, title, description, status, priority, owner, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (id, company_id, name, email, phone, role_id, department, hire_date, status, notes, created_at, updated_at, weekly_hours, whatsapp, user_id) FROM stdin;
3	5	Fabiano - Gerente Adm/Fin	fabiano@gestaoversus.com.br	3134770194	6	Financeiro	2024-12-31	active		2025-10-10 20:56:43	2025-10-10 20:56:43	40	\N	\N
4	5	Fabiano Gerente Operacional	fabiano@versusconsultoria.com.br	3133121915	5	Operação	2022-10-31	active		2025-10-10 20:58:02	2025-10-10 20:58:02	40	\N	\N
5	5	Fabiano Diretor	mff2000@gmail.com	71996426565	1	Diretoria	2024-12-31	active		2025-10-10 21:31:02	2025-10-10 21:31:02	40	\N	\N
6	6	teste	teste@bol.com.br	111	8	teste	2025-12-31	active		2025-10-10 22:30:14	2025-10-10 22:30:14	40	\N	\N
7	1	Joao Silva	joao@empresa.com	11987654321	\N	TI	\N	active	\N	2025-10-11 22:30:08	2025-10-11 22:30:08	40	\N	\N
8	1	Maria Santos	maria@empresa.com	11987654322	\N	RH	\N	active	\N	2025-10-11 22:30:08	2025-10-11 22:30:08	40	\N	\N
9	1	Pedro Costa	pedro@empresa.com	11987654323	\N	Comercial	\N	active	\N	2025-10-11 22:30:08	2025-10-11 22:30:08	40	\N	\N
10	1	Ana Oliveira	ana@empresa.com	11987654324	\N	Marketing	\N	active	\N	2025-10-11 22:30:08	2025-10-11 22:30:08	40	\N	\N
11	1	Carlos Souza	carlos@empresa.com	11987654325	\N	Financeiro	\N	active	\N	2025-10-11 22:30:08	2025-10-11 22:30:08	40	\N	\N
12	13	Marcel	\N	\N	20	\N	\N	active	\N	2025-10-16 10:29:08	2025-10-16 10:29:08	40	\N	\N
13	13	Erika	\N	\N	21	\N	\N	active	\N	2025-10-16 10:29:21	2025-10-16 10:29:21	40	\N	\N
14	13	Vicente	\N	\N	22	\N	\N	active	\N	2025-10-16 10:29:37	2025-10-16 10:29:37	40	\N	\N
15	13	Manoel	\N	\N	19	\N	\N	active	\N	2025-10-16 10:29:50	2025-10-16 10:29:50	40	\N	\N
16	13	Joseane	\N	\N	23	\N	\N	active	\N	2025-10-16 10:30:05	2025-10-16 10:30:05	40	\N	\N
17	13	Thais	\N	\N	24	\N	\N	active	\N	2025-10-16 10:30:20	2025-10-16 10:30:20	40	\N	\N
18	14	Quesia	\N	\N	33	Adm/Fin	\N	active	\N	2025-10-16 16:58:42	2025-10-16 17:00:49	40	\N	\N
19	14	Sandro	\N	\N	33	Adm/Fin	\N	active	\N	2025-10-16 16:58:49	2025-10-16 17:00:58	40	\N	\N
20	14	Victor	\N	\N	33	Adm/Fin	\N	active	\N	2025-10-16 17:01:10	2025-10-16 17:01:21	40	\N	\N
21	14	Azevedo	\N	\N	26	Diretoria	\N	active	\N	2025-10-16 18:36:50	2025-10-16 18:37:28	40	\N	\N
22	14	Fabiano	\N	\N	34	\N	\N	active	\N	2025-10-16 18:37:02	2025-10-16 18:37:02	40	\N	\N
23	14	Cida	\N	\N	26	Diretoria	\N	active	\N	2025-10-16 18:37:14	2025-10-16 18:37:35	40	\N	\N
24	14	Carla	\N	\N	27	Comercial	\N	active	\N	2025-10-16 18:37:53	2025-10-16 18:37:53	40	\N	\N
25	13	Fabiano	\N	\N	35	\N	\N	active	\N	2025-10-16 22:19:22	2025-10-16 22:19:22	40	\N	\N
26	13	Wagner	\N	\N	35	\N	\N	active	\N	2025-10-16 22:19:33	2025-10-16 22:19:33	40	\N	\N
\.


--
-- Data for Name: indicator_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.indicator_data (id, company_id, goal_id, record_date, value, notes, created_at, updated_at) FROM stdin;
1	5	1	2025-10-13	150	\N	2025-10-13 00:34:45	2025-10-13 00:34:45
2	5	1	2025-12-31	130000	\N	2025-10-13 00:35:41	2025-10-13 00:35:41
3	13	4	2025-10-18	200	\N	2025-10-18 14:06:29.887925-03	2025-10-18 14:06:29.887925-03
\.


--
-- Data for Name: indicator_goals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.indicator_goals (id, company_id, indicator_id, code, goal_value, goal_date, responsible_id, status, notes, created_at, updated_at, goal_type, period_start, period_end, evaluation_basis, okr_reference, okr_reference_label) FROM stdin;
1	5	1	META-0001	120000	2025-12-31	3	active	120 mil por mês.	2025-10-13 00:34:29	2025-10-13 00:35:54	single	\N	\N	value	\N	\N
2	5	2	META-0002	300	2025-12-31	3	active	\N	2025-10-13 14:00:55	2025-10-13 14:00:55	single	\N	\N	value	\N	\N
3	5	3	META-0003	500	2025-10-25	5	active	\N	2025-10-13 15:27:25	2025-10-13 15:28:12	weekly	2025-10-05	2025-10-25	average	\N	\N
4	13	7	META-0001	200	2025-10-31	25	active	\N	2025-10-18 14:06:19.378085-03	2025-10-18 14:06:19.378085-03	daily	2025-10-18	2025-10-31	sum	\N	\N
\.


--
-- Data for Name: indicator_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.indicator_groups (id, company_id, parent_id, code, name, description, created_at, updated_at) FROM stdin;
1	5	\N	AA.I.1	Grupo Inicial - - -	Grupo cadastrado manualmente para testes.	2025-10-12 23:58:46	2025-10-13 00:09:41
2	5	1	AA.I.1.1	Teste 02	\N	2025-10-13 00:07:48	2025-10-13 00:07:48
3	5	\N	AA.I.2	Teste 02	\N	2025-10-13 00:07:55	2025-10-13 00:07:55
4	5	1	AA.I.1.2	Teste 03	\N	2025-10-13 00:08:57	2025-10-13 00:08:57
5	5	\N	AA.I.3	Teste 04	\N	2025-10-13 00:09:07	2025-10-13 00:09:07
6	13	\N	AL.I.1	teste	teste	2025-10-18 14:05:39.343329-03	2025-10-18 14:05:39.343329-03
\.


--
-- Data for Name: indicators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.indicators (id, company_id, group_id, code, name, process_id, project_id, department_id, collaborators, unit, formula, polarity, data_source, notes, created_at, updated_at, okr_reference, okr_reference_label, plan_id, okr_id, okr_level) FROM stdin;
1	5	2	AA.I.1.1.IND.001	Tete 02	45	27	\N	[3]	R$	Teste teste teste teste	positive	Teste teste teste	teste	2025-10-13 00:33:38	2025-10-13 00:33:38	\N	\N	\N	\N	\N
2	5	5	AA.I.3.001	Teste Indicador AB.C.1.1.1	17	\N	\N	[4]	R$	Teste Formula.	positive	Teste Fonte de Dados	teste	2025-10-13 13:58:46	2025-10-13 13:59:06	\N	\N	\N	\N	\N
3	5	2	AA.I.1.1.002	Teste 100	18	26	\N	[3]	R$	Formula indicador	positive	Fonte de Dados Indicador	Observações Indicador	2025-10-13 14:49:13	2025-10-13 14:49:13	\N	\N	\N	\N	\N
4	5	\N	AA.001	Teste Fabiano	17	28	\N	[3]	Litros	Teste Formulação	negative	Teste Fonte de Dados	teste	2025-10-13 16:52:02	2025-10-13 16:52:02	\N	\N	\N	\N	\N
5	5	\N	AA.002	Teste Indicador OKR	\N	\N	\N	[3]	R$	teste	positive	teste	teste	2025-10-14 21:58:23	2025-10-14 21:58:23	Teste OKR Global 01	\N	5	2	global
6	13	\N	AL.001	Tempo de Emissão de NF	93	\N	\N	[16]	Horas	\N	negative	\N	\N	2025-10-16 12:21:39	2025-10-16 12:21:39	\N	\N	\N	\N	\N
7	13	\N	AL.002	teste	69	\N	\N	[25]	teste	teste	positive	teste	teste	2025-10-18 14:05:26.530794-03	2025-10-18 14:05:26.530794-03	\N	\N	\N	\N	\N
\.


--
-- Data for Name: interviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.interviews (id, plan_id, participant_name, consultant_name, interview_date, format, notes, created_at, updated_at) FROM stdin;
1	5	Fabiano Diretor	Fabiano	2025-12-31	Online	Teste Fabiano adsfjklajklçdsfjkl çdfjkl çadfsjkl dfçasdfsjkl çadfsjklç dfasjklç adfjklç afdsfadsjkl çasdfjklç fsdajkl çadsfjkl çadsfjkl çdafsajdskl çfsdfajkl çsdfjklç dsfjkl çfdsjkl çafds	2025-10-13 21:08:14	2025-10-13 21:08:14
2	5	Fabiano Gerente Operacional	Fabiano	2025-12-31	Presencial	Teste jklçasdfl jdfksadsf ljkçadsf jklçadsf ljkçadsfdkl jfakldjf klasd fkldas klfj alkfj aklçdsf klads fjkad jkf alk fjkal jkl dkljas	2025-10-13 21:08:37	2025-10-13 21:08:37
\.


--
-- Data for Name: macro_processes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.macro_processes (id, company_id, area_id, name, code, owner, description, order_index, created_at, updated_at) FROM stdin;
1	1	1	PLANEJAMENTO ESTRATEGICO	AO.C.1.1	DIRETORIA		1	2025-10-06 22:16:33	2025-10-06 22:16:33
2	1	1	PESQUISA E DESENVOLVIMENTO	AO.C.1.2	DIRETORIA		2	2025-10-06 22:17:09	2025-10-06 22:17:09
3	1	1	GESTAO ESTRATEGICA	AO.C.1.3	FABIANO FERREIRA		3	2025-10-06 22:17:31	2025-10-06 22:17:31
4	1	2	COMERCIAL	AO.C.2.1	Douglas Carvalho		1	2025-10-06 22:22:26	2025-10-06 22:22:26
5	1	2	GERIR OPERAÇÕES PRÓPRIAS	AO.C.2.2	Fabiano Ferreira		2	2025-10-06 22:23:16	2025-10-06 22:23:16
6	1	2	GERIR OPERAÇÕES EM PARCERIA	AO.C.2.3	Fabiano Ferreira		3	2025-10-06 22:23:43	2025-10-06 22:23:43
7	1	3	GERIR PESSOAS	AO.C.3.1	Debora Carvalho		1	2025-10-06 22:24:59	2025-10-06 22:24:59
8	1	3	GERIR RECURSOS FINANCEIROS	AO.C.3.2	Debora Carvalho		2	2025-10-06 22:25:29	2025-10-06 22:25:29
9	1	3	GERIR TRIBUTOS E FISCO	AO.C.3.3	Edward Carvalho		3	2025-10-06 22:25:52	2025-10-06 22:25:52
10	1	3	GERIR DOCS E CONHECIMENTOS	AO.C.3.4	Debora Carvalho		4	2025-10-06 22:26:21	2025-10-06 22:26:21
11	1	3	GERIR ATIVO IMOBILIZADO	AO.C.3.5	Edward Carvalho		5	2025-10-06 22:26:49	2025-10-06 22:26:49
14	1	1	Teste Fabiano 02	AO.C.1.4	Fabiano		4	2025-10-07 23:18:49	2025-10-07 23:20:27
15	1	4	Teste 01	AO.C.4.1	Fabiano		1	2025-10-07 23:21:11	2025-10-07 23:21:11
16	1	4	Teste 02	AO.C.4.2	Fabiano		2	2025-10-07 23:21:46	2025-10-07 23:21:46
18	5	9	PESQUISA E DESENVOLVIMENTO	AB.C.1.2	Fabiano Ferreira		2	2025-10-07 23:44:30	2025-10-07 23:44:30
19	5	9	GESTÃO ESTRATÉGICA	AB.C.1.3	Fabiano Ferreira		3	2025-10-07 23:44:55	2025-10-07 23:44:55
20	5	9	PLANEJAMENTO ESTRATÉGICO	AB.C.1.1	Fabiano Ferreira		1	2025-10-07 23:48:45	2025-10-07 23:48:45
21	5	10	GERIR COMERCIAL	AB.C.2.1	Fabiano Ferreira		1	2025-10-08 00:24:19	2025-10-08 00:24:19
22	5	10	GERIR OPERAÇÕES PROPRIAS	AB.C.2.2	Fabiano Ferreira		2	2025-10-08 00:24:53	2025-10-08 00:24:53
23	5	10	GERIR OPERAÇÕES DE TERCEIROS	AB.C.2.3	Fabiano Ferreira		3	2025-10-08 00:26:07	2025-10-08 00:26:07
24	5	11	GERIR PESSOAS	AB.C.3.1	Fabiano Ferreira		1	2025-10-08 00:26:29	2025-10-08 00:26:29
25	5	11	GERIR RECURSOS FINANCEIROS	AB.C.3.2	Fabiano Ferreira		2	2025-10-08 00:26:49	2025-10-08 00:26:49
26	5	11	GERIR TRIBUTOS E FISCO	AB.C.3.3	Fabiano Ferreira		3	2025-10-08 00:27:06	2025-10-08 00:27:06
27	5	11	GERIR DOCS E CONHECIMENTO	AB.C.3.4	Fabiano Ferreira		4	2025-10-08 00:27:23	2025-10-08 00:27:23
28	5	11	GERIR ATIVO IMOBILIZADO	AB.C.3.5	Fabiano Ferreira		5	2025-10-08 00:27:48	2025-10-08 00:27:48
29	5	11	GERIR TIC	AB.C.3.6	Fabiano Ferreira		6	2025-10-08 00:28:08	2025-10-08 00:28:08
30	13	12	Planejamento Estratégico	AL.C.1.1	Diretoria		1	2025-10-16 10:48:29	2025-10-16 10:55:46
31	13	12	Pesquisa e Desenvolvimento	AL.C.1.2	Diretoria		2	2025-10-16 10:49:06	2025-10-16 10:55:53
32	13	14	Gerir Departamento Pessoal	AL.C.3.8	Erika		8	2025-10-16 10:49:26	2025-10-16 11:00:16
33	13	13	Novos Negócios	AL.C.2.1	Marcel		1	2025-10-16 10:51:04	2025-10-16 10:55:42
34	13	13	Gerir Relação com Clientes	AL.C.2.2	Marcel		2	2025-10-16 10:51:40	2025-10-16 10:55:50
35	13	12	Gestão Estratégica	AL.C.1.3	Diretoria		3	2025-10-16 11:12:04	2025-10-16 11:12:04
36	13	13	Gerir Execução dos Contratos	AL.C.2.3	Vicente		3	2025-10-16 11:15:53	2025-10-16 11:15:53
37	13	13	Gerir Serviços Terceirizados	AL.C.2.4	Vicente		4	2025-10-16 11:16:14	2025-10-16 11:16:14
38	13	14	Gerir Tributos e Fisco	AL.C.3.1	Erika		1	2025-10-16 11:16:46	2025-10-16 11:16:46
39	13	14	Gerir Pessoas	AL.C.3.2	Diretoria		2	2025-10-16 11:17:05	2025-10-16 11:17:05
40	13	14	Gerir Recursos Financeiros	AL.C.3.3	Erika		3	2025-10-16 11:17:27	2025-10-16 11:17:27
41	13	14	Gerir Compras e Estoque	AL.C.3.4	Erika		4	2025-10-16 11:17:48	2025-10-16 11:17:48
42	13	14	Gerir Documentos e Conhecimento	AL.C.3.5	Erika		5	2025-10-16 11:18:08	2025-10-16 11:18:08
43	13	14	Gerir Ativo Imobilizado	AL.C.3.6	Erika		6	2025-10-16 11:18:30	2025-10-16 11:18:30
44	13	14	Gerir TIC	AL.C.3.7	Marcel		7	2025-10-16 11:18:47	2025-10-16 11:18:47
45	14	15	PLANEJAMENTO ESTRATÉGICO	AB.C.1.1	DIRETORIA		1	2025-10-16 17:10:26	2025-10-16 17:10:26
46	14	15	PESQUISA E DESENVOLVIMENTO	AB.C.1.2	DIRETORIA		2	2025-10-16 17:10:43	2025-10-16 17:10:43
47	14	15	GESTÃO ESTRATÉGICA	AB.C.1.3	DIRETORIA		3	2025-10-16 17:11:06	2025-10-16 17:11:06
48	14	16	GERIR COMPRAS	AB.C.2.1	AZEVEDO		1	2025-10-16 17:11:31	2025-10-16 17:11:31
49	14	16	GERIR ESTOQUE E DISTRIBUIÇÃO	AB.C.2.2	AZEVEDO		2	2025-10-16 17:13:50	2025-10-16 17:13:50
50	14	16	GERIR COMERCIAL E ENTREGAS	AB.C.2.3	CARLA		3	2025-10-16 17:14:15	2025-10-16 17:14:15
51	14	17	GERIR JURIDICO	AB.C.3.7	FABIANO FERREIRA		7	2025-10-16 17:14:50	2025-10-16 17:18:18
52	14	17	GERIR PESSOAS	AB.C.3.1	AZEVEDO		1	2025-10-16 17:34:50	2025-10-16 17:34:50
53	14	17	GERIR RECURSOS FINANCEIROS	AB.C.3.2	FABIANO FERREIRA		2	2025-10-16 17:35:11	2025-10-16 17:35:11
54	14	17	GERIR TRIBUTOS E DEPTO PESSOAL	AB.C.3.3	FABIANO FERREIRA		3	2025-10-16 17:35:39	2025-10-16 17:35:39
55	14	17	GERIR ATIVO IMOBILIZADO	AB.C.3.5	FABIANO FERREIRA		5	2025-10-16 17:36:00	2025-10-16 17:36:00
56	14	17	GERIR TIC	AB.C.3.6	FABIANO FERREIRA		6	2025-10-16 17:36:15	2025-10-16 17:36:15
57	14	17	GERIR DOCUMENTOS E CONHECIMENTOS	AB.C.3.4	FABIANO FERREIRA		4	2025-10-16 17:37:34	2025-10-16 17:37:34
\.


--
-- Data for Name: market_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_records (id, plan_id, participants, consultants, market_date, format, global_context, sector_context, market_size, growth_space, threats, consumer_behavior, competition, notes, created_at, updated_at) FROM stdin;
1	5	Fulano e Beltrano	Fabiano	2025-10-13	Online	teste adsjklads jkdflajkaldsf jklç adsfakdsfjl çsdfj klçaçk jladsfkjlç adsfkjlsdfajk ldsfajkadsfl çkjl fçadsfdsjklç sfd ajklsdfjk lafds jkl	ajklçdfsjkladsf jldfsakçasdfjkl çfdsajkl çfadsjkl afdsjkl adsfljkçdsfjklçfdsjkla çsfdjkl ç	jklçadfjkl dasfjkl adfsjkl açdfsdsfjkl çdsaf jklçdsfalçjk fdasjklç fdsajkl	jadsflçkdfsajklfds jlkfdjkl fdsjlkçfadsfjldk ajfkldççdfljk  jklçdfakjlfd ljkçdaflk	jkldfajkl çdfasjk lçadsf jkldsaf jklçdfs jklfadsjkç lafdsjk dsflça dsfjklçfadsjkl 	dsjklajklafd jkldfasjkl çfdjkldfsjkl çdfjklç dfasjklç dfsajklç dfsjklçfdsjklç	dljkfadjklç dafsjkl çdfasjkl çadfsjklfdajklç afdsjkl afdkjladfklçj adfçjkl daljkç daf	dsfajkladsfjklç dfasjklç fdajkl çfdajklç fdasjklçfjlçk asjklç sdfajklç dfs	2025-10-13 21:24:44	2025-10-13 21:24:44
\.


--
-- Data for Name: meeting_agenda_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.meeting_agenda_items (id, company_id, title, description, usage_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: meetings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.meetings (id, company_id, project_id, title, scheduled_date, scheduled_time, invite_notes, meeting_notes, guests_json, agenda_json, participants_json, discussions_json, activities_json, created_at, updated_at, actual_date, actual_time, status) FROM stdin;
1	5	31	Reunião Teste	2025-10-21	09:00	Teste Observações da Reunião.	Teste Observações.	{"internal": [{"id": "3", "name": "Fabiano - Gerente Adm/Fin", "email": "fabiano@gestaoversus.com.br", "whatsapp": ""}, {"id": "5", "name": "Fabiano Diretor", "email": "mff2000@gmail.com", "whatsapp": ""}], "external": []}	[{"title": "Pauta 01"}, {"title": "Patua 02"}]	{"external": [], "internal": []}	[{"title": "Discussão 01", "discussion": "Discussão 01"}, {"title": "Discussão 02", "discussion": "Discussão 02"}]	[{"title": "Teste Atividade Cadastrada", "responsible": "Fabiano", "deadline": "2025-10-31", "project_id": null}, {"title": "", "responsible": "", "deadline": "", "project_id": null}]	2025-10-14 21:48:57	2025-10-15 00:09:17	\N	\N	draft
2	5	\N	Teste Reunião Fabiano	2025-10-31	10:00	Teste Fabiano Observações	teste fabiano	{"internal": [{"id": "3", "name": "Fabiano - Gerente Adm/Fin", "email": "fabiano@gestaoversus.com.br", "whatsapp": ""}], "external": [{"name": "Marcos", "email": "mff2000@gmail.com", "whatsapp": "71996426565"}]}	[{"title": "Pauta 01"}, {"title": "Pauta 02"}, {"title": "Pauta 03"}]	{"external": [], "internal": []}	[{"title": "Teste Assunto 01", "discussion": "Assunto diversos 01"}, {"title": "Teste Assunto 02", "discussion": "Assuntos diversos 02"}]	[{"title": "Projeto 02", "responsible": "Fabiano", "deadline": "2025-12-31", "project_id": "28"}]	2025-10-14 23:42:18	2025-10-14 23:47:39	\N	\N	draft
4	13	42	Teste Fabiano Reunião 02	2025-10-17	10:00	Teste Observações		{"internal": [{"id": "25", "name": "Fabiano", "email": "", "whatsapp": ""}, {"id": "26", "name": "Wagner", "email": "", "whatsapp": ""}], "external": []}	[{"title": "Pauta Tese 01"}, {"title": "Pauta Teste 02"}]	{"external": [], "internal": [{"email": "", "id": "25", "name": "Fabiano", "whatsapp": ""}, {"email": "", "id": "26", "name": "Wagner", "whatsapp": ""}]}	[{"discussion": "Teste Discussão 01", "title": "Teste Discussão 01"}, {"discussion": "Teste Discussão 02", "title": "Teste Discussão 02"}, {"discussion": "Teste Discussão 03", "title": "Teste Discussão 03"}]	[{"deadline": "2025-10-31", "how": "Como Atividade 01", "project_id": null, "responsible": "Fabiano", "title": "Teste Atividade 01"}, {"deadline": "2025-10-31", "how": "Como Atividade 02", "project_id": null, "responsible": "Fabiano", "title": "Teste Atividade 02"}, {"deadline": "2025-10-31", "how": "Como Atividade 03", "project_id": null, "responsible": "Fabiano", "title": "Teste Atividade 03"}, {"deadline": "2025-10-20", "how": "teatfdsadsaf dfs ddsfsadfas dsaddf sda fsa fa ", "project_id": null, "responsible": "Fabiano", "title": "Tste Atividade 04"}]	2025-10-17 22:52:47	2025-10-18 12:27:00	2025-10-17	18:00	completed
3	13	41	Reunião Semanal Gerencial	2025-10-14	09:00			{"internal": [{"email": "", "id": "12", "name": "Marcel", "whatsapp": ""}, {"email": "", "id": "13", "name": "Erika", "whatsapp": ""}, {"email": "", "id": "26", "name": "Wagner", "whatsapp": ""}, {"email": "", "id": "25", "name": "Fabiano", "whatsapp": ""}], "external": []}	[{"title": "Implantação da Reunião Semanal"}, {"title": "Atividades e Projetos Prioritários para Cada um."}]	{"external": [], "internal": [{"email": "", "id": "26", "name": "Wagner", "whatsapp": ""}, {"email": "", "id": "25", "name": "Fabiano", "whatsapp": ""}]}	[{"discussion": "Wagner: \\n           Controle dos Colaboradores\\n\\nErika: \\n           Treinamento Joseane\\n           Treinamento Thais\\n           Revisar Contrato Padrão\\n           Suply Chain - Estruturar\\n\\nMarcel:\\n          Delegar demandas que são de outras áreas, como compras técnicas e relatórios;\\n          Reforçar treinamento da equipe até eles ficarem aptos a executar o que é de responsabilidade deles;\\n          Vicente melhorar relacionamento com clientes para desvincular Marcel\\n          Custeio por cliente\\n          Cartões corporativos - Resolver essa questão\\n         ", "title": "Atividades e Projetos Prioritários para Cada um"}]	[{"deadline": "2025-10-17", "how": "- Abertura da Conta;\\n- Entrar em contato com os clientes e trazer o parecer deles.", "project_id": null, "responsible": "Marcel", "title": "Mudança de Contratos (Conta e Falar com Cliente)"}, {"deadline": "2025-10-28", "how": "- Estruturar os processos que Joseane e Thais irão atuar.\\n- Fazer um plano de treinamento para cada uma.\\n- Trazer atualização em que status elas estão.", "project_id": null, "responsible": "Erika", "title": "Treinamento Joseane e Thais"}, {"deadline": "2025-10-21", "how": "Será discutido na próxima reunião:\\n-> Controle da Rotina\\n-> Controle de Km\\n-> Controle de Gastos\\nVicente e Manoel estarão presentes.", "project_id": null, "responsible": "Erika", "title": "Controle de Colaboradores"}, {"deadline": "2025-10-21", "how": "Iremos discutir na próxima reunião a partir das 10:00 com Vicente e Manoel.", "project_id": null, "responsible": "Marcel", "title": "Orçamento Base Zero"}, {"deadline": "2025-10-21", "how": "Avaliar a troca do dono do processo de Ativo Imobilizado e Gestão de Estoque.", "project_id": null, "responsible": "Todos", "title": "Trocar Dono do Processo"}]	2025-10-16 22:21:49	2025-10-20 10:08:56.819472	2025-10-14	09:00	completed
5	13	\N	Teste Fabiano 02	2025-10-20	10:00	teste		{"internal": [{"id": "25", "name": "Fabiano", "email": "", "whatsapp": ""}, {"id": "13", "name": "Erika", "email": "", "whatsapp": ""}, {"id": "12", "name": "Marcel", "email": "", "whatsapp": ""}], "external": []}	[{"title": "Teste 01"}]	{"external": [], "internal": []}	[]	[]	2025-10-20 10:12:52.579413	2025-10-20 11:46:51.311128	2025-10-20	09:00	draft
\.


--
-- Data for Name: misalignment_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.misalignment_records (id, plan_id, issue, description, severity, impact, notes, created_at, updated_at) FROM stdin;
1	5						2025-10-13 21:27:33	2025-10-13 21:27:33
2	5						2025-10-13 21:27:51	2025-10-13 21:27:51
\.


--
-- Data for Name: occurrences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.occurrences (id, company_id, employee_id, process_id, project_id, title, description, type, score, created_at, updated_at) FROM stdin;
1	5	3	\N	29	Teste Fabiano	Teste Fabiano Teste Fabiano	positive	5	2025-10-11 20:25:09	2025-10-11 20:25:09
2	5	5	\N	\N	teste 02		negative	4	2025-10-11 20:25:37	2025-10-11 20:25:37
\.


--
-- Data for Name: okr_area_preliminary_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.okr_area_preliminary_records (id, plan_id, analysis, created_at, updated_at) FROM stdin;
1	5	tweaewewradsffddfasdfas	2025-10-14 19:18:06	2025-10-14 19:18:06
\.


--
-- Data for Name: okr_area_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.okr_area_records (id, plan_id, stage, objective, okr_type, type_display, department, owner_id, owner, deadline, observations, created_at, updated_at) FROM stdin;
1	5	approval	Teste OKR de Area 01 - Vendas	estruturante	Estruturante	Vendas	\N	Gerente de Vendas	2024-12-31	OKR focado em crescimento de vendas	2025-10-14 22:00:45	2025-10-14 22:00:45
2	5	approval	Teste OKR de Area 02 - Marketing	aceleracao	Aceleração	Marketing	\N	Gerente de Marketing	2024-12-31	OKR focado em aquisição de clientes	2025-10-14 22:00:45	2025-10-14 22:00:45
3	5	workshop	Teste Objetivo 01	estruturante	Estruturante	operacional	8	Fabiano Diretor	2025-12-31	Teste Observações	2025-10-14 22:24:33	2025-10-14 22:24:33
\.


--
-- Data for Name: okr_global_key_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.okr_global_key_results (id, okr_id, label, target, deadline, owner, "position", created_at, updated_at, owner_id, indicator_id) FROM stdin;
\.


--
-- Data for Name: okr_global_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.okr_global_records (id, plan_id, stage, objective, okr_type, type_display, owner, deadline, observations, directional, created_at, updated_at, owner_id) FROM stdin;
1	5	workshop	Teste	estruturante	Estruturante	Fabiano Diretor	2025-12-31	Teste	9	2025-10-14 19:16:44	2025-10-14 19:16:44	8
2	5	approval	Teste OKR Global 01	estruturante	Estruturante	Fabiano Diretor	2025-12-31	teste	9	2025-10-14 19:17:24	2025-10-14 19:17:24	8
\.


--
-- Data for Name: okr_preliminary_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.okr_preliminary_records (id, plan_id, analysis, created_at, updated_at) FROM stdin;
1	5	jladsfjlkdfsjkldfasjkl dfsajkl dçsfjklç dsfjadsfkl çdjkl ç djklçdsjkl djskl sdfj lksfdjkl çfds	2025-10-14 14:50:37	2025-10-14 14:50:37
\.


--
-- Data for Name: okrs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.okrs (id, plan_id, title, description, type, area, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: participants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.participants (id, plan_id, name, role, relation, email, cpf, phone, status, email_confirmed, whatsapp_confirmed, message_sent, created_at, updated_at, employee_id) FROM stdin;
7	5	Fabiano Gerente Operacional	Gerente Operacional	Operação	fabiano@versusconsultoria.com.br		3133121915	active	f	f	f	2025-10-11 22:37:05	\N	4
8	5	Fabiano Diretor	Diretor	Diretoria	mff2000@gmail.com		71996426565	active	f	f	f	2025-10-11 22:43:40	\N	5
\.


--
-- Data for Name: plan_alignment_agenda; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_alignment_agenda (id, plan_id, action_title, owner_name, schedule_info, execution_info, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plan_alignment_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_alignment_members (id, plan_id, name, role, motivation, commitment, risk, created_at, updated_at) FROM stdin;
2	6	Antonio Carlos	Diretor Comercial | Diretor Adm-Fin	Ter um negócio com uma renda fixa de USD 5 a 10 mil / mês nos EUA. Iniciando em um ano.	Não irá deixar seus compromissos no Brasil para se dedicar ao dia a dia, porém irá estruturar as áreas de sua responsabilidade e irá tocar com a ajuda da sua equipe.	Moderada	2025-10-28 16:26:37.288646	2025-10-28 16:26:37.288646
3	6	Tom	Diretor Operacional	Ter um negócio nos EUA que aumente a visibilidade e confiabilidade do seu negócio no Brasil e que este renda USD 50 mil mês, iniciando em até 01 ano.	Irá se responsabilizar junto à sua equipe pela parte operacional, desde a compra de insumos até a entrega/montagem (quando houve) do produto final. Não pretende largar seus negócios no Brasil para se dedicar a não ser que os EUA escale muito mais que o Brasil.	Moderada	2025-10-28 16:28:45.241353	2025-10-28 16:28:45.241353
\.


--
-- Data for Name: plan_alignment_overview; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_alignment_overview (plan_id, shared_vision, financial_goals, decision_criteria, notes, created_at, updated_at) FROM stdin;
6	O mercado americano, em especial Orlando, tem uma carência em móveis planejados (atendimento a marceneiros) e modulares (atendimento a empreiteiros), que pode ser um ótimo negócio.	Atender 30 marceneiros com 120 projetos por mês, fazendo um faturamento mensal de USD 1.200.000,00.	["Antonio Carlos e Tom terão outros sócios, sendo que cada um irá organizar junto aos seus sócios a divisão de investimento e definições. Porém Antonio Carlos e Tom é que serão os sócios administradores."]	\N	2025-10-28 16:31:44.377972	2025-10-28 16:31:44.377972
\.


--
-- Data for Name: plan_alignment_principles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_alignment_principles (id, plan_id, principle, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plan_alignment_project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_alignment_project (plan_id, project_name, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plan_finance_business_distribution; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_finance_business_distribution (id, period_id, description, amount, created_at) FROM stdin;
\.


--
-- Data for Name: plan_finance_business_periods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_finance_business_periods (id, plan_id, period_label, revenue, variables, contribution_margin, fixed_costs, operating_result, result_period, created_at) FROM stdin;
\.


--
-- Data for Name: plan_finance_funding_sources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_finance_funding_sources (id, plan_id, source_type, contribution_date, amount, notes, created_at) FROM stdin;
1	6	Aporte dos Sócios	2026-01-10	300000.00	150.000 para cada parte	2025-10-28 20:15:44.989401
2	6	Aporte dos Sócios	2026-02-15	300000.00	150.000 para cada parte	2025-10-28 20:16:03.55409
3	6	Aporte dos Sócios	2026-03-15	300000.00	150.000 para cada parte	2025-10-28 20:16:22.595308
6	6	Aporte dos Sócios	2026-04-15	600000.00	300.000 para cada parte	2025-10-28 20:19:11.927869
\.


--
-- Data for Name: plan_finance_investment_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_finance_investment_categories (id, plan_id, category_type, category_name, display_order, created_at) FROM stdin;
1	5	capital_giro	Capital de Giro	1	2025-10-27 20:19:01.448752
2	5	imobilizado	Imobilizado	2	2025-10-27 20:19:01.448752
3	6	capital_giro	Capital de Giro	1	2025-10-27 20:19:01.448752
4	6	imobilizado	Imobilizado	2	2025-10-27 20:19:01.448752
5	7	capital_giro	Capital de Giro	1	2025-10-27 20:19:01.448752
6	7	imobilizado	Imobilizado	2	2025-10-27 20:19:01.448752
7	8	capital_giro	Capital de Giro	1	2025-10-27 20:19:01.448752
8	8	imobilizado	Imobilizado	2	2025-10-27 20:19:01.448752
\.


--
-- Data for Name: plan_finance_investment_contributions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_finance_investment_contributions (id, item_id, contribution_date, amount, notes, created_at, description, system_suggestion, adjusted_value, calculation_memo) FROM stdin;
4	1	2026-05-01	612000.00		2025-10-28 18:22:12.44966		\N	612000.00	Custo e Despesas Fixas = 76.500 x 8 = 612.000
5	3	2026-05-01	430000.00		2025-10-28 18:27:56.18196		\N	430000.00	MDF\n-> 01 mês de produção em pedidos: 110.000\n-> 01 mês de produção produzindo: 110.000\n-> 01 mês de produção em trânsito (no mar): 110.000\n\nFerragens:\n-> 01 mês de produção: 100.000
\.


--
-- Data for Name: plan_finance_investment_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_finance_investment_items (id, category_id, item_name, display_order, created_at) FROM stdin;
1	1	Caixa	1	2025-10-27 20:19:01.448752
2	1	Recebíveis	2	2025-10-27 20:19:01.448752
3	1	Estoques	3	2025-10-27 20:19:01.448752
4	2	Instalações	1	2025-10-27 20:19:01.448752
5	2	Máquinas e Equipamentos	2	2025-10-27 20:19:01.448752
6	2	Outros Investimentos	3	2025-10-27 20:19:01.448752
7	3	Caixa	1	2025-10-27 20:19:01.448752
8	3	Recebíveis	2	2025-10-27 20:19:01.448752
9	3	Estoques	3	2025-10-27 20:19:01.448752
10	4	Instalações	1	2025-10-27 20:19:01.448752
11	4	Máquinas e Equipamentos	2	2025-10-27 20:19:01.448752
12	4	Outros Investimentos	3	2025-10-27 20:19:01.448752
13	5	Caixa	1	2025-10-27 20:19:01.448752
14	5	Recebíveis	2	2025-10-27 20:19:01.448752
15	5	Estoques	3	2025-10-27 20:19:01.448752
16	6	Instalações	1	2025-10-27 20:19:01.448752
17	6	Máquinas e Equipamentos	2	2025-10-27 20:19:01.448752
18	6	Outros Investimentos	3	2025-10-27 20:19:01.448752
19	7	Caixa	1	2025-10-27 20:19:01.448752
20	7	Recebíveis	2	2025-10-27 20:19:01.448752
21	7	Estoques	3	2025-10-27 20:19:01.448752
22	8	Instalações	1	2025-10-27 20:19:01.448752
23	8	Máquinas e Equipamentos	2	2025-10-27 20:19:01.448752
24	8	Outros Investimentos	3	2025-10-27 20:19:01.448752
\.


--
-- Data for Name: plan_finance_investments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_finance_investments (id, plan_id, description, amount, created_at) FROM stdin;
\.


--
-- Data for Name: plan_finance_investor_periods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_finance_investor_periods (id, plan_id, period_label, contribution, distribution, balance, cumulative, created_at) FROM stdin;
\.


--
-- Data for Name: plan_finance_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_finance_metrics (id, plan_id, payback, tir, notes, created_at) FROM stdin;
\.


--
-- Data for Name: plan_finance_premises; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_finance_premises (id, plan_id, description, suggestion, adjusted, observations, memory, created_at) FROM stdin;
\.


--
-- Data for Name: plan_finance_profit_distribution; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_finance_profit_distribution (id, plan_id, percentage, notes, created_at, updated_at, start_date) FROM stdin;
1	6	50%		2025-10-28 17:57:21.133251	2025-10-28 17:57:21.133251	2026-10-10
\.


--
-- Data for Name: plan_finance_result_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_finance_result_rules (id, plan_id, description, percentage, periodicity, created_at) FROM stdin;
1	6	Participação nos Lucros - Funcionários	20%		2025-10-28 17:58:42.553449
\.


--
-- Data for Name: plan_finance_sources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_finance_sources (id, plan_id, category, description, amount, availability, created_at) FROM stdin;
\.


--
-- Data for Name: plan_finance_variable_costs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_finance_variable_costs (id, plan_id, description, percentage, created_at) FROM stdin;
\.


--
-- Data for Name: plan_implantation_checkpoints; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_implantation_checkpoints (id, plan_id, title, status, date_label, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plan_implantation_dashboard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_implantation_dashboard (plan_id, hero_message, progress_message, general_note, general_details, next_focus, next_focus_details, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plan_implantation_phases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_implantation_phases (id, plan_id, phase_key, title, status, tagline, pulse, sections, deliverables, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plan_products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_products (id, plan_id, name, description, sale_price, sale_price_notes, variable_costs_percent, variable_costs_value, variable_costs_notes, variable_expenses_percent, variable_expenses_value, variable_expenses_notes, unit_contribution_margin_percent, unit_contribution_margin_value, unit_contribution_margin_notes, market_size_monthly_units, market_size_monthly_revenue, market_size_notes, market_share_goal_monthly_units, market_share_goal_percent, market_share_goal_notes, created_at, updated_at, is_deleted) FROM stdin;
2	6	Projetos Planejados	Projetos planejados vendidos por marceneiros para os clientes deles	10000.00		32.00	3200.00		0.00	0.00		68.00	6800.00		600.00	6000000.00		120.00	30.00	Validar	2025-10-28 20:54:18.420887	2025-10-28 20:54:18.420887	f
\.


--
-- Data for Name: plan_sections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_sections (id, plan_id, section_name, status, closed_by, closed_at, notes, created_at, updated_at, adjustments) FROM stdin;
1	5	projects	open		\N	\N	2025-10-11 04:19:23	2025-10-11 04:19:26	\N
5	5	preliminary-analysis-okr	open	\N	\N	\N	2025-10-11 22:49:47	2025-10-14 14:50:30	\N
6	5	workshop-final-okr	open	\N	\N	\N	2025-10-11 22:49:51	2025-10-14 14:50:51	\N
7	5	okr-approvals	open	\N	\N	\N	2025-10-11 22:49:54	2025-10-14 14:51:54	\N
8	5	alignments-found	closed	Usu�rio	CURRENT_TIMESTAMP		2025-10-13 21:25:49	2025-10-14 14:49:55	\N
9	5	misalignments-critical	closed	Usu�rio	CURRENT_TIMESTAMP		2025-10-13 21:27:18	2025-10-14 14:49:50	\N
10	5	workshop-final-analysis	closed	Usu�rio	CURRENT_TIMESTAMP		2025-10-13 21:28:02	2025-10-14 14:49:46	[{"type": "", "original": "", "adjusted": "", "reason": ""}]
11	5	directionals-consultant	open	{"ai_analysis": "", "diagnosis": "", "directionals": ""}	\N	\N	2025-10-13 21:29:21	2025-10-14 10:06:28	\N
12	5	directionals-approvals	open	\N	\N	{"consultant_notes": "\\u00e7lkjdfsjkl \\u00e7adsfjkl \\u00e7dasfjkl\\u00e7d sfjkl\\u00e7 dfsaadsfjkl \\u00e7dfjkl\\u00e7 fdsjkl \\u00e7adsfljk", "approvals": [], "conclusion_reason": "{\\"approvals\\": [{\\"partner\\": \\"\\", \\"status\\": \\"\\", \\"comments\\": \\"\\", \\"date\\": \\"\\"}], \\"directionals\\": []}"}	2025-10-14 10:39:47	2025-10-14 15:08:33	\N
13	5	market	closed	Usu�rio	CURRENT_TIMESTAMP		2025-10-14 14:50:07	2025-10-14 14:50:07	\N
14	5	vision	closed	Usu�rio	CURRENT_TIMESTAMP		2025-10-14 14:50:10	2025-10-14 14:50:10	\N
15	5	area-okr-workshop	open	{"okrs": [{"id": 1, "global_ref": "2", "area": "operacional", "objective": "Teste Objetivo 01", "type": "estruturante", "type_display": "Estruturante", "owner_id": "8", "owner": "Fabiano Diretor", "deadline": "2025-12-31", "observations": "Teste Observa\\u00e7\\u00f5es", "created_at": "2025-10-14T19:24:33.575542", "updated_at": "2025-10-14T19:24:33.575542", "key_results": []}]}	\N	\N	2025-10-14 19:18:38	2025-10-14 22:24:33	\N
16	5	final-area-okr	open	{"okrs": [{"id": 1, "global_ref": "2", "area": "administrativo", "objective": "OKR Area Teste 01", "type": "estruturante", "type_display": "Estruturante", "owner_id": "8", "owner": "Fabiano Diretor", "deadline": "2025-12-31", "observations": "teste", "created_at": "2025-10-14T18:42:30.037559", "updated_at": "2025-10-14T18:42:30.037559", "key_results": []}]}	\N	\N	2025-10-14 21:42:30	2025-10-14 21:42:30	\N
2	5	company	open	\N	\N		2025-10-11 21:37:52	2025-10-18 14:23:00.015408-03	\N
4	5	participants	open	\N	\N		2025-10-11 22:44:08	2025-10-18 14:23:09.724522-03	\N
3	5	interviews	closed	Usuário	CURRENT_TIMESTAMP		2025-10-11 22:19:59	2025-10-18 14:23:22.427924-03	\N
\.


--
-- Data for Name: plan_segments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_segments (id, plan_id, name, description, audiences, differentials, evidences, personas, competitors_matrix, strategy, created_at) FROM stdin;
1	6	Móveis Modulares (Corporativo)	Atendimento a empreiteiros e construtores na região de Orlando com móveis planejados das unidades que serão entregues por estes aos clientes finais.	["Construtores", "Empreiteiros"]	["Peço competitivo"]	["Um dos possíveis sócios na parte de Antonio Carlos é construtor nos EUA e deu acesso aos números deste mercado, além de suas necessidades."]	[]	[]	{"positioning": {"promise": "", "narrative": "\\n", "next_steps": []}, "monetization": {"key_partners": ["Fornecedores no mundo todo que possam fornecer com preço e agilidade.", "Construtores (clientes finais)", "Empreiteiros"], "cost_structure": ["Insumos", "Montagem", "Fabricação", "Logística", "Garantia"], "revenue_streams": ["Venda de projetos modulares", "Instalação dos projetos", "Venda de projetos complementares para os clientes finais"]}, "value_proposition": {"problems": ["O preço pode ser menor."], "solution": "Atendimento, qualidade, pontualidade e preço competitivo."}}	2025-10-28 16:36:11.160102
2	6	Moveis Planejados (Renvendas)	\N	["Marceneiros autônomos"]	["Bom atendimento", "Parceria", "Preço competitivo", "Pontualidade"]	["Pesquisas com marceneiros da região apontam esse cenário."]	[{"nome": "Marceneiro Autônomo (Latino)", "idade": "Entre 30 e 50 anos preponderamente.", "perfil": "Imigrante que trabalha na região de Orlando e tem que vender pelo menos 3 projetos de USD 10 mil para pagar as contas.", "jornada": ["Conhecer", "Considerar", "Comprar", "Fidelizar"], "desafios": ["Vencer a concorrência"], "objetivos": ["Ter um parceiro que o apoie e o ajude a ter uma margem razoáel", "Ter um parceiro que dê respaldo técnico e de pós-venda em suas operações"]}]	[]	{"positioning": {"promise": "Executar projetos de marcenaria planejados (marceneiros) com um excelente preço, atendimento diferenciado e assistência técnica ao cliente presente.", "narrative": "Ser o melhor custo benefício para os marceneiros latinos da região.", "next_steps": ["Aumentar a capacidade operacional para atender 100 marceneiros. Ou investir no segmento corporativo."]}, "monetization": {"key_partners": ["Fornecedores no mundo todo que possam fornecer com preço e agilidade.", "Marceneiros Autônomos"], "cost_structure": ["Insumos", "Fabricação"], "revenue_streams": ["Venda de Projetos", "Venda de Serviços"]}, "journey_triggers": {"Compra": ["Venda de projetos para os clientes deste marceneiro e o mesmo escolher a nós como seu fornecedor"], "Descoberta": ["Boca a boca, Café da manhã e outros eventos"], "Fidelização": ["Entrega do que foi vendido produzindo uma percepção de valor superior ao que foi negociado"], "Consideração": ["Apresentação da qualidade e do atendimento nestas oportunidades"]}, "value_proposition": {"problems": ["Atendimento e qualidade deficitários para esse público nesta região"], "solution": "Fornecimento de projeto técnico e fabricação dos móveis vendidos pelos marceneiros\\n"}}	2025-10-28 16:39:53.133769
\.


--
-- Data for Name: plan_structure_capacities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_structure_capacities (id, plan_id, area, revenue_capacity, observations, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plan_structure_installments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_structure_installments (id, structure_id, installment_number, amount, due_info, installment_type, created_at, classification, repetition) FROM stdin;
2	1	1	1100	2026-05-08	Mensalidade	2025-10-28 17:00:45.886685	Despesa Fixa	Mensal
3	1	2	1100	2026-05-15	Mensalidade	2025-10-28 17:00:45.927204	Despesa Fixa	Mensal
4	1	3	1100	2026-05-22	Mensalidade	2025-10-28 17:00:45.950329	Despesa Fixa	Mensal
5	1	4	1100	2026-05-29	Mensalidade	2025-10-28 17:00:45.985293	Despesa Fixa	Mensal
6	2	1	14300	2026-05-08	Mensalidade	2025-10-28 17:02:54.023409	Custo Fixo	Mensal
7	2	2	14300	2026-05-15	Mensalidade	2025-10-28 17:02:54.033298	Custo Fixo	Mensal
8	2	3	14300	2026-05-22	Mensalidade	2025-10-28 17:02:54.045051	Custo Fixo	Mensal
9	2	4	14300	2026-05-29	Mensalidade	2025-10-28 17:02:54.066911	Custo Fixo	Mensal
10	3	1	1100	2026-05-08	Mensalidade	2025-10-28 17:05:19.997973	Despesa Fixa	Mensal
11	3	2	1100	2026-05-15	Mensalidade	2025-10-28 17:05:20.015097	Despesa Fixa	Mensal
12	3	3	1100	2026-05-22	Mensalidade	2025-10-28 17:05:20.02722	Despesa Fixa	Mensal
13	3	4	1100	2026-05-29	Mensalidade	2025-10-28 17:05:20.035368	Despesa Fixa	Mensal
14	4	1	180000	2026-01-15	Entrada	2025-10-28 17:07:23.254869	Investimento	Única
15	4	2	3200	2026-02-15	Mensalidade	2025-10-28 17:07:23.353293	Custo Fixo	Mensal
16	5	1	90500	2026-02-01	Entrada	2025-10-28 17:11:04.470661	Investimento	Única
17	5	2	45250	2026-03-30	Parcela	2025-10-28 17:11:04.483429	Investimento	Única
18	5	3	45250	2026-04-15	Parcela	2025-10-28 17:11:04.492681	Investimento	Única
19	6	1	14000	2026-04-01	Pagamento único	2025-10-28 17:12:57.584734	Investimento	Única
20	7	1	58500	2026-05-01	Pagamento único	2025-10-28 17:14:50.334431	Investimento	Única
21	8	1	5000	2026-05-01	Pagamento único	2025-10-28 17:16:06.980761	Investimento	Mensal
22	9	1	1500	2026-05-01	Mensalidade	2025-10-28 17:17:57.21535	Custo Fixo	Mensal
23	10	1	500	2026-05-01	Mensalidade	2025-10-28 17:18:50.663599	Custo Fixo	Mensal
24	11	1	1000	2026-05-01	Mensalidade	2025-10-28 17:21:13.333476	Custo Fixo	Mensal
25	12	1	1000	2026-05-01	Mensalidade	2025-10-28 17:24:27.941739	Custo Fixo	Mensal
26	14	1	1000	2026-05-01	Mensalidade	2025-10-28 17:27:25.342152	Custo Fixo	Mensal
27	15	1	10000	2026-02-01	Pagamento único	2025-10-28 17:31:03.504759	Investimento	Única
\.


--
-- Data for Name: plan_structures; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plan_structures (id, plan_id, area, block, item_type, description, value, repetition, payment_form, acquisition_info, availability_info, supplier, observations, status, sort_order, created_at) FROM stdin;
1	6	comercial	pessoas	Contratação	Assistente Comercial	R$ 4400,00		À vista	2026-05-01	2026-05-01	A Definir	Fazer recrutamento e seleção	active	0	2025-10-28 17:00:42.553945
2	6	operacional	pessoas	Contratação	Funcionários Operação	R$ 57200,00		À vista	2026-05-01	2026-05-01	A Definir	Fazer recrutamento e seleção	active	0	2025-10-28 17:02:51.365767
3	6	adm_fin	pessoas	Contratação	Assistente Adm / Fin	R$ 4400,00		À vista	2026-05-01	2026-05-01	A Definir	Fazer recrutamento e seleção	active	0	2025-10-28 17:03:38.033519
4	6	operacional	imoveis	Aquisição	Imóvel (Parte da Entrada)	R$ 600000,00		À vista	2026-01-15	2026-01-31	A Definir		active	0	2025-10-28 17:06:46.856818
5	6	operacional	maquinas_equipamentos	Aquisição	Maquinas (Valor China)	R$ 181000,00		À vista	2026-02-01	2026-04-15	A Definir		active	0	2025-10-28 17:09:31.584056
6	6	operacional	maquinas_equipamentos	Aquisição	Transporte dos Equipamentos	R$ 14000,00		À vista	2026-04-01	2026-04-01	A Definir		active	0	2025-10-28 17:12:09.184459
7	6	operacional	maquinas_equipamentos	Aquisição	Imposto de Importação Maquinas	R$ 58500,00		À vista	2026-05-01	2026-05-01	Governo Americano	Maquinas 181.000\nFrete = 14.000\nSubtotal: 195.000\nTaxa: 30% = 58.500	active	0	2025-10-28 17:14:30.773999
8	6	operacional	maquinas_equipamentos	Aquisição	Serviço de Intalação de Maquinas e Equipamentos	R$ 5000,00		À vista	2026-05-01	2026-05-01	A Definir		active	0	2025-10-28 17:16:05.243113
9	6	operacional	outros	Contratação	Energia Elétrica	R$ 1500,00		À vista	2026-05-01	2026-05-01	A Definir		active	0	2025-10-28 17:17:09.550053
10	6	operacional	maquinas_equipamentos	Contratação	Manutenção Industrial Mensal	R$ 500,00		À vista	2026-05-01	2026-05-01	A Definir		active	0	2025-10-28 17:18:48.775421
11	6	operacional	outros	Contratação	Carro (Locação / Combustível / Outros)	R$ 1000,00		À vista	2026-05-01	2026-05-01	A Definir		active	0	2025-10-28 17:20:15.05772
12	6	operacional	outros	Contratação	Outros Custos	R$ 1000,00		À vista	2026-05-01	2026-05-01	A Definir		active	0	2025-10-28 17:21:55.923091
13	6	adm_fin	outros	Contratação	Contabilidade / Jurídico	R$ 250,00		À vista	2026-05-01	2026-05-01	A Definir		active	0	2025-10-28 17:25:15.086977
14	6	operacional	outros	Contratação	Seguros	R$ 1000,00		À vista	2026-05-01	2026-05-01	A Definir		active	0	2025-10-28 17:26:52.545348
15	6	operacional	instalacoes	Aquisição	Infraestrutura do Galpão	R$ 10000,00		À vista	2026-02-01	2026-02-01	A Definir		active	0	2025-10-28 17:30:42.461853
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plans (id, company_id, name, description, start_date, end_date, year, status, created_at, plan_mode, updated_at) FROM stdin;
5	5	Planejamento de Crescimento 	Teste Fabiano	2025-10-10	2025-12-31	\N	active	2025-10-10 21:06:22	evolucao	2025-10-27 13:54:59.141505
6	25	Concepção Empresa de Móveis - EUA	Projeto criado para organização e validação do projeto da empresa de móveis nos EUA e criação dos projetos e atividades (com seus prazos, responsáveis e orçamentos).	2025-10-20	2026-03-31	\N	draft	2025-10-19 12:11:43.837928-03	evolucao	2025-10-27 13:54:59.141505
7	14	Implantação Gas Evolution	Plano de implantação para Gas Evolution	2025-10-01	2026-06-30	\N	draft	2025-10-27 13:54:59.141505-03	implantacao	2025-10-27 13:54:59.141505
8	13	Implantação Save Water	Plano de implantação Save Water	2025-10-15	2026-04-30	\N	draft	2025-10-27 13:55:13.279351-03	implantacao	2025-10-27 13:55:13.279351
\.


--
-- Data for Name: portfolios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.portfolios (id, company_id, code, name, responsible_id, notes, created_at, updated_at) FROM stdin;
1	5	01	Teste Portfolio	5	Teste	2025-10-11 04:06:21	2025-10-11 04:06:21
3	5	02	Portfolio Teste	5	\N	2025-10-11 15:11:19	2025-10-11 15:11:19
4	5	03	Portfolio Teste	5	\N	2025-10-11 15:11:23	2025-10-11 15:11:23
5	5	04	Portfolio Teste 200	3	\N	2025-10-11 15:12:09	2025-10-11 15:12:09
6	5	111	Teste 04	5	\N	2025-10-12 19:27:49	2025-10-12 19:27:49
7	13	Port-001	Reuniões de Diretoria - Mensais	\N	\N	2025-10-16 15:35:38	2025-10-16 15:35:38
8	13	Port-002	Reuniões de Gerência - Semanais	\N	\N	2025-10-16 15:36:02	2025-10-16 15:36:02
9	13	Port-003	Reuniões de Gestão	\N	\N	2025-10-16 15:37:09	2025-10-16 15:37:09
22	14	Prf-001	Geral	22	\N	2025-10-16 21:21:08	2025-10-16 21:21:08
23	14	Prf-002	Reuniões Gerenciais	22	\N	2025-10-16 21:21:28	2025-10-16 21:21:28
\.


--
-- Data for Name: process_activities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.process_activities (id, process_id, code, name, layout, order_index, created_at, updated_at) FROM stdin;
6	25	AB.C.2.1.1.01	Teste Atividade 01	dual	1	2025-10-09 13:37:26	2025-10-09 13:37:26
7	19	AB.C.1.1.3.01	Teste Atividade 01	dual	1	2025-10-09 14:08:22	2025-10-09 14:08:22
8	23	AB.C.1.3.2.01	Teste Atividade 01 Fabiano	dual	1	2025-10-09 14:31:32	2025-10-09 14:31:32
9	22	AB.C.1.3.1.01	Teste Atividade 01	dual	1	2025-10-09 14:46:57	2025-10-09 14:46:57
10	22	AB.C.1.3.1.02	Teste Atividade 02	dual	2	2025-10-09 14:47:04	2025-10-09 14:47:04
11	22	AB.C.1.3.1.03	Testa Atividade 03	dual	3	2025-10-09 14:47:16	2025-10-09 14:47:16
12	24	AB.C.1.3.3.01	Teste Atividade 01 Fabiano	dual	1	2025-10-09 14:56:31	2025-10-09 14:56:31
14	28	AB.C.2.1.4.01	Teste Atividade 01 Fabiano	dual	1	2025-10-09 15:11:38	2025-10-09 15:11:38
15	28	AB.C.2.1.4.02	Teste Atividade 02 Fabiano	dual	2	2025-10-09 15:23:18	2025-10-09 15:23:18
16	42	AB.C.3.1.5.01	01	dual	1	2025-10-09 15:47:30	2025-10-09 15:47:30
17	42	AB.C.3.1.5.02	02	dual	2	2025-10-09 15:48:43	2025-10-09 15:48:43
18	30	AB.C.2.1.6.01	Teste Atividade 01	dual	1	2025-10-09 16:40:32	2025-10-09 16:40:32
19	30	AB.C.2.1.6.02	Teste Atividade 02 Fabiano	dual	2	2025-10-09 16:40:52	2025-10-09 16:40:52
20	17	AB.C.1.1.1.02	Atividade 02	single	2	2025-10-09 17:15:40	2025-10-09 17:15:40
21	17	AB.C.1.1.1.03	Atividade 03	single	3	2025-10-09 17:25:16	2025-10-09 17:25:16
22	17	AB.C.1.1.1.04	Atividade 04	single	4	2025-10-09 17:31:44	2025-10-09 17:31:44
23	44	AB.C.3.2.1.01	Atividade 01	single	1	2025-10-09 17:37:11	2025-10-09 17:37:11
24	33	AB.C.2.2.3.01	Teste Fabiano 01	single	1	2025-10-09 17:52:07	2025-10-09 17:52:07
25	35	AB.C.2.3.1.01	Atividade 01	single	1	2025-10-09 17:59:06	2025-10-09 17:59:06
26	29	AB.C.2.1.5.01	Atividade 01	single	1	2025-10-09 18:01:06	2025-10-09 18:01:06
27	40	AB.C.3.1.3.01	Atividade 01	single	1	2025-10-09 18:10:50	2025-10-09 18:10:50
28	40	AB.C.3.1.3.02	Atividade 02	single	2	2025-10-09 18:15:53	2025-10-09 18:15:53
29	54	AB.C.3.3.4.01	Teste Fabiano 01	single	1	2025-10-09 18:41:30	2025-10-09 18:41:30
30	43	AB.C.3.1.6.01	Atividade 01	single	1	2025-10-09 18:56:37	2025-10-09 18:56:37
31	41	AB.C.3.1.4.02	teste	single	1	2025-10-09 21:18:43	2025-10-09 21:18:43
33	19	AB.C.1.1.3.02	Atividade 02	single	2	2025-10-10 12:13:23	2025-10-10 12:13:23
34	1	AO.C.1.1.1.01	Atividade 01	single	1	2025-10-10 15:09:50	2025-10-10 15:09:50
35	1	AO.C.1.1.1.02	Atividade 02	single	2	2025-10-10 15:15:04	2025-10-10 15:15:04
37	1	AO.C.1.1.1.03	Atividade 03	single	3	2025-10-10 15:18:48	2025-10-10 15:18:48
38	38	AB.C.3.1.1.01	Atividade 01	single	2	2025-10-11 00:27:43	2025-10-11 00:27:43
39	18	AB.C.1.1.2.01	yyy	single	1	2025-10-11 17:10:10	2025-10-11 17:10:10
40	17	AB.C.1.1.1.05	Atividade 05	single	5	2025-10-12 13:24:15	2025-10-12 13:28:38
41	17	AB.C.1.1.1.01	Atividade 01	single	6	2025-10-13 17:02:32	2025-10-13 17:02:32
42	93	AL.C.3.3.1.01	Emissão da Nota Fiscal via Conta Azul	single	1	2025-10-16 12:18:09	2025-10-16 12:18:09
\.


--
-- Data for Name: process_activity_entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.process_activity_entries (id, activity_id, order_index, text_content, image_path, image_width, created_at, updated_at, layout) FROM stdin;
1	34	1	Teste ldasjladfk jlkadfs jklçadsfj klçadsfjkl çadsfjklç adsfjklç adsfjklç adsf jklçads jklçdsdsjfkl sdajkl çadsjkl çdfsjkl çdfsjkladsf jkld jklçadf jklafd jkladf ajkldfs	process_activities/activity-34-20251010121030579883.png	280	2025-10-10 15:10:30	2025-10-10 15:10:30	dual
2	35	1	tesetesalçjk aes jlkdfsaj dfs jdsfkldf asjklçd sfajçkldsf jklçdfsjklçdsfa çjklfds jsdkafl	process_activities/activity-35-20251010121540099807.png	280	2025-10-10 15:15:40	2025-10-10 15:15:40	dual
5	37	1	Teste Atividade 03 - So texto	\N	280	2025-10-10 15:22:36	2025-10-10 15:22:50	dual
6	38	1	Teste	process_activities/activity-38-20251010212811043800.png	280	2025-10-11 00:28:11	2025-10-11 00:28:11	dual
7	38	2	teste	process_activities/activity-38-20251010212824352048.png	280	2025-10-11 00:28:24	2025-10-11 00:28:24	dual
8	38	3	teste 01	process_activities/activity-38-20251010212840721646.png	280	2025-10-11 00:28:40	2025-10-11 00:28:40	dual
9	40	1	teste	process_activities/activity-40-20251012102451769363.png	280	2025-10-12 13:24:51	2025-10-12 13:24:51	dual
10	40	2	teste	process_activities/activity-40-20251012102502907053.png	280	2025-10-12 13:25:02	2025-10-12 13:25:02	dual
11	40	3	teste	process_activities/activity-40-20251012102513010228.png	280	2025-10-12 13:25:13	2025-10-12 13:25:13	dual
12	22	1	atividade 04	process_activities/activity-22-20251012102604478752.png	280	2025-10-12 13:26:04	2025-10-12 13:27:24	dual
13	22	2	teste	process_activities/activity-22-20251012102620873990.png	280	2025-10-12 13:26:20	2025-10-12 13:26:20	dual
14	21	1	Atividade 03	process_activities/activity-21-20251012102750029149.png	524	2025-10-12 13:27:50	2025-10-13 16:48:43	dual
17	41	1	Tete jklçadsfjklçadfsjklç adsfjkl çdfajkl çdfjkl çdfsjklç dfasajklç fdjkladf çsdjkl sfçdfasjkl adsfjkl fdasjkl ads	process_activities/activity-41-20251013140324399596.png	280	2025-10-13 17:03:24	2025-10-13 17:03:24	dual
18	20	1	Teste Fabiano	process_activities/activity-20-20251013140359994683.png	272	2025-10-13 17:03:59	2025-10-13 17:03:59	dual
19	42	1	Inserir dado tal no campo x	process_activities/activity-42-20251016091846187277.png	280	2025-10-16 12:18:46	2025-10-16 12:18:46	dual
\.


--
-- Data for Name: process_areas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.process_areas (id, company_id, name, code, description, order_index, color, created_at, updated_at) FROM stdin;
1	1	Gestão	AO.C.1		1	#faa28b	2025-10-06 22:15:05	2025-10-07 23:36:40
2	1	Finalistico	AO.C.2		2	#b7d8ad	2025-10-06 22:15:11	2025-10-07 23:28:51
3	1	Apoio	AO.C.3		3	#a78bfa	2025-10-06 22:15:15	2025-10-07 23:28:28
4	1	TESTE 03	AO.C.4		4	#a78bfa	2025-10-07 19:34:31	2025-10-07 23:30:23
5	3	Gestão	AA.C.1		1	#a78bfa	2025-10-07 23:09:20	2025-10-07 23:09:20
7	3	Finalisticos	AA.C.2		2	#a78bfa	2025-10-07 23:13:35	2025-10-07 23:13:35
8	3	Apoio	AA.C.3		3	#a78bfa	2025-10-07 23:13:48	2025-10-07 23:13:48
9	5	Gestão	AB.C.1		1	#8891fd	2025-10-07 23:41:08	2025-10-07 23:47:46
10	5	Finalistica	AB.C.2		2	#fc9289	2025-10-07 23:41:18	2025-10-07 23:42:38
11	5	Apoio	AB.C.3		3	#fcfc89	2025-10-07 23:41:30	2025-10-07 23:42:59
12	13	GESTÃO	AL.C.1		1	#bdc4c8	2025-10-16 10:47:21	2025-10-16 10:47:21
13	13	FINALÍSTICOS	AL.C.2		2	#94c7f1	2025-10-16 10:47:42	2025-10-16 10:47:42
14	13	APOIO	AL.C.3		3	#acdda8	2025-10-16 10:47:59	2025-10-16 10:47:59
15	14	Gestão	AB.C.1		1	#88a3fd	2025-10-16 17:05:37	2025-10-16 17:08:25
16	14	Finalistico	AB.C.2		2	#9fe6a7	2025-10-16 17:05:46	2025-10-16 17:08:39
17	14	Apoio	AB.C.3		3	#e9e99c	2025-10-16 17:05:54	2025-10-16 17:09:12
\.


--
-- Data for Name: process_instances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.process_instances (id, company_id, process_id, routine_id, instance_code, title, description, status, priority, due_date, started_at, completed_at, assigned_collaborators, estimated_hours, actual_hours, notes, metadata, created_by, trigger_type, created_at, updated_at) FROM stdin;
1	5	33	\N	AA.P33.001	Teste	teste	pending	normal	2025-10-31 20:00:00	\N	\N	[]	0	\N	\N	\N	\N	manual	2025-10-11T14:44:20.999191	2025-10-11 17:44:20
2	5	17	\N	AA.P17.001	Teste Fabiano 02		pending	normal	2025-12-12 20:00:00	\N	\N	[]	0	\N	\N	\N	\N	manual	2025-10-11T14:49:04.212260	2025-10-11 17:49:04
3	5	18	\N	AA.P18.001	Teste de Instancia	Teste	completed	normal	2025-10-12 17:00:00	\N	2025-10-11 18:00:00	[]	0	\N	[{"timestamp":"2025-10-11T18:01:14.901Z","author":"Sistema","content":"Instância concluída. "},{"timestamp":"2025-10-11T18:01:02.616Z","author":"Usuário","content":"teste Fabiano."},{"timestamp":"2025-10-11T18:00:54.509Z","author":"Usuário","content":"Teste Fabiano"}]	\N	\N	manual	2025-10-11T14:58:12.586556	2025-10-11 18:01:14
\.


--
-- Data for Name: processes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.processes (id, company_id, macro_id, name, code, structuring_level, performance_level, responsible, description, order_index, created_at, updated_at, kanban_stage, flow_document, notes) FROM stdin;
1	1	1	Diagnostico Cenario Externo	AO.C.1.1.1		critical	Fabiano Ferreira		1	2025-10-06 22:18:49	2025-10-10 15:09:38	out_of_scope	process_flows/process-1-20251010120938.png	\N
2	1	1	Identidade Organizacional	AO.C.1.1.2	critical	initiated	Fabiano Ferreira		2	2025-10-06 22:19:36	2025-10-06 22:19:36	inbox	\N	\N
3	1	1	Planejamento Estratégico	AO.C.1.1.3			Fabiano Ferreira		3	2025-10-06 22:21:21	2025-10-10 15:13:36	out_of_scope	\N	\N
4	1	7	Gerir Contratações	AO.C.3.1.1			Fabiano Ferreira		1	2025-10-06 22:28:19	2025-10-06 22:28:19	inbox	\N	\N
5	1	7	Gerir Folha de Pagamento	AO.C.3.1.2			Fabiano Ferreira		2	2025-10-06 22:28:38	2025-10-06 22:28:38	inbox	\N	\N
6	1	7	Gerir Plano de Carreira e Promoções	AO.C.3.1.3			Fabiano Ferreira		3	2025-10-06 22:28:56	2025-10-06 22:28:56	inbox	\N	\N
7	1	7	Gerir Desligamentos	AO.C.3.1.4			Fabiano Ferreira		4	2025-10-06 22:29:15	2025-10-06 22:29:15	inbox	\N	\N
8	1	7	Gerir Benefícios	AO.C.3.1.5			Fabiano Ferreira		5	2025-10-06 22:29:33	2025-10-06 22:29:33	inbox	\N	\N
9	1	7	Gerir SST	AO.C.3.1.6			Fabiano Ferreira		6	2025-10-06 22:29:47	2025-10-06 22:29:47	inbox	\N	\N
10	1	7	Gerir Treinamentos e Planos de Desenvolvimento Pessoais	AO.C.3.1.7			Fabiano Ferreira		7	2025-10-06 22:30:14	2025-10-06 22:30:14	inbox	\N	\N
11	1	4	Gerir Marketing Digital	AO.C.2.1.1			Fabiano Ferreira		1	2025-10-06 22:30:54	2025-10-06 22:30:54	inbox	\N	\N
12	1	4	Gerir Indicações e Outras Fontes de Leads	AO.C.2.1.2			Fabiano Ferreira		2	2025-10-06 22:31:26	2025-10-06 22:31:26	inbox	\N	\N
13	1	4	Gerir Eventos e Outras Midias Pontuais	AO.C.2.1.3			Fabiano Ferreira		3	2025-10-06 22:31:46	2025-10-06 22:31:46	inbox	\N	\N
14	1	4	Gerir Vendas (do pré-atendimento ao fechamento)	AO.C.2.1.4			Fabiano Ferreira		4	2025-10-06 22:32:21	2025-10-06 22:32:21	inbox	\N	\N
15	1	4	Gerir Relacionamento com os Clientes	AO.C.2.1.5			Fabiano Ferreira		5	2025-10-06 22:32:37	2025-10-06 22:32:37	inbox	\N	\N
16	1	4	Gerir Encerramento de Contratos	AO.C.2.1.6			Fabiano Ferreira		6	2025-10-06 22:32:54	2025-10-06 22:32:54	inbox	\N	\N
17	5	20	Diagnostico Cenario Externo	AB.C.1.1.1	in_progress		Fabiano Ferreira		1	2025-10-07 23:54:54	2025-10-12 20:41:19	designing	process_flows/process-17-20251009131146.png	<p>Teste Observações</p>
18	5	20	Identidade Organizacional	AB.C.1.1.2			Fabiano Ferreira		2	2025-10-07 23:55:46	2025-10-12 15:57:41	out_of_scope	\N	\N
19	5	20	PLANEJAMENTO ESTRATÉGICO	AB.C.1.1.3	in_progress	initiated	Marcos		3	2025-10-07 23:56:21	2025-10-12 15:57:38	designing	process_flows/process-19-20251009110807.pdf	\N
20	5	18	Desenvolvimento de Produtos	AB.C.1.2.1	initiated	critical	Marcos Ferreira		1	2025-10-07 23:56:59	2025-10-08 22:10:37	designing	\N	\N
21	5	18	Desenvolvimento de Mercados	AB.C.1.2.2	structured	initiated	Marcos		2	2025-10-07 23:57:19	2025-10-08 22:10:38	deploying	\N	\N
22	5	19	GERIR PROCESSOS	AB.C.1.3.1			Fabiano Ferreira		1	2025-10-08 00:15:35	2025-10-09 14:54:39	stabilizing	process_flows/process-22-20251009115439.png	\N
23	5	19	GERIR PROJETOS	AB.C.1.3.2			Fabiano Ferreira		2	2025-10-08 00:15:56	2025-10-12 15:57:42	out_of_scope	process_flows/process-23-20251009114103.pdf	\N
24	5	19	AUDITORIA INTERNA	AB.C.1.3.3			Fabiano Ferreira		3	2025-10-08 00:16:18	2025-10-09 14:56:12	stable	process_flows/process-24-20251009115612.png	\N
25	5	21	Gerir Marketing Digital	AB.C.2.1.1					1	2025-10-08 00:29:58	2025-10-09 13:37:04	designing	process_flows/process-25-20251009103704.png	\N
26	5	21	GERIR INDICAÇÕES E OUTRAS FONTES DE LEADS	AB.C.2.1.2					2	2025-10-08 00:30:26	2025-10-08 22:10:50	deploying	\N	\N
27	5	21	GERIR EVENTOS E OUTRAS MIDIAS PONTUAIS	AB.C.2.1.3			Fabiano Ferreira		3	2025-10-08 00:30:51	2025-10-08 22:10:52	stabilizing	\N	\N
28	5	21	GERIR VENDAS (DO PRE ATENDIMENTO AO FECHAMENTO)	AB.C.2.1.4			Fabiano Ferreira		4	2025-10-08 00:31:19	2025-10-09 15:11:20	stable	process_flows/process-28-20251009121120.png	\N
29	5	21	GERIR RELACIONAMENTO COM CLIENTES ATIVOS	AB.C.2.1.5			Fabiano Ferreira		5	2025-10-08 00:31:41	2025-10-09 18:00:57	designing	process_flows/process-29-20251009150057.png	\N
30	5	21	GERIR ENCERRAMENTO DE CONTRATOS	AB.C.2.1.6			Fabiano Ferreira		6	2025-10-08 00:31:56	2025-10-09 16:40:22	deploying	process_flows/process-30-20251009134022.png	\N
31	5	22	GERIR IMPLANTAÇÃO DE NOVO CONTRATO	AB.C.2.2.1			Fabiano Ferreira		1	2025-10-08 00:32:53	2025-10-08 22:10:58	stabilizing	\N	\N
32	5	22	GERIR SERVIÇOS ROTINEIROS	AB.C.2.2.2			Fabiano Ferreira		2	2025-10-08 00:33:13	2025-10-08 22:10:59	stable	\N	\N
33	5	22	GERIR SERVIÇOS ESPORADICOS	AB.C.2.2.3			Fabiano Ferreira		3	2025-10-08 00:33:33	2025-10-09 17:51:52	designing	process_flows/process-33-20251009145152.png	\N
34	5	29	GERIR TELEFONIA/INTERNET (NEC|AQU|INST)	AB.C.3.6.3			Fabiano Ferreira		3	2025-10-08 00:33:56	2025-10-08 00:45:14	inbox	\N	\N
35	5	23	GERIR SERVIÇOS CONTABEIS PARCEIROS	AB.C.2.3.1			Fabiano Ferreira		1	2025-10-08 20:34:50	2025-10-09 17:58:56	designing	process_flows/process-35-20251009145856.png	\N
36	5	23	GERIR SERVICOS DE CONSULTORIA DE TERCEIROS	AB.C.2.3.2			Fabiano Ferreira		2	2025-10-08 20:35:18	2025-10-15 11:46:41	inbox	\N	\N
37	5	23	GERIR SERVIÇOS DE CAPTACAO DE RECURSOS DE PARCEIROS	AB.C.2.3.3			Fabiano Ferreira		3	2025-10-08 20:35:42	2025-10-08 22:15:08	designing	\N	\N
38	5	24	GERIR CONTRATAÇÕES	AB.C.3.1.1			Fabiano Ferreira		1	2025-10-08 20:36:52	2025-10-11 00:27:21	deploying	process_flows/process-38-20251010212721.png	\N
39	5	24	GERIR FOLHA DE PAGAMENTO	AB.C.3.1.2			Fabiano Ferreira		2	2025-10-08 20:37:12	2025-10-08 22:23:05	inbox	\N	\N
40	5	24	GERIR PLANO DE CARREIRAS E PROMOÇÕES	AB.C.3.1.3			Fabiano Ferreira		3	2025-10-08 20:37:35	2025-10-09 18:10:40	designing	process_flows/process-40-20251009151040.png	\N
41	5	24	GERIR DESLIGAMENTOS	AB.C.3.1.4			Fabiano Ferreira		4	2025-10-08 20:38:12	2025-10-09 21:16:02	deploying	process_flows/process-41-20251009181602.png	\N
42	5	24	GERIR BENEFICIOS	AB.C.3.1.5			Fabiano Ferreira		5	2025-10-08 20:38:33	2025-10-09 15:47:13	deploying	process_flows/process-42-20251009124713.png	\N
43	5	24	GERIR SST	AB.C.3.1.6			Fabiano Ferreira		6	2025-10-08 20:38:50	2025-10-09 18:56:27	stabilizing	process_flows/process-43-20251009155627.png	\N
147	14	54	Gerir Folha de Pagamento	AB.C.3.3.6					6	2025-10-16 18:15:43	2025-10-16 18:42:14	inbox	\N	\N
44	5	25	GERIR CONTAS A RECEBER	AB.C.3.2.1			Fabiano Ferreira		1	2025-10-08 20:39:13	2025-10-09 17:37:01	inbox	process_flows/process-44-20251009143701.png	\N
45	5	25	GERIR CONTAS A PAGAR	AB.C.3.2.2			Fabiano Ferreira		2	2025-10-08 20:39:32	2025-10-08 22:15:19	designing	\N	\N
46	5	25	GERIR CREDITO E COBRANÇA	AB.C.3.2.3			Fabiano Ferreira		3	2025-10-08 20:39:52	2025-10-08 22:15:20	designing	\N	\N
47	5	25	GERIR FLUXO DE CAIXA E TESOURARIA	AB.C.3.2.4			Fabiano Ferreira		4	2025-10-08 20:40:21	2025-10-08 22:15:21	deploying	\N	\N
48	5	25	GERIR DEMONSTRATIVOS FINANCEIROS	AB.C.3.2.5			Fabiano Ferreira		5	2025-10-08 20:40:43	2025-10-08 22:15:22	designing	\N	\N
49	5	25	GERIR ORÇAMENTO EMPRESARIAL	AB.C.3.2.6			Fabiano Ferreira		6	2025-10-08 20:41:14	2025-10-08 22:15:24	designing	\N	\N
50	5	25	GERIR FATURAMENTO PROPRIO E DE TERCEIROS	AB.C.3.2.7			Fabiano Ferreira		7	2025-10-08 20:42:31	2025-10-08 22:15:26	designing	\N	\N
51	5	26	GERIR EMISSÃO E REGISTRO DE DOCUMENTOS FISCAIS	AB.C.3.3.1			Fabiano Ferreira		1	2025-10-08 20:51:25	2025-10-08 22:23:07	inbox	\N	\N
52	5	26	GERIR CALCULO, ESCRITURAÇÃO E DECLARAÇÃO DE IMPOSTOS	AB.C.3.3.2			Fabiano Ferreira		2	2025-10-08 20:52:08	2025-10-08 22:15:28	designing	\N	\N
53	5	26	GERIR PLANEJAMENTO TRIBUTARIO	AB.C.3.3.3			Fabiano Ferreira		3	2025-10-08 20:52:36	2025-10-08 22:15:29	deploying	\N	\N
54	5	26	GERIR ESCRITURACAO E DECLARAÇÕES CONTABEIS	AB.C.3.3.4			Fabiano Ferreira		4	2025-10-08 20:53:13	2025-10-09 18:41:17	stabilizing	process_flows/process-54-20251009154117.png	\N
55	5	26	GERIR PORTFOLIO DE DOCS LEGAIS E CADASTRAIS	AB.C.3.3.5			Fabiano Ferreira		5	2025-10-08 20:53:48	2025-10-08 22:23:08	inbox	\N	\N
56	5	27	GERIR ARQUIVO FISICO	AB.C.3.4.1			Fabiano Ferreira		1	2025-10-08 20:54:18	2025-10-08 22:15:32	designing	\N	\N
57	5	27	GERIR ARQUIVO DIGITAL	AB.C.3.4.2			Fabiano Ferreira		2	2025-10-08 20:54:33	2025-10-08 22:23:08	inbox	\N	\N
58	5	28	GERIR NECESSIDADE DE AQUISIÇÃO DE ATIVOS	AB.C.3.5.1			Fabiano Ferreira		1	2025-10-08 20:54:54	2025-10-08 22:23:09	inbox	\N	\N
59	5	28	GERIR MANUTENÇÕES	AB.C.3.5.2			Fabiano Ferreira		2	2025-10-08 20:56:34	2025-10-08 22:23:10	inbox	\N	\N
60	5	28	GERIR VENDA E DESCARTE DE ATIVOS	AB.C.3.5.3			Fabiano Ferreira		3	2025-10-08 20:56:57	2025-10-08 20:56:57	inbox	\N	\N
61	5	29	GERIR SOFTWARE (MAN|INST|AQUIS)	AB.C.3.6.1			Fabiano Ferreira		1	2025-10-08 21:39:55	2025-10-08 22:23:11	inbox	\N	\N
62	5	29	GERIR HARDWARE (MAN|INST|AQUIS)	AB.C.3.6.2			Fabiano Ferreira		2	2025-10-08 21:40:15	2025-10-08 21:40:15	inbox	\N	\N
63	5	29	GERIR HARDWARE (MAN|INST|AQUIS)	AB.C.3.6.3			Fabiano Ferreira		3	2025-10-08 21:40:35	2025-10-08 21:40:35	inbox	\N	\N
64	13	30	Diagnostico	AL.C.1.1.1					1	2025-10-16 11:19:53	2025-10-16 15:12:38	inbox	\N	\N
65	13	30	Identidade Organizacional	AL.C.1.1.2					2	2025-10-16 11:37:13	2025-10-16 15:12:40	inbox	\N	\N
66	13	30	Planejamento Estratégico	AL.C.1.1.3					3	2025-10-16 11:37:34	2025-10-16 15:12:40	inbox	\N	\N
67	13	31	Desenvolvimento de Produtos	AL.C.1.2.1					1	2025-10-16 11:37:54	2025-10-16 15:12:41	inbox	\N	\N
68	13	31	Desenvolvimento de Mercados	AL.C.1.2.2					2	2025-10-16 11:38:09	2025-10-16 15:12:42	inbox	\N	\N
69	13	35	Gerir Processos	AL.C.1.3.1					1	2025-10-16 11:38:36	2025-10-16 15:12:42	inbox	\N	\N
70	13	35	Gerir Projetos	AL.C.1.3.2					2	2025-10-16 11:38:50	2025-10-16 15:12:43	inbox	\N	\N
71	13	35	Auditoria Interna	AL.C.1.3.3					3	2025-10-16 11:39:05	2025-10-16 15:12:44	inbox	\N	\N
72	13	33	Propaganda e Publicidade	AL.C.2.1.1					1	2025-10-16 11:39:33	2025-10-16 11:39:33	inbox	\N	\N
73	13	33	Prospecções	AL.C.2.1.2					2	2025-10-16 11:39:48	2025-10-16 11:39:48	inbox	\N	\N
74	13	33	Funil de Vendas	AL.C.2.1.3					3	2025-10-16 11:41:06	2025-10-16 11:41:06	inbox	\N	\N
75	13	34	Gerir Rentabilidade do Cliente	AL.C.2.2.1					1	2025-10-16 11:43:37	2025-10-16 11:43:37	inbox	\N	\N
76	13	34	Gerir Satisfação do Cliente	AL.C.2.2.2					2	2025-10-16 11:43:55	2025-10-16 11:43:55	inbox	\N	\N
77	13	36	Implantar Contratos	AL.C.2.3.1					1	2025-10-16 11:44:16	2025-10-16 11:44:16	inbox	\N	\N
78	13	36	Operacionalizar Contratos	AL.C.2.3.2					2	2025-10-16 11:44:55	2025-10-16 11:44:55	inbox	\N	\N
79	13	36	Encerrar Contratos	AL.C.2.3.3					3	2025-10-16 11:45:24	2025-10-16 11:45:24	inbox	\N	\N
80	13	37	Gerir Cadastro de Terceirizados (Prospecção | Ativação | Desativação)	AL.C.2.4.1					1	2025-10-16 11:48:25	2025-10-16 11:48:25	inbox	\N	\N
81	13	37	Gerir Contratação de Serviços Terceirizado (Negociação e Supervisão)	AL.C.2.4.2					2	2025-10-16 11:49:08	2025-10-16 11:49:08	inbox	\N	\N
82	13	37	Gerir Faturamento de Terceirizados	AL.C.2.4.3					3	2025-10-16 11:49:55	2025-10-16 11:49:55	inbox	\N	\N
83	13	38	Gerir Emissão e Registro de Documentos Fiscais	AL.C.3.1.1			Joseane		1	2025-10-16 11:50:25	2025-10-16 13:26:40	inbox	\N	\N
84	13	38	Gerir Cálculo, Escrituração e Declaração de Impostos	AL.C.3.1.2			Joseane		2	2025-10-16 11:51:30	2025-10-16 13:37:49	inbox	\N	\N
85	13	38	Gerir Planejamento Triburário	AL.C.3.1.3					3	2025-10-16 11:52:05	2025-10-16 13:49:04	inbox	\N	\N
86	13	38	Gerir Escrituração e Declarações Contábeis	AL.C.3.1.4			Joseane		4	2025-10-16 11:52:55	2025-10-16 13:48:57	inbox	\N	\N
87	13	38	Gerir Portfólio de Docs Legais e Cadastrais	AL.C.3.1.5			Joseane		5	2025-10-16 11:53:23	2025-10-16 13:49:13	inbox	\N	\N
88	13	39	Gerir Recrutamento e Seleção	AL.C.3.2.1					1	2025-10-16 11:53:54	2025-10-16 11:53:54	inbox	\N	\N
89	13	39	Gerir Contratação e Integração	AL.C.3.2.2					2	2025-10-16 11:54:15	2025-10-16 11:54:15	inbox	\N	\N
90	13	39	Gerir Treinamentos	AL.C.3.2.3					3	2025-10-16 11:54:31	2025-10-16 11:54:31	inbox	\N	\N
91	13	39	Gerir Plano de Carreira e Promoções	AL.C.3.2.4					4	2025-10-16 11:54:48	2025-10-16 11:54:48	inbox	\N	\N
92	13	39	Gerir Desligamentos	AL.C.3.2.5					5	2025-10-16 11:57:25	2025-10-16 11:57:25	inbox	\N	\N
93	13	40	Gerir Faturamento	AL.C.3.3.1	in_progress		Joseane		1	2025-10-16 11:57:44	2025-10-16 15:18:51	designing	process_flows/process-93-20251016091734.png	\N
94	13	40	Gerir Contas a Receber / Recebidas	AL.C.3.3.2	in_progress		Joseane		2	2025-10-16 11:58:05	2025-10-16 15:18:55	designing	\N	\N
95	13	40	Gerir Contas a Pagar / Pagas	AL.C.3.3.3	in_progress		Joseane		3	2025-10-16 11:58:24	2025-10-16 15:19:01	designing	\N	\N
96	13	40	Gerir Conciliação Bancária	AL.C.3.3.4	in_progress		Joseane		4	2025-10-16 11:58:45	2025-10-16 15:19:04	designing	\N	\N
97	13	40	Gerir Demonstrações Financeiras	AL.C.3.3.5					5	2025-10-16 11:59:18	2025-10-16 11:59:18	inbox	\N	\N
98	13	40	Gerir Fundo Fixo / Cartões Corporativos	AL.C.3.3.6	in_progress		Joseane		6	2025-10-16 11:59:46	2025-10-16 15:19:11	designing	\N	\N
99	13	40	Gerir Crédito e Cobrança	AL.C.3.3.7	in_progress		Joseane		7	2025-10-16 12:00:07	2025-10-16 15:19:14	designing	\N	\N
100	13	40	Gerir Fluxo de Caixa (Aplicações | Empréstimos | Prorrogações)	AL.C.3.3.8					8	2025-10-16 12:00:58	2025-10-16 12:00:58	inbox	\N	\N
104	13	42	Gerir Arquivo Físico	AL.C.3.5.1			Joseane		1	2025-10-16 12:02:52	2025-10-16 13:50:39	inbox	\N	\N
105	13	42	Gerir Arquivos Digitais	AL.C.3.5.2			Joseane		2	2025-10-16 12:03:07	2025-10-16 13:50:46	inbox	\N	\N
106	13	43	Gerir Inventário / Necessidade / Aquisição / Locação de Ativos	AL.C.3.6.1					1	2025-10-16 12:04:13	2025-10-16 12:04:13	inbox	\N	\N
107	13	43	Gerir Manutenções	AL.C.3.6.2					2	2025-10-16 12:04:29	2025-10-16 12:04:29	inbox	\N	\N
108	13	43	Gerir Descarte / Devolução / Venda de Ativos	AL.C.3.6.3					3	2025-10-16 12:05:00	2025-10-16 12:05:00	inbox	\N	\N
109	13	44	Gerir Software (Necess / Instal / Manut)	AL.C.3.7.1					1	2025-10-16 12:05:40	2025-10-16 12:05:40	inbox	\N	\N
110	13	44	Gerir Hardware (Necess / Instal / Manut)	AL.C.3.7.2					2	2025-10-16 12:06:00	2025-10-16 12:06:00	inbox	\N	\N
111	13	32	Gerir Admissões	AL.C.3.8.1			Joseane		1	2025-10-16 12:06:20	2025-10-16 13:51:03	inbox	\N	\N
112	13	32	Gerir Folha de Pagamento	AL.C.3.8.2			Joseane		2	2025-10-16 12:06:34	2025-10-16 13:51:10	inbox	\N	\N
113	13	32	Gerir Férias	AL.C.3.8.3			Joseane		3	2025-10-16 12:06:50	2025-10-16 13:51:16	inbox	\N	\N
114	13	32	Gerir Rescisões	AL.C.3.8.4			Joseane		4	2025-10-16 12:07:19	2025-10-16 13:51:25	inbox	\N	\N
115	13	32	Gerir SST	AL.C.3.8.5			Joseane		5	2025-10-16 12:07:36	2025-10-16 13:51:32	inbox	\N	\N
116	13	32	Gerir Beneficios	AL.C.3.8.6			Joseane		6	2025-10-16 12:07:47	2025-10-16 13:51:39	inbox	\N	\N
117	14	45	Diagnostico	AB.C.1.1.1					1	2025-10-16 17:45:27	2025-10-16 18:38:32	out_of_scope	\N	\N
118	14	45	Identidade Organizacional	AB.C.1.1.2					2	2025-10-16 17:48:53	2025-10-16 18:38:34	out_of_scope	\N	\N
119	14	45	PLANEJAMENTO ESTRATÉGICO	AB.C.1.1.3					3	2025-10-16 17:49:08	2025-10-16 18:38:36	out_of_scope	\N	\N
120	14	46	Desenvolvimento de Produtos	AB.C.1.2.1					1	2025-10-16 17:49:25	2025-10-16 18:38:37	out_of_scope	\N	\N
121	14	46	Desenvolvimento de Mercados	AB.C.1.2.2					2	2025-10-16 17:49:32	2025-10-16 18:38:38	out_of_scope	\N	\N
122	14	47	GERIR PROCESSOS	AB.C.1.3.1					1	2025-10-16 17:49:49	2025-10-16 18:40:59	inbox	\N	\N
123	14	47	GERIR PROJETOS	AB.C.1.3.2					2	2025-10-16 17:50:01	2025-10-16 18:41:00	inbox	\N	\N
124	14	47	Auditoria Interna	AB.C.1.3.3					3	2025-10-16 17:50:20	2025-10-16 18:38:49	out_of_scope	\N	\N
126	14	48	GERIR NECESSIDADE E SUGESTÃO DE COMPRAS	AB.C.2.1.1					1	2025-10-16 18:07:46	2025-10-16 18:41:02	inbox	\N	\N
127	14	48	GERIR COMPRAS	AB.C.2.1.2					2	2025-10-16 18:08:05	2025-10-16 18:41:03	inbox	\N	\N
128	14	49	GERIR RECEPÇÃO DE COMRPAS	AB.C.2.2.1					1	2025-10-16 18:08:30	2025-10-16 18:41:06	inbox	\N	\N
129	14	49	GERIR REPOSIÇÃO DE ESTQQUE NOS POSTOS DE VENDAS	AB.C.2.2.2					2	2025-10-16 18:08:50	2025-10-16 18:41:08	inbox	\N	\N
130	14	49	GERIR INVENTÁRIOS (DEPÓSITO E POSTOS DE VENDAS)	AB.C.2.2.3					3	2025-10-16 18:10:00	2025-10-16 18:41:13	inbox	\N	\N
131	14	50	VENDAS - POSTOS	AB.C.2.3.1	in_progress				1	2025-10-16 18:10:20	2025-10-16 19:26:15	designing	process_flows/process-131-20251016162615.png	\N
132	14	50	GERIR PROPAGANDA	AB.C.2.3.2					2	2025-10-16 18:10:34	2025-10-16 18:39:28	out_of_scope	\N	\N
133	14	50	GERIR SANGRIA E DESPESAS NOS POSTOS	AB.C.2.3.3	in_progress				3	2025-10-16 18:10:52	2025-10-16 18:39:31	designing	\N	\N
134	14	52	GERIR DESLIGAMENTOS	AB.C.3.1.2					2	2025-10-16 18:11:06	2025-10-16 18:39:33	out_of_scope	\N	\N
135	14	53	GERIR CONTAS A RECEBER	AB.C.3.2.1	in_progress				1	2025-10-16 18:13:18	2025-10-16 18:39:51	designing	\N	\N
136	14	53	GERIR DEMONSTRAÇÕES FINANCEIRAS	AB.C.3.2.2	in_progress				2	2025-10-16 18:13:31	2025-10-16 18:39:53	designing	\N	\N
137	14	53	GERIR CONTAS A PAGAR	AB.C.3.2.3	in_progress				3	2025-10-16 18:13:41	2025-10-16 18:39:55	designing	\N	\N
138	14	53	GERIR CREDITO E COBRANÇA	AB.C.3.2.4	in_progress				4	2025-10-16 18:13:52	2025-10-16 18:39:58	designing	\N	\N
139	14	53	GERIR FLUXO DE CAIXA E TESOURARIA	AB.C.3.2.5	in_progress				5	2025-10-16 18:14:02	2025-10-16 18:40:00	designing	\N	\N
140	14	53	GERIR ORÇAMENTO EMPRESARIAL	AB.C.3.2.6	in_progress				6	2025-10-16 18:14:13	2025-10-16 18:40:02	designing	\N	\N
141	14	53	GERIR CONFERENCIA DE CAIXA	AB.C.3.2.7	in_progress				7	2025-10-16 18:14:25	2025-10-16 18:40:04	designing	\N	\N
142	14	54	GERIR EMISSÃO E REGISTRO DE DOCS FISCAIS	AB.C.3.3.1					1	2025-10-16 18:14:42	2025-10-16 18:41:33	inbox	\N	\N
143	14	54	GERIR CALCULO, ESCRITURAÇÃO E DECLARAÇÃO DE IMPOSTOS	AB.C.3.3.2					2	2025-10-16 18:14:55	2025-10-16 18:41:35	inbox	\N	\N
144	14	54	GERIR PLANEJAMENTO TRIBUTARIO	AB.C.3.3.3					3	2025-10-16 18:15:08	2025-10-16 18:41:36	inbox	\N	\N
145	14	54	Gerir Escrituração e Declarações Contábeis	AB.C.3.3.4					4	2025-10-16 18:15:21	2025-10-16 18:41:38	inbox	\N	\N
146	14	54	Gerir Portfólio de Docs Legais e Cadastrais	AB.C.3.3.5	in_progress				5	2025-10-16 18:15:32	2025-10-16 18:41:43	designing	\N	\N
103	13	41	Gerir Estoques de Insumos de Laboratorio	AL.C.3.4.3	in_progress				3	2025-10-16 12:02:29	2025-10-20 11:14:53.968983-03	designing	\N	\N
148	14	54	GERIR SST	AB.C.3.3.7					7	2025-10-16 18:15:53	2025-10-16 18:40:29	out_of_scope	\N	\N
149	14	51	Gerir Demanda Jurídica Passiva (Réu)	AB.C.3.7.2					2	2025-10-16 18:16:15	2025-10-16 18:40:43	out_of_scope	\N	\N
150	14	57	GERIR ARQUIVO FISICO	AB.C.3.4.1	in_progress				1	2025-10-16 18:26:44	2025-10-16 18:42:01	designing	\N	\N
151	14	57	GERIR ARQUIVO DIGITAL	AB.C.3.4.2	in_progress				2	2025-10-16 18:26:54	2025-10-16 18:41:58	designing	\N	\N
152	14	55	GERIR NECESSIDADE DE AQUISIÇÃO DE ATIVOS	AB.C.3.5.1					1	2025-10-16 18:27:20	2025-10-16 18:40:36	out_of_scope	\N	\N
153	14	55	GERIR MANUTENÇÕES	AB.C.3.5.2					2	2025-10-16 18:27:37	2025-10-16 18:40:37	out_of_scope	\N	\N
154	14	55	GERIR VENDA E DESCARTE DE ATIVOS	AB.C.3.5.3					3	2025-10-16 18:27:49	2025-10-16 18:40:39	out_of_scope	\N	\N
155	14	55	GERIR COMBUSTIVEIS	AB.C.3.5.4					4	2025-10-16 18:28:03	2025-10-16 18:40:40	out_of_scope	\N	\N
156	14	56	Gerir Software (Necess / Instal / Manut)	AB.C.3.6.1					1	2025-10-16 18:28:59	2025-10-16 18:40:41	out_of_scope	\N	\N
157	14	56	Gerir Hardware (Necess / Instal / Manut)	AB.C.3.6.2					2	2025-10-16 18:29:18	2025-10-16 18:40:42	out_of_scope	\N	\N
158	14	51	Gerir Demanda Jurídica Ativa (Autor)	AB.C.3.7.1					1	2025-10-16 18:29:48	2025-10-16 18:40:43	out_of_scope	\N	\N
101	13	41	Gerir Compras	AL.C.3.4.1	in_progress				1	2025-10-16 12:01:27	2025-10-20 10:34:25.879028-03	designing	\N	\N
102	13	41	Gerir Estoques de Produtos Quimicos	AL.C.3.4.2	in_progress				2	2025-10-16 12:02:08	2025-10-20 11:14:52.185779-03	designing	\N	\N
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (id, plan_id, title, description, status, priority, owner, start_date, end_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: report_instances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report_instances (id, model_id, title, report_type, company_id, generated_at, file_path, status) FROM stdin;
\.


--
-- Data for Name: report_models; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report_models (id, name, description, paper_size, orientation, margin_top, margin_right, margin_bottom, margin_left, header_height, header_rows, header_columns, header_content, footer_height, footer_rows, footer_columns, footer_content, created_at, updated_at, created_by) FROM stdin;
7	Retrato Margem Minima Sem Cabeçalho e Rodape	Retrato Margem Minima Sem Cabeçalho e Rodape	A4	Retrato	5	5	5	5	0	0	0		0	0	0		2025-10-12 20:43:15	2025-10-17 21:54:48	\N
8	Relatório POP Padrão	Modelo com cabeçalho/rodapé do gerador - Margens 5mm	A4	Retrato	5	5	5	5	25	1	3		15	1	3		2025-10-12 21:28:39	2025-10-12 21:34:54	\N
9	Organograma 01	Organograma 01	A4	Paisagem	5	5	5	5	0	0	0		12	1	2		2025-10-15 14:06:09	2025-10-15 14:06:09	\N
16	Retrato Margem Minima Sem Cabeçalho e Rodape	Retrato Margem Minima Sem Cabeçalho e Rodape	A4	Retrato	5	5	5	5	0	0	0		0	0	0		2025-10-17 21:38:38	2025-10-17 21:38:38	system
\.


--
-- Data for Name: report_patterns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report_patterns (id, name, code, description, pattern_type, sections_config, created_at, updated_at) FROM stdin;
1	Relatório Executivo de Processo	EXEC_PROC	Relatório resumido para executivos com foco em indicadores e resumo	process	{"sections": [{"id": "info", "name": "Informa\\u00e7\\u00f5es do Processo", "required": true}, {"id": "flow", "name": "Fluxo do Processo", "required": true}, {"id": "indicators", "name": "Indicadores de Desempenho", "required": true}]}	2025-10-17 01:16:23	2025-10-17 01:16:23
2	Relatório Operacional Completo	OP_COMPLETE	Relatório completo com todas as seções para uso operacional	process	{"sections": [{"id": "info", "name": "Informa\\u00e7\\u00f5es do Processo", "required": true}, {"id": "flow", "name": "Fluxo do Processo", "required": true}, {"id": "pop", "name": "Procedimento Operacional", "required": true}, {"id": "routine", "name": "Rotinas e Colaboradores", "required": true}, {"id": "indicators", "name": "Indicadores de Desempenho", "required": true}]}	2025-10-17 01:16:23	2025-10-17 01:16:23
3	Relatório de Auditoria	AUDIT	Relatório focado em auditoria com POP e rotinas detalhadas	process	{"sections": [{"id": "info", "name": "Informa\\u00e7\\u00f5es do Processo", "required": true}, {"id": "pop", "name": "Procedimento Operacional", "required": true}, {"id": "routine", "name": "Rotinas e Colaboradores", "required": true}, {"id": "indicators", "name": "Indicadores de Desempenho", "required": true}]}	2025-10-17 01:16:23	2025-10-17 01:16:23
\.


--
-- Data for Name: report_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report_templates (id, name, description, page_config_id, report_type, sections_config, created_at, updated_at, created_by) FROM stdin;
1	Relatório de Reuniões - Padrão	Template completo para relatórios de reuniões com todas as seções	10	meetings	{"summary": {"enabled": true, "title": "Resumo Executivo", "description": "Vis\\u00e3o geral das reuni\\u00f5es do per\\u00edodo"}, "meetings_list": {"enabled": true, "title": "Lista de Reuni\\u00f5es", "description": "Detalhes de todas as reuni\\u00f5es realizadas"}, "participants_analysis": {"enabled": true, "title": "An\\u00e1lise de Participantes", "description": "Estat\\u00edsticas de participa\\u00e7\\u00e3o"}, "conclusions": {"enabled": true, "title": "Conclus\\u00f5es e Recomenda\\u00e7\\u00f5es", "description": "An\\u00e1lise final e pr\\u00f3ximos passos"}}	2025-10-17 11:08:15	2025-10-17 11:08:15	\N
2	Relatório de Reuniões - Resumido	Template resumido para relatórios de reuniões	11	meetings	{"summary": {"enabled": true, "title": "Resumo Executivo", "description": "Vis\\u00e3o geral das reuni\\u00f5es do per\\u00edodo"}, "meetings_list": {"enabled": true, "title": "Lista de Reuni\\u00f5es", "description": "Detalhes das reuni\\u00f5es principais"}, "participants_analysis": {"enabled": false, "title": "An\\u00e1lise de Participantes", "description": "Estat\\u00edsticas de participa\\u00e7\\u00e3o"}, "conclusions": {"enabled": true, "title": "Conclus\\u00f5es", "description": "Principais conclus\\u00f5es"}}	2025-10-17 11:08:15	2025-10-17 11:08:15	\N
3	Relatório de Reuniões - Padrão	Template completo para relatórios de reuniões com todas as seções	12	meetings	{"summary": {"enabled": true, "title": "Resumo Executivo", "description": "Vis\\u00e3o geral das reuni\\u00f5es do per\\u00edodo"}, "meetings_list": {"enabled": true, "title": "Lista de Reuni\\u00f5es", "description": "Detalhes de todas as reuni\\u00f5es realizadas"}, "participants_analysis": {"enabled": true, "title": "An\\u00e1lise de Participantes", "description": "Estat\\u00edsticas de participa\\u00e7\\u00e3o"}, "conclusions": {"enabled": true, "title": "Conclus\\u00f5es e Recomenda\\u00e7\\u00f5es", "description": "An\\u00e1lise final e pr\\u00f3ximos passos"}}	2025-10-17 11:08:18	2025-10-17 11:08:18	\N
4	Relatório de Reuniões - Resumido	Template resumido para relatórios de reuniões	13	meetings	{"summary": {"enabled": true, "title": "Resumo Executivo", "description": "Vis\\u00e3o geral das reuni\\u00f5es do per\\u00edodo"}, "meetings_list": {"enabled": true, "title": "Lista de Reuni\\u00f5es", "description": "Detalhes das reuni\\u00f5es principais"}, "participants_analysis": {"enabled": false, "title": "An\\u00e1lise de Participantes", "description": "Estat\\u00edsticas de participa\\u00e7\\u00e3o"}, "conclusions": {"enabled": true, "title": "Conclus\\u00f5es", "description": "Principais conclus\\u00f5es"}}	2025-10-17 11:08:18	2025-10-17 11:08:18	\N
5	Relatório de Reuniões - Personalizado	Template personalizado para relatórios de reuniões com foco em análise de produtividade	12	meetings	{"summary": {"enabled": true, "title": "Resumo Executivo", "description": "Vis\\u00e3o geral das reuni\\u00f5es do per\\u00edodo"}, "meetings_list": {"enabled": true, "title": "Lista Detalhada de Reuni\\u00f5es", "description": "Detalhes de todas as reuni\\u00f5es realizadas"}, "participants_analysis": {"enabled": true, "title": "An\\u00e1lise de Participa\\u00e7\\u00e3o", "description": "Estat\\u00edsticas detalhadas de participa\\u00e7\\u00e3o"}, "conclusions": {"enabled": true, "title": "Conclus\\u00f5es e Pr\\u00f3ximos Passos", "description": "An\\u00e1lise final e recomenda\\u00e7\\u00f5es"}}	2025-10-17 11:09:46	2025-10-17 11:09:46	\N
6	Relatório de Reuniões - Personalizado	Template personalizado para relatórios de reuniões com foco em análise de produtividade	12	meetings	{"summary": {"enabled": true, "title": "Resumo Executivo", "description": "Vis\\u00e3o geral das reuni\\u00f5es do per\\u00edodo"}, "meetings_list": {"enabled": true, "title": "Lista Detalhada de Reuni\\u00f5es", "description": "Detalhes de todas as reuni\\u00f5es realizadas"}, "participants_analysis": {"enabled": true, "title": "An\\u00e1lise de Participa\\u00e7\\u00e3o", "description": "Estat\\u00edsticas detalhadas de participa\\u00e7\\u00e3o"}, "conclusions": {"enabled": true, "title": "Conclus\\u00f5es e Pr\\u00f3ximos Passos", "description": "An\\u00e1lise final e recomenda\\u00e7\\u00f5es"}}	2025-10-17 11:09:55	2025-10-17 11:09:55	\N
7	Template Teste - Model 7 - Relatórios Executivos	Template de teste usando Model 7 - Relatórios Executivos	12	meetings	{"summary": {"enabled": true, "title": "Resumo"}, "meetings_list": {"enabled": true, "title": "Reuni\\u00f5es"}, "conclusions": {"enabled": true, "title": "Conclus\\u00f5es"}}	2025-10-17 11:09:55	2025-10-17 11:09:55	\N
8	Template Teste - Model 8 - Relatórios Técnicos	Template de teste usando Model 8 - Relatórios Técnicos	13	meetings	{"summary": {"enabled": true, "title": "Resumo"}, "meetings_list": {"enabled": true, "title": "Reuni\\u00f5es"}, "conclusions": {"enabled": true, "title": "Conclus\\u00f5es"}}	2025-10-17 11:09:55	2025-10-17 11:09:55	\N
9	Teste Fabiano 100	Teste de Relatórios	12	meetings	{"summary": {"enabled": true, "title": "Resumo Executivo"}, "list": {"enabled": true, "title": "Lista Detalhada"}, "analysis": {"enabled": true, "title": "An\\u00e1lise"}, "conclusions": {"enabled": true, "title": "Conclus\\u00f5es"}}	2025-10-17 12:58:56	2025-10-17 12:58:56	\N
10	Teste Fabiano 100	Teste Fabiano Descrição Template 100	12	meetings	{"summary": {"enabled": true, "title": "Resumo Executivo"}, "list": {"enabled": true, "title": "Lista Detalhada"}, "analysis": {"enabled": true, "title": "An\\u00e1lise"}, "conclusions": {"enabled": true, "title": "Conclus\\u00f5es"}}	2025-10-17 13:00:47	2025-10-17 13:00:47	\N
11	Teste	teste	10	meetings	{"summary": {"enabled": true, "title": "Resumo Executivo"}, "list": {"enabled": true, "title": "Lista Detalhada"}, "analysis": {"enabled": true, "title": "An\\u00e1lise"}, "conclusions": {"enabled": true, "title": "Conclus\\u00f5es"}}	2025-10-17 13:02:06	2025-10-17 13:02:06	\N
12	Teste Fabiano 100	Teste Fabiano 100	12	meetings	{"summary": {"enabled": true, "title": "Resumo Executivo"}, "list": {"enabled": true, "title": "Lista Detalhada"}, "analysis": {"enabled": true, "title": "An\\u00e1lise"}, "conclusions": {"enabled": true, "title": "Conclus\\u00f5es"}}	2025-10-17 13:03:27	2025-10-17 13:03:27	\N
13	Reunião Finalizada - Model 7	Relatório de reunião realizada e finalizada com seções completas	12	meetings	{"titulo_reuniao": {"enabled": true, "title": "T\\u00edtulo da Reuni\\u00e3o"}, "dados_agendamento": {"enabled": true, "title": "Dados do Agendamento"}, "pauta": {"enabled": true, "title": "Pauta"}, "convidados": {"enabled": true, "title": "Convidados"}, "observacoes": {"enabled": true, "title": "Observa\\u00e7\\u00f5es"}, "participantes": {"enabled": true, "title": "Participantes"}, "discussoes": {"enabled": true, "title": "Discuss\\u00f5es"}, "projeto_atividades": {"enabled": true, "title": "Projeto e Atividades Cadastradas"}, "notas_gerais": {"enabled": true, "title": "Notas Gerais"}, "atividades_geradas": {"enabled": true, "title": "Atividades Geradas"}}	2025-10-17 14:51:26	2025-10-17 14:51:26	\N
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, company_id, title, parent_role_id, reports_to, department, color, headcount_planned, weekly_hours, notes, created_at, updated_at) FROM stdin;
1	5	Diretor	\N	\N	Diretoria	\N	0	0		2025-10-10 20:41:34	2025-10-10 20:41:34
2	5	Gerente Comercial	1	\N	Comercial	\N	0	0		2025-10-10 20:41:50	2025-10-10 21:30:02
5	5	Gerente Operacional	1	\N	Operação	\N	0	0		2025-10-10 20:55:44	2025-10-10 21:30:10
6	5	Gerente Administrativo e Financeiro	1	\N	Financeiro	\N	0	0		2025-10-10 20:56:00	2025-10-12 22:33:52
8	6	teste	\N	\N	teste	\N	0	0	teste	2025-10-10 22:29:44	2025-10-10 22:29:44
9	5	Assistente Financeiro	6	\N	Financeiro	\N	0	0	Teste	2025-10-10 22:50:41	2025-10-10 22:50:41
11	5	Assistente Fiscal	6	\N	Financeiro	\N	0	0		2025-10-14 19:40:53	2025-10-14 19:40:53
12	5	Assistente Administrativo	6	\N	Financeiro	\N	0	0		2025-10-14 19:41:20	2025-10-14 19:41:20
13	5	Vendedor PME	2	\N	Comercial	\N	0	0		2025-10-14 19:42:10	2025-10-14 19:42:10
14	5	Vendedor Midle	2	\N	Comercial	\N	0	0		2025-10-14 19:42:28	2025-10-14 19:42:28
15	5	Vendedor Grandes Empresas	2	\N	Comercial	\N	0	0		2025-10-14 19:42:54	2025-10-14 19:42:54
16	5	Assistente Operacional 01	5	\N	Operação	\N	0	0		2025-10-14 19:43:25	2025-10-14 19:43:25
17	5	Assistente Operacional 02	5	\N	Operação	\N	0	0		2025-10-14 19:43:44	2025-10-14 19:43:44
18	5	Assistente Operacional 03	5	\N	Operação	\N	0	0		2025-10-14 19:43:59	2025-10-14 19:43:59
19	13	Diretor	\N	\N	Diretoria	\N	0	0		2025-10-16 10:07:51	2025-10-16 10:07:51
20	13	Gestor Comercial	19	\N	Comercial	\N	0	0		2025-10-16 10:08:12	2025-10-16 10:08:12
21	13	Gestor Adm/Fin	19	\N	Financeiro	\N	0	0		2025-10-16 10:08:34	2025-10-16 10:08:34
22	13	Gestor Operacional	19	\N	Operação	\N	0	0		2025-10-16 10:08:52	2025-10-16 10:08:52
23	13	Assistente Adm/Fin	21	\N	Financeiro	\N	0	0		2025-10-16 10:09:40	2025-10-16 10:09:40
24	13	Assistente Operacional	22	\N	Operação	\N	0	0		2025-10-16 10:10:07	2025-10-16 10:10:07
25	13	RTS	22	\N	Operação	\N	0	0		2025-10-16 10:10:31	2025-10-16 10:10:31
26	14	Diretor	\N	\N	Diretoria	\N	0	0		2025-10-16 15:23:01	2025-10-16 15:23:01
27	14	Gestor Comercial	26	\N	Comercial	\N	0	0		2025-10-16 15:23:15	2025-10-16 15:23:15
28	14	Gestor Operacional / Suprimentos	26	\N	Operaação Suprimentos	\N	0	0		2025-10-16 15:23:45	2025-10-16 15:23:45
29	14	Gestor Adm/Fin	26	\N	Financeiro	\N	0	0		2025-10-16 15:24:01	2025-10-16 15:24:01
33	14	Auxiliar Adm/Fin	29	\N	Adm/Fin	\N	0	0		2025-10-16 17:00:03	2025-10-16 17:05:06
34	14	Consultor	\N	\N		\N	0	0		2025-10-16 18:36:32	2025-10-16 18:36:32
35	13	Consultor	\N	\N		\N	0	0		2025-10-16 22:18:28	2025-10-16 22:18:28
36	15	Diretor	\N	\N	Diretoria	\N	0	0		2025-10-16 22:53:56	2025-10-16 22:53:56
37	15	Gestor Operacional	36	\N	Operação	\N	0	0		2025-10-16 22:54:21	2025-10-16 22:54:21
38	15	Gestor Adm/Fin	36	\N	Adm/Fin	\N	0	0		2025-10-16 22:54:40	2025-10-16 22:54:40
39	15	Gestor de Tecnologia	36	\N	TI	\N	0	0		2025-10-16 22:55:30	2025-10-16 22:55:30
40	15	Gestor Comercial	36	\N	Comercial	\N	0	0		2025-10-16 22:55:44	2025-10-16 22:55:44
\.


--
-- Data for Name: routine_collaborators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.routine_collaborators (id, routine_id, employee_id, hours_used, notes, created_at, updated_at) FROM stdin;
1	13	3	7.5		2025-10-11 00:30:33	2025-10-11 00:30:33
2	13	4	4		2025-10-11 00:30:50	2025-10-11 00:30:50
3	15	3	4		2025-10-11 00:41:48	2025-10-11 00:41:48
4	15	5	8		2025-10-11 00:41:57	2025-10-11 00:41:57
5	17	3	4		2025-10-11 01:31:34	2025-10-11 01:31:34
6	17	5	2		2025-10-11 01:31:42	2025-10-11 01:31:42
7	17	4	2		2025-10-11 01:31:58	2025-10-11 01:31:58
8	18	16	4		2025-10-16 12:19:55	2025-10-16 12:19:55
\.


--
-- Data for Name: routine_tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.routine_tasks (id, routine_id, trigger_id, title, description, scheduled_date, deadline_date, status, completed_at, completed_by, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: routine_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.routine_triggers (id, routine_id, trigger_type, trigger_value, deadline_value, deadline_unit, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: routines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.routines (id, company_id, name, description, is_active, created_at, updated_at, process_id, schedule_type, schedule_value, deadline_days, deadline_date, deadline_hours) FROM stdin;
1	1	Folha de Pgto		1	2025-10-10 16:22:20	2025-10-10 16:22:20	5	monthly	25	\N	\N	0
2	1	Folha de Pgto	teste	1	2025-10-10 16:23:00	2025-10-10 16:23:00	5	monthly	25	5	\N	0
3	5	Planej. Estratégico Anual		1	2025-10-10 18:31:40	2025-10-10 18:31:40	19	yearly	2025-01-01	180	\N	0
4	5	Teste 02		1	2025-10-10 19:52:09	2025-10-10 19:52:09	18	daily	10:00	1	\N	0
5	5	Teste 03		1	2025-10-10 20:06:54	2025-10-11 00:45:12	20	monthly	20	1	\N	0
8	5	Teste		1	2025-10-11 00:05:43	2025-10-11 00:05:43	63	daily	07:00	0	\N	12
11	5	Teste 02	teste	1	2025-10-11 00:14:32	2025-10-11 00:14:32	21	daily	10:00	0	\N	4
13	5	Rotina 01		1	2025-10-11 00:30:01	2025-10-11 00:31:04	38	monthly	10	5	\N	0
15	5	Teste 03		1	2025-10-11 00:41:26	2025-10-11 00:42:08	22	weekly	segunda,terca,quarta,quinta,sexta,sabado	1	\N	12
16	5	Teste 04 - Fantasia		1	2025-10-11 00:44:27	2025-10-11 00:44:27	34	monthly	15	5	\N	0
17	5	Teste 04		1	2025-10-11 01:31:24	2025-10-11 01:31:24	17	monthly	15	1	\N	0
18	13	Faturamento		1	2025-10-16 12:19:40	2025-10-16 12:19:40	93	monthly	04	1	\N	0
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team_members (id, team_id, employee_id, role, joined_at, left_at) FROM stdin;
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teams (id, company_id, name, description, leader_id, created_at, updated_at, is_active) FROM stdin;
\.


--
-- Data for Name: user_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_logs (id, user_id, user_email, user_name, action, entity_type, entity_id, entity_name, old_values, new_values, ip_address, user_agent, endpoint, method, description, company_id, plan_id, created_at) FROM stdin;
1	\N	anonymous	Usuário Anônimo	CREATE	test	1	Teste	\N	\N	127.0.0.1	Test/Script	test	SYSTEM	Teste de inserção com user_id NULL	\N	\N	2025-10-15 11:28:35.303851
2	1	admin@versus.com.br	Administrador	CREATE	test	2	Teste com User	\N	\N	127.0.0.1	Test/Script	test	SYSTEM	Teste de inserção com user_id válido	\N	\N	2025-10-15 11:28:35.318453
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password_hash, name, role, is_active, created_at, updated_at) FROM stdin;
2	admin@versus.com.br	pbkdf2:sha256:600000$dF6PNsXwaKfRMSmW$ce7a96ad3fa917d9a99caae72824b5b37ccc3abc85992c2dc23381506f4db203	Administrador	admin	t	2025-10-15 13:38:29	2025-10-15 13:38:29
\.


--
-- Data for Name: vision_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vision_records (id, plan_id, participants, consultants, vision_date, format, notes, created_at, updated_at) FROM stdin;
1	5	Fulano e Ciclano	Fabiano	2025-12-31	Online	jlkadjçsjlkçdfsaj lkçfjdklç afjkls dfajklç fjdslkfdjkl çadfjkl 	2025-10-13 21:23:43	2025-10-13 21:23:43
\.


--
-- Data for Name: workshop_discussions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workshop_discussions (id, plan_id, section_type, content, created_at, updated_at) FROM stdin;
1	5	preliminary	lçajkdsf dsajkladsfjl kdasfjkl çadsfjklç adsfjkl çdsf jklçdfssjklç a dsfjklçsdf jkladsjkl dsfk ldsf jk sdafjkldf	2025-10-14 15:13:43	2025-10-15 10:17:16
\.


--
-- Name: activity_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activity_comments_id_seq', 1, false);


--
-- Name: activity_work_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activity_work_logs_id_seq', 1, false);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.companies_id_seq', 25, true);


--
-- Name: company_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.company_data_id_seq', 5, true);


--
-- Name: company_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.company_projects_id_seq', 45, false);


--
-- Name: drivers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.drivers_id_seq', 1, false);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employees_id_seq', 26, true);


--
-- Name: indicator_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.indicator_data_id_seq', 3, true);


--
-- Name: indicator_goals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.indicator_goals_id_seq', 4, true);


--
-- Name: indicator_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.indicator_groups_id_seq', 7, true);


--
-- Name: indicators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.indicators_id_seq', 7, true);


--
-- Name: interviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.interviews_id_seq', 2, true);


--
-- Name: macro_processes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.macro_processes_id_seq', 57, true);


--
-- Name: meeting_agenda_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.meeting_agenda_items_id_seq', 1, false);


--
-- Name: meetings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.meetings_id_seq', 5, true);


--
-- Name: occurrences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.occurrences_id_seq', 2, true);


--
-- Name: okr_area_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.okr_area_records_id_seq', 3, true);


--
-- Name: okr_global_key_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.okr_global_key_results_id_seq', 1, false);


--
-- Name: okr_global_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.okr_global_records_id_seq', 2, true);


--
-- Name: okrs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.okrs_id_seq', 1, false);


--
-- Name: participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.participants_id_seq', 8, true);


--
-- Name: plan_alignment_agenda_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_alignment_agenda_id_seq', 1, false);


--
-- Name: plan_alignment_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_alignment_members_id_seq', 3, true);


--
-- Name: plan_alignment_principles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_alignment_principles_id_seq', 1, false);


--
-- Name: plan_finance_business_distribution_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_finance_business_distribution_id_seq', 1, false);


--
-- Name: plan_finance_business_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_finance_business_periods_id_seq', 1, false);


--
-- Name: plan_finance_funding_sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_finance_funding_sources_id_seq', 6, true);


--
-- Name: plan_finance_investment_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_finance_investment_categories_id_seq', 8, true);


--
-- Name: plan_finance_investment_contributions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_finance_investment_contributions_id_seq', 5, true);


--
-- Name: plan_finance_investment_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_finance_investment_items_id_seq', 24, true);


--
-- Name: plan_finance_investments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_finance_investments_id_seq', 1, false);


--
-- Name: plan_finance_investor_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_finance_investor_periods_id_seq', 1, false);


--
-- Name: plan_finance_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_finance_metrics_id_seq', 1, false);


--
-- Name: plan_finance_premises_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_finance_premises_id_seq', 1, false);


--
-- Name: plan_finance_profit_distribution_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_finance_profit_distribution_id_seq', 1, true);


--
-- Name: plan_finance_result_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_finance_result_rules_id_seq', 1, true);


--
-- Name: plan_finance_sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_finance_sources_id_seq', 1, false);


--
-- Name: plan_finance_variable_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_finance_variable_costs_id_seq', 1, false);


--
-- Name: plan_implantation_checkpoints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_implantation_checkpoints_id_seq', 1, false);


--
-- Name: plan_implantation_phases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_implantation_phases_id_seq', 1, false);


--
-- Name: plan_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_products_id_seq', 2, true);


--
-- Name: plan_sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_sections_id_seq', 16, true);


--
-- Name: plan_segments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_segments_id_seq', 2, true);


--
-- Name: plan_structure_capacities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_structure_capacities_id_seq', 3, true);


--
-- Name: plan_structure_installments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_structure_installments_id_seq', 27, true);


--
-- Name: plan_structures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plan_structures_id_seq', 15, true);


--
-- Name: plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plans_id_seq', 8, true);


--
-- Name: portfolios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.portfolios_id_seq', 23, true);


--
-- Name: process_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.process_activities_id_seq', 42, true);


--
-- Name: process_areas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.process_areas_id_seq', 17, true);


--
-- Name: processes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.processes_id_seq', 158, true);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.projects_id_seq', 1, false);


--
-- Name: report_instances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.report_instances_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 40, true);


--
-- Name: routine_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.routine_tasks_id_seq', 1, false);


--
-- Name: routine_triggers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.routine_triggers_id_seq', 1, false);


--
-- Name: routines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.routines_id_seq', 18, true);


--
-- Name: team_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.team_members_id_seq', 1, false);


--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.teams_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: workshop_discussions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.workshop_discussions_id_seq', 1, true);


--
-- Name: activity_comments activity_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_comments
    ADD CONSTRAINT activity_comments_pkey PRIMARY KEY (id);


--
-- Name: activity_work_logs activity_work_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_work_logs
    ADD CONSTRAINT activity_work_logs_pkey PRIMARY KEY (id);


--
-- Name: alignment_records alignment_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alignment_records
    ADD CONSTRAINT alignment_records_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_data company_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_data
    ADD CONSTRAINT company_data_pkey PRIMARY KEY (id);


--
-- Name: company_projects company_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_projects
    ADD CONSTRAINT company_projects_pkey PRIMARY KEY (id);


--
-- Name: company_records company_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_records
    ADD CONSTRAINT company_records_pkey PRIMARY KEY (id);


--
-- Name: directional_records directional_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.directional_records
    ADD CONSTRAINT directional_records_pkey PRIMARY KEY (id);


--
-- Name: drivers drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: indicator_data indicator_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.indicator_data
    ADD CONSTRAINT indicator_data_pkey PRIMARY KEY (id);


--
-- Name: indicator_goals indicator_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.indicator_goals
    ADD CONSTRAINT indicator_goals_pkey PRIMARY KEY (id);


--
-- Name: indicator_groups indicator_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.indicator_groups
    ADD CONSTRAINT indicator_groups_pkey PRIMARY KEY (id);


--
-- Name: indicators indicators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.indicators
    ADD CONSTRAINT indicators_pkey PRIMARY KEY (id);


--
-- Name: interviews interviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT interviews_pkey PRIMARY KEY (id);


--
-- Name: macro_processes macro_processes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.macro_processes
    ADD CONSTRAINT macro_processes_pkey PRIMARY KEY (id);


--
-- Name: market_records market_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_records
    ADD CONSTRAINT market_records_pkey PRIMARY KEY (id);


--
-- Name: meeting_agenda_items meeting_agenda_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meeting_agenda_items
    ADD CONSTRAINT meeting_agenda_items_pkey PRIMARY KEY (id);


--
-- Name: meetings meetings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meetings
    ADD CONSTRAINT meetings_pkey PRIMARY KEY (id);


--
-- Name: misalignment_records misalignment_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.misalignment_records
    ADD CONSTRAINT misalignment_records_pkey PRIMARY KEY (id);


--
-- Name: occurrences occurrences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.occurrences
    ADD CONSTRAINT occurrences_pkey PRIMARY KEY (id);


--
-- Name: okr_area_preliminary_records okr_area_preliminary_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.okr_area_preliminary_records
    ADD CONSTRAINT okr_area_preliminary_records_pkey PRIMARY KEY (id);


--
-- Name: okr_area_records okr_area_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.okr_area_records
    ADD CONSTRAINT okr_area_records_pkey PRIMARY KEY (id);


--
-- Name: okr_global_key_results okr_global_key_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.okr_global_key_results
    ADD CONSTRAINT okr_global_key_results_pkey PRIMARY KEY (id);


--
-- Name: okr_global_records okr_global_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.okr_global_records
    ADD CONSTRAINT okr_global_records_pkey PRIMARY KEY (id);


--
-- Name: okr_preliminary_records okr_preliminary_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.okr_preliminary_records
    ADD CONSTRAINT okr_preliminary_records_pkey PRIMARY KEY (id);


--
-- Name: okrs okrs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.okrs
    ADD CONSTRAINT okrs_pkey PRIMARY KEY (id);


--
-- Name: participants participants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participants
    ADD CONSTRAINT participants_pkey PRIMARY KEY (id);


--
-- Name: plan_alignment_agenda plan_alignment_agenda_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_alignment_agenda
    ADD CONSTRAINT plan_alignment_agenda_pkey PRIMARY KEY (id);


--
-- Name: plan_alignment_members plan_alignment_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_alignment_members
    ADD CONSTRAINT plan_alignment_members_pkey PRIMARY KEY (id);


--
-- Name: plan_alignment_overview plan_alignment_overview_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_alignment_overview
    ADD CONSTRAINT plan_alignment_overview_pkey PRIMARY KEY (plan_id);


--
-- Name: plan_alignment_principles plan_alignment_principles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_alignment_principles
    ADD CONSTRAINT plan_alignment_principles_pkey PRIMARY KEY (id);


--
-- Name: plan_alignment_project plan_alignment_project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_alignment_project
    ADD CONSTRAINT plan_alignment_project_pkey PRIMARY KEY (plan_id);


--
-- Name: plan_finance_business_distribution plan_finance_business_distribution_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_business_distribution
    ADD CONSTRAINT plan_finance_business_distribution_pkey PRIMARY KEY (id);


--
-- Name: plan_finance_business_periods plan_finance_business_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_business_periods
    ADD CONSTRAINT plan_finance_business_periods_pkey PRIMARY KEY (id);


--
-- Name: plan_finance_funding_sources plan_finance_funding_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_funding_sources
    ADD CONSTRAINT plan_finance_funding_sources_pkey PRIMARY KEY (id);


--
-- Name: plan_finance_investment_categories plan_finance_investment_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_investment_categories
    ADD CONSTRAINT plan_finance_investment_categories_pkey PRIMARY KEY (id);


--
-- Name: plan_finance_investment_contributions plan_finance_investment_contributions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_investment_contributions
    ADD CONSTRAINT plan_finance_investment_contributions_pkey PRIMARY KEY (id);


--
-- Name: plan_finance_investment_items plan_finance_investment_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_investment_items
    ADD CONSTRAINT plan_finance_investment_items_pkey PRIMARY KEY (id);


--
-- Name: plan_finance_investments plan_finance_investments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_investments
    ADD CONSTRAINT plan_finance_investments_pkey PRIMARY KEY (id);


--
-- Name: plan_finance_investor_periods plan_finance_investor_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_investor_periods
    ADD CONSTRAINT plan_finance_investor_periods_pkey PRIMARY KEY (id);


--
-- Name: plan_finance_metrics plan_finance_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_metrics
    ADD CONSTRAINT plan_finance_metrics_pkey PRIMARY KEY (id);


--
-- Name: plan_finance_metrics plan_finance_metrics_plan_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_metrics
    ADD CONSTRAINT plan_finance_metrics_plan_id_key UNIQUE (plan_id);


--
-- Name: plan_finance_premises plan_finance_premises_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_premises
    ADD CONSTRAINT plan_finance_premises_pkey PRIMARY KEY (id);


--
-- Name: plan_finance_profit_distribution plan_finance_profit_distribution_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_profit_distribution
    ADD CONSTRAINT plan_finance_profit_distribution_pkey PRIMARY KEY (id);


--
-- Name: plan_finance_profit_distribution plan_finance_profit_distribution_plan_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_profit_distribution
    ADD CONSTRAINT plan_finance_profit_distribution_plan_id_key UNIQUE (plan_id);


--
-- Name: plan_finance_result_rules plan_finance_result_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_result_rules
    ADD CONSTRAINT plan_finance_result_rules_pkey PRIMARY KEY (id);


--
-- Name: plan_finance_sources plan_finance_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_sources
    ADD CONSTRAINT plan_finance_sources_pkey PRIMARY KEY (id);


--
-- Name: plan_finance_variable_costs plan_finance_variable_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_variable_costs
    ADD CONSTRAINT plan_finance_variable_costs_pkey PRIMARY KEY (id);


--
-- Name: plan_implantation_checkpoints plan_implantation_checkpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_implantation_checkpoints
    ADD CONSTRAINT plan_implantation_checkpoints_pkey PRIMARY KEY (id);


--
-- Name: plan_implantation_dashboard plan_implantation_dashboard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_implantation_dashboard
    ADD CONSTRAINT plan_implantation_dashboard_pkey PRIMARY KEY (plan_id);


--
-- Name: plan_implantation_phases plan_implantation_phases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_implantation_phases
    ADD CONSTRAINT plan_implantation_phases_pkey PRIMARY KEY (id);


--
-- Name: plan_implantation_phases plan_implantation_phases_plan_id_phase_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_implantation_phases
    ADD CONSTRAINT plan_implantation_phases_plan_id_phase_key_key UNIQUE (plan_id, phase_key);


--
-- Name: plan_products plan_products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_products
    ADD CONSTRAINT plan_products_pkey PRIMARY KEY (id);


--
-- Name: plan_sections plan_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_sections
    ADD CONSTRAINT plan_sections_pkey PRIMARY KEY (id);


--
-- Name: plan_segments plan_segments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_segments
    ADD CONSTRAINT plan_segments_pkey PRIMARY KEY (id);


--
-- Name: plan_structure_capacities plan_structure_capacities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_structure_capacities
    ADD CONSTRAINT plan_structure_capacities_pkey PRIMARY KEY (id);


--
-- Name: plan_structure_capacities plan_structure_capacities_plan_id_area_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_structure_capacities
    ADD CONSTRAINT plan_structure_capacities_plan_id_area_key UNIQUE (plan_id, area);


--
-- Name: plan_structure_installments plan_structure_installments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_structure_installments
    ADD CONSTRAINT plan_structure_installments_pkey PRIMARY KEY (id);


--
-- Name: plan_structures plan_structures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_structures
    ADD CONSTRAINT plan_structures_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: portfolios portfolios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portfolios
    ADD CONSTRAINT portfolios_pkey PRIMARY KEY (id);


--
-- Name: process_activities process_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_activities
    ADD CONSTRAINT process_activities_pkey PRIMARY KEY (id);


--
-- Name: process_activity_entries process_activity_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_activity_entries
    ADD CONSTRAINT process_activity_entries_pkey PRIMARY KEY (id);


--
-- Name: process_areas process_areas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_areas
    ADD CONSTRAINT process_areas_pkey PRIMARY KEY (id);


--
-- Name: process_instances process_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_instances
    ADD CONSTRAINT process_instances_pkey PRIMARY KEY (id);


--
-- Name: processes processes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processes
    ADD CONSTRAINT processes_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: report_instances report_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_instances
    ADD CONSTRAINT report_instances_pkey PRIMARY KEY (id);


--
-- Name: report_models report_models_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_models
    ADD CONSTRAINT report_models_pkey PRIMARY KEY (id);


--
-- Name: report_patterns report_patterns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_patterns
    ADD CONSTRAINT report_patterns_pkey PRIMARY KEY (id);


--
-- Name: report_templates report_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_templates
    ADD CONSTRAINT report_templates_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: routine_collaborators routine_collaborators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routine_collaborators
    ADD CONSTRAINT routine_collaborators_pkey PRIMARY KEY (id);


--
-- Name: routine_tasks routine_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routine_tasks
    ADD CONSTRAINT routine_tasks_pkey PRIMARY KEY (id);


--
-- Name: routine_triggers routine_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routine_triggers
    ADD CONSTRAINT routine_triggers_pkey PRIMARY KEY (id);


--
-- Name: routines routines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routines
    ADD CONSTRAINT routines_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_team_id_employee_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_employee_id_key UNIQUE (team_id, employee_id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: user_logs user_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_logs
    ADD CONSTRAINT user_logs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vision_records vision_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vision_records
    ADD CONSTRAINT vision_records_pkey PRIMARY KEY (id);


--
-- Name: workshop_discussions workshop_discussions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workshop_discussions
    ADD CONSTRAINT workshop_discussions_pkey PRIMARY KEY (id);


--
-- Name: idx_alignment_agenda_plan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alignment_agenda_plan_id ON public.plan_alignment_agenda USING btree (plan_id);


--
-- Name: idx_alignment_members_plan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alignment_members_plan_id ON public.plan_alignment_members USING btree (plan_id);


--
-- Name: idx_alignment_principles_plan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alignment_principles_plan_id ON public.plan_alignment_principles USING btree (plan_id);


--
-- Name: idx_comments_activity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_comments_activity ON public.activity_comments USING btree (activity_type, activity_id);


--
-- Name: idx_comments_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_comments_created ON public.activity_comments USING btree (created_at);


--
-- Name: idx_comments_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_comments_employee ON public.activity_comments USING btree (employee_id);


--
-- Name: idx_company_projects_end_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_projects_end_date ON public.company_projects USING btree (end_date);


--
-- Name: idx_company_projects_executor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_projects_executor ON public.company_projects USING btree (executor_id);


--
-- Name: idx_company_projects_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_projects_priority ON public.company_projects USING btree (priority);


--
-- Name: idx_company_projects_responsible; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_projects_responsible ON public.company_projects USING btree (responsible_id);


--
-- Name: idx_company_projects_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_projects_status ON public.company_projects USING btree (status);


--
-- Name: idx_employees_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_company ON public.employees USING btree (company_id);


--
-- Name: idx_employees_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_role ON public.employees USING btree (role_id);


--
-- Name: idx_employees_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_user ON public.employees USING btree (user_id);


--
-- Name: idx_employees_user_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_employees_user_unique ON public.employees USING btree (user_id) WHERE (user_id IS NOT NULL);


--
-- Name: idx_funding_sources_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_funding_sources_date ON public.plan_finance_funding_sources USING btree (contribution_date);


--
-- Name: idx_funding_sources_plan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_funding_sources_plan ON public.plan_finance_funding_sources USING btree (plan_id);


--
-- Name: idx_investment_categories_plan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_investment_categories_plan ON public.plan_finance_investment_categories USING btree (plan_id);


--
-- Name: idx_investment_contributions_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_investment_contributions_date ON public.plan_finance_investment_contributions USING btree (contribution_date);


--
-- Name: idx_investment_contributions_item; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_investment_contributions_item ON public.plan_finance_investment_contributions USING btree (item_id);


--
-- Name: idx_investment_items_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_investment_items_category ON public.plan_finance_investment_items USING btree (category_id);


--
-- Name: idx_team_members_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_team_members_employee ON public.team_members USING btree (employee_id);


--
-- Name: idx_team_members_team; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_team_members_team ON public.team_members USING btree (team_id);


--
-- Name: idx_teams_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_teams_active ON public.teams USING btree (is_active);


--
-- Name: idx_teams_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_teams_company ON public.teams USING btree (company_id);


--
-- Name: idx_teams_leader; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_teams_leader ON public.teams USING btree (leader_id);


--
-- Name: idx_work_logs_activity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_work_logs_activity ON public.activity_work_logs USING btree (activity_type, activity_id);


--
-- Name: idx_work_logs_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_work_logs_date ON public.activity_work_logs USING btree (work_date);


--
-- Name: idx_work_logs_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_work_logs_employee ON public.activity_work_logs USING btree (employee_id);


--
-- Name: company_projects trg_company_projects_updated_at_row; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_company_projects_updated_at_row BEFORE UPDATE ON public.company_projects FOR EACH ROW EXECUTE FUNCTION public.trg_company_projects_updated_at();


--
-- Name: activity_work_logs trigger_update_worked_hours; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_worked_hours AFTER INSERT ON public.activity_work_logs FOR EACH ROW EXECUTE FUNCTION public.update_activity_worked_hours();


--
-- Name: activity_comments activity_comments_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_comments
    ADD CONSTRAINT activity_comments_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: activity_work_logs activity_work_logs_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_work_logs
    ADD CONSTRAINT activity_work_logs_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: employees employees_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: plan_alignment_agenda plan_alignment_agenda_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_alignment_agenda
    ADD CONSTRAINT plan_alignment_agenda_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_alignment_members plan_alignment_members_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_alignment_members
    ADD CONSTRAINT plan_alignment_members_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_alignment_overview plan_alignment_overview_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_alignment_overview
    ADD CONSTRAINT plan_alignment_overview_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_alignment_principles plan_alignment_principles_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_alignment_principles
    ADD CONSTRAINT plan_alignment_principles_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_alignment_project plan_alignment_project_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_alignment_project
    ADD CONSTRAINT plan_alignment_project_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_finance_business_distribution plan_finance_business_distribution_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_business_distribution
    ADD CONSTRAINT plan_finance_business_distribution_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.plan_finance_business_periods(id) ON DELETE CASCADE;


--
-- Name: plan_finance_business_periods plan_finance_business_periods_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_business_periods
    ADD CONSTRAINT plan_finance_business_periods_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_finance_funding_sources plan_finance_funding_sources_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_funding_sources
    ADD CONSTRAINT plan_finance_funding_sources_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_finance_investment_categories plan_finance_investment_categories_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_investment_categories
    ADD CONSTRAINT plan_finance_investment_categories_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_finance_investment_contributions plan_finance_investment_contributions_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_investment_contributions
    ADD CONSTRAINT plan_finance_investment_contributions_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.plan_finance_investment_items(id) ON DELETE CASCADE;


--
-- Name: plan_finance_investment_items plan_finance_investment_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_investment_items
    ADD CONSTRAINT plan_finance_investment_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.plan_finance_investment_categories(id) ON DELETE CASCADE;


--
-- Name: plan_finance_investments plan_finance_investments_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_investments
    ADD CONSTRAINT plan_finance_investments_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_finance_investor_periods plan_finance_investor_periods_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_investor_periods
    ADD CONSTRAINT plan_finance_investor_periods_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_finance_metrics plan_finance_metrics_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_metrics
    ADD CONSTRAINT plan_finance_metrics_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_finance_premises plan_finance_premises_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_premises
    ADD CONSTRAINT plan_finance_premises_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_finance_profit_distribution plan_finance_profit_distribution_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_profit_distribution
    ADD CONSTRAINT plan_finance_profit_distribution_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_finance_result_rules plan_finance_result_rules_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_result_rules
    ADD CONSTRAINT plan_finance_result_rules_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_finance_sources plan_finance_sources_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_sources
    ADD CONSTRAINT plan_finance_sources_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_finance_variable_costs plan_finance_variable_costs_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_finance_variable_costs
    ADD CONSTRAINT plan_finance_variable_costs_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_implantation_checkpoints plan_implantation_checkpoints_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_implantation_checkpoints
    ADD CONSTRAINT plan_implantation_checkpoints_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_implantation_dashboard plan_implantation_dashboard_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_implantation_dashboard
    ADD CONSTRAINT plan_implantation_dashboard_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_implantation_phases plan_implantation_phases_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_implantation_phases
    ADD CONSTRAINT plan_implantation_phases_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_products plan_products_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_products
    ADD CONSTRAINT plan_products_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_segments plan_segments_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_segments
    ADD CONSTRAINT plan_segments_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_structure_capacities plan_structure_capacities_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_structure_capacities
    ADD CONSTRAINT plan_structure_capacities_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_structure_installments plan_structure_installments_structure_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_structure_installments
    ADD CONSTRAINT plan_structure_installments_structure_id_fkey FOREIGN KEY (structure_id) REFERENCES public.plan_structures(id) ON DELETE CASCADE;


--
-- Name: plan_structures plan_structures_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_structures
    ADD CONSTRAINT plan_structures_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: team_members team_members_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: team_members team_members_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: teams teams_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: teams teams_leader_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_leader_id_fkey FOREIGN KEY (leader_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict NiU0xIOmm0AnNZcRBlchIh0fdrEWUe61yO37RfMCjavsMeu2bXF4NEmnqz71wkX

